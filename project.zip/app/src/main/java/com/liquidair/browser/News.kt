package com.liquidair.browser

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.os.Handler
import android.os.Looper
import android.util.LruCache
import android.view.Gravity
import android.view.View
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.ImageView
import android.widget.LinearLayout
import org.xmlpull.v1.XmlPullParser
import org.xmlpull.v1.XmlPullParserFactory
import java.net.HttpURLConnection
import java.net.URL
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.Executors

/** The news channels you can show under the start page. Each is the channel's own public RSS feed. */
object NewsSources {
    class Source(val id: String, val name: String, val feed: String)

    val all = listOf(
        Source("bbc", "BBC News", "https://feeds.bbci.co.uk/news/rss.xml"),
        Source("aljazeera", "Al Jazeera", "https://www.aljazeera.com/xml/rss/all.xml"),
        Source("dw", "DW", "https://rss.dw.com/rdf/rss-en-all"),
        Source("guardian", "The Guardian", "https://www.theguardian.com/world/rss"),
        Source("npr", "NPR", "https://feeds.npr.org/1001/rss.xml"),
        Source("france24", "France 24", "https://www.france24.com/en/rss"),
        Source("sky", "Sky News", "https://feeds.skynews.com/feeds/rss/world.xml"),
        Source("cnn", "CNN", "http://rss.cnn.com/rss/edition.rss"),
        Source("arabnews", "Arab News", "https://www.arabnews.com/rss.xml"),
        Source("verge", "The Verge", "https://www.theverge.com/rss/index.xml"),
        Source("techcrunch", "TechCrunch", "https://techcrunch.com/feed/"),
        Source("ars", "Ars Technica", "https://feeds.arstechnica.com/arstechnica/index")
    )
}

/** A picture that is always 16:9 at whatever width it is given. */
class WideImage(ctx: android.content.Context) : ImageView(ctx) {
    override fun onMeasure(widthSpec: Int, heightSpec: Int) {
        val w = View.MeasureSpec.getSize(widthSpec)
        setMeasuredDimension(w, w * 9 / 16)
    }
}

/**
 * The news under the start page, laid out like Brave's: scroll down from the search bar and a
 * "NEWS" feed of large picture cards appears (picture, headline, how old it is, and the channel).
 * Nothing is fetched unless "News on the start page" is on, and only from the channels you picked,
 * straight from their own feeds (no account, no middleman). Tapping a story opens it in the tab.
 */
class NewsView(private val act: MainActivity) {

    private class Item(val title: String, val link: String, val time: Long, val image: String?, val source: String)

    private val ui = Handler(Looper.getMainLooper())
    private val pool = Executors.newFixedThreadPool(4)
    private val images = LruCache<String, Bitmap>(30)

    private var items: List<Item> = emptyList()
    private var fetchedAt = 0L
    private var loading = false
    private var filter: String? = null

    private val list = LinearLayout(act)
    private val chips = LinearLayout(act)
    private val status = text(act, "", 14f, C.INK)

    /** Add this under the search bar's screen. */
    val view = CappedFrame(act, act.dp(660))

    init {
        val column = LinearLayout(act)
        column.orientation = LinearLayout.VERTICAL
        column.pad(16, 8, 16, 40)

        // "NEWS" title with a bar to its left.
        val head = LinearLayout(act)
        head.gravity = Gravity.CENTER_VERTICAL
        head.pad(12, 8, 18, 8)
        head.background = solid(act, C.CARD, 14f)
        val bar = View(act)
        bar.background = solid(act, C.LINK, 2f)
        head.addView(bar, LinearLayout.LayoutParams(act.dp(4), act.dp(26)).apply { rightMargin = act.dp(10) })
        head.addView(text(act, "NEWS", 22f, C.INK, true))
        column.addView(head, LinearLayout.LayoutParams(-2, -2).apply { bottomMargin = act.dp(12) })

        val chipScroll = HorizontalScrollView(act)
        chipScroll.isHorizontalScrollBarEnabled = false
        chips.gravity = Gravity.CENTER_VERTICAL
        chipScroll.addView(chips)
        column.addView(chipScroll, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = act.dp(12) })

        list.orientation = LinearLayout.VERTICAL
        status.pad(16, 14, 16, 14)
        status.background = solid(act, C.CARD, 14f)
        list.addView(status)
        column.addView(list, LinearLayout.LayoutParams(-1, -2))
        view.addView(column, FrameLayout.LayoutParams(-1, -2))
        view.addOnAttachStateChangeListener(object : View.OnAttachStateChangeListener {
            override fun onViewAttachedToWindow(v: View) { refresh(false) }
            override fun onViewDetachedFromWindow(v: View) {}
        })
    }

    /** True when the headlines are a few minutes old, so "Load new content" is worth offering. */
    fun isStale() = items.isNotEmpty() && System.currentTimeMillis() - fetchedAt > 3 * 60 * 1000L

    /** Hidden while something is typed on the start page (the overview takes this space) and in private tabs. */
    fun setVisible(show: Boolean) {
        view.visibility = if (show && act.prefs.newsOn && !act.browser.privateMode) View.VISIBLE else View.GONE
        if (view.visibility == View.VISIBLE) refresh(false)
    }

    /** Reload the headlines. Quiet unless they are over ten minutes old or `force` is set. */
    fun refresh(force: Boolean) {
        if (!act.prefs.newsOn || act.browser.privateMode) {
            view.visibility = View.GONE
            return
        }
        view.visibility = View.VISIBLE
        val chosen = NewsSources.all.filter { act.prefs.newsSources.contains(it.id) }
        if (chosen.isEmpty()) {
            items = emptyList()
            drawChips(chosen)
            showStatus("No news channels chosen. Pick some in Settings > General > News.")
            return
        }
        drawChips(chosen)
        val fresh = System.currentTimeMillis() - fetchedAt < 10 * 60 * 1000L
        if (!force && fresh && items.isNotEmpty()) {
            draw()
            return
        }
        if (loading) return
        loading = true
        if (items.isEmpty()) showStatus("Loading news...")
        val results = java.util.concurrent.ConcurrentHashMap<String, List<Item>>()
        val left = java.util.concurrent.atomic.AtomicInteger(chosen.size)
        for (s in chosen) {
            pool.execute {
                results[s.id] = try { fetch(s) } catch (e: Exception) { emptyList() }
                if (left.decrementAndGet() == 0) {
                    // Take turns between channels so each one shows up near the top.
                    val lists = chosen.map { (results[it.id] ?: emptyList()).take(8) }
                    val merged = ArrayList<Item>()
                    var i = 0
                    while (merged.size < 48 && lists.any { i < it.size }) {
                        for (l in lists) if (i < l.size) merged.add(l[i])
                        i++
                    }
                    ui.post {
                        loading = false
                        if (merged.isNotEmpty()) {
                            items = merged
                            fetchedAt = System.currentTimeMillis()
                        }
                        draw()
                    }
                }
            }
        }
    }

    // ---- drawing ---------------------------------------------------------------

    private fun showStatus(msg: String) {
        list.removeAllViews()
        status.text = msg
        list.addView(status)
    }

    private fun drawChips(chosen: List<NewsSources.Source>) {
        chips.removeAllViews()
        fun chip(label: String, id: String?) {
            val on = filter == id
            val t = text(act, label, 14f, if (on) C.WHITE else C.INK, on)
            t.pad(14, 7, 14, 7)
            t.background = solid(act, if (on) C.LINK else C.CARD, 17f)
            t.setOnClickListener {
                filter = id
                drawChips(chosen)
                draw()
            }
            chips.addView(t, LinearLayout.LayoutParams(-2, -2).apply { rightMargin = act.dp(8) })
        }
        if (filter != null && chosen.none { it.id == filter }) filter = null
        chip("All", null)
        for (s in chosen) chip(s.name, s.id)
    }

    private fun draw() {
        val shown = items.filter { filter == null || it.source == filter }
        if (shown.isEmpty()) {
            showStatus(if (loading) "Loading news..." else "Couldn't load the news. Check your connection.")
            return
        }
        list.removeAllViews()
        for (item in shown) list.addView(card(item), LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = act.dp(16) })
    }

    /** One story: a large picture on top, then the headline, its age and the channel. */
    private fun card(item: Item): View {
        val card = LinearLayout(act)
        card.orientation = LinearLayout.VERTICAL
        card.background = solid(act, C.CARD, 18f)
        card.clipToOutline = true
        if (item.image != null) {
            val img = WideImage(act)
            img.scaleType = ImageView.ScaleType.CENTER_CROP
            img.setBackgroundColor(C.SHADE)
            card.addView(img, LinearLayout.LayoutParams(-1, -2))
            val cached = images.get(item.image)
            if (cached != null) img.setImageBitmap(cached) else loadImage(item.image, img)
        }
        val body = LinearLayout(act)
        body.orientation = LinearLayout.VERTICAL
        body.pad(18, 14, 18, 16)
        val title = text(act, item.title, 17f, C.INK, true)
        title.maxLines = 3
        title.ellipsize = android.text.TextUtils.TruncateAt.END
        body.addView(title)
        if (item.time > 0) body.addView(text(act, ago(item.time), 13f, C.MUTED), LinearLayout.LayoutParams(-2, -2).apply { topMargin = act.dp(6) })
        val name = NewsSources.all.firstOrNull { it.id == item.source }?.name ?: ""
        body.addView(text(act, name, 14f, C.INK), LinearLayout.LayoutParams(-2, -2).apply { topMargin = act.dp(8) })
        card.addView(body)
        card.foreground = withRipple(null)
        card.setOnClickListener { act.openLink(item.link) }
        return card
    }

    private fun ago(t: Long): String {
        val m = (System.currentTimeMillis() - t) / 60000
        return when {
            m < 1 -> "just now"
            m < 60 -> if (m == 1L) "1 minute ago" else "$m minutes ago"
            m < 60 * 24 -> if (m < 120) "1 hour ago" else "${m / 60} hours ago"
            else -> "${m / (60 * 24)} days ago"
        }
    }

    private fun loadImage(url: String, into: ImageView) {
        into.tag = url
        pool.execute {
            try {
                val c = URL(url).openConnection() as HttpURLConnection
                c.connectTimeout = 4000
                c.readTimeout = 5000
                val bytes = c.inputStream.use { it.readBytes() }
                c.disconnect()
                val o = BitmapFactory.Options()
                o.inJustDecodeBounds = true
                BitmapFactory.decodeByteArray(bytes, 0, bytes.size, o)
                var s = 1
                while (o.outWidth / (s * 2) >= 900) s *= 2
                val o2 = BitmapFactory.Options()
                o2.inSampleSize = s
                val bmp = BitmapFactory.decodeByteArray(bytes, 0, bytes.size, o2) ?: return@execute
                images.put(url, bmp)
                ui.post { if (into.tag == url) into.setImageBitmap(bmp) }
            } catch (e: Exception) {
                // No picture for this story.
            }
        }
    }

    // ---- fetching and reading a feed ---------------------------------------------------

    private fun fetch(s: NewsSources.Source): List<Item> {
        val c = URL(s.feed).openConnection() as HttpURLConnection
        c.connectTimeout = 5000
        c.readTimeout = 6000
        c.instanceFollowRedirects = true
        c.setRequestProperty("User-Agent", "Mozilla/5.0 (Android) LiquidAir")
        val out = ArrayList<Item>()
        c.inputStream.use { stream ->
            val p = XmlPullParserFactory.newInstance().newPullParser()
            p.setInput(stream, null)
            var inItem = false
            var title = ""
            var link = ""
            var date = ""
            var image: String? = null
            var ev = p.eventType
            while (ev != XmlPullParser.END_DOCUMENT) {
                if (ev == XmlPullParser.START_TAG) {
                    val n = p.name.lowercase(Locale.US)
                    if (n == "item" || n == "entry") {
                        inItem = true; title = ""; link = ""; date = ""; image = null
                    } else if (inItem) {
                        when (n) {
                            "title" -> title = p.nextText().trim()
                            "link" -> {
                                val href = p.getAttributeValue(null, "href")
                                val t = try { p.nextText().trim() } catch (e: Exception) { "" }
                                link = if (!href.isNullOrEmpty()) href else t
                            }
                            "pubdate", "published", "updated", "date" -> if (date.isEmpty()) date = p.nextText().trim()
                            "thumbnail", "content", "enclosure" -> {
                                val u = p.getAttributeValue(null, "url")
                                val type = p.getAttributeValue(null, "type") ?: ""
                                val medium = p.getAttributeValue(null, "medium") ?: ""
                                if (image == null && !u.isNullOrEmpty() &&
                                    (n == "thumbnail" || type.startsWith("image") || medium == "image")
                                ) image = u.replace("http://", "https://")
                            }
                        }
                    }
                } else if (ev == XmlPullParser.END_TAG) {
                    val n = p.name.lowercase(Locale.US)
                    if ((n == "item" || n == "entry") && inItem) {
                        inItem = false
                        if (title.isNotEmpty() && link.startsWith("http")) {
                            out.add(Item(title, link.replace("http://", "https://"), parseDate(date), image, s.id))
                        }
                    }
                }
                ev = p.next()
            }
        }
        c.disconnect()
        return out
    }

    private fun parseDate(s: String): Long {
        if (s.isEmpty()) return 0
        val formats = arrayOf(
            "EEE, dd MMM yyyy HH:mm:ss Z", "EEE, dd MMM yyyy HH:mm:ss zzz", "yyyy-MM-dd'T'HH:mm:ssXXX",
            "yyyy-MM-dd'T'HH:mm:ss'Z'", "yyyy-MM-dd'T'HH:mm:ss.SSSXXX"
        )
        for (f in formats) {
            try {
                val d: Date? = SimpleDateFormat(f, Locale.US).parse(s)
                if (d != null) return d.time
            } catch (e: Exception) {
                // Try the next format.
            }
        }
        return 0
    }
}
