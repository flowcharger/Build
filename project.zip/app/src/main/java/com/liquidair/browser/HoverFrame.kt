package com.liquidair.browser

import android.content.Context
import android.os.SystemClock
import android.view.InputDevice
import android.view.MotionEvent
import android.view.View
import android.view.ViewConfiguration
import android.widget.FrameLayout
import kotlin.math.hypot

/**
 * Wraps the web page. With hover mode on, a tap does not click: it moves a mouse
 * pointer to that spot instead, so the page shows what it shows on a desktop when the
 * cursor rests on something (details, previews, highlights). Dragging still scrolls.
 */
class HoverFrame(ctx: Context) : FrameLayout(ctx) {
    var hoverMode = false
        set(value) {
            if (field && !value) sendHover(lastX, lastY, MotionEvent.ACTION_HOVER_EXIT)
            field = value
            hovering = false
        }

    private val slop = ViewConfiguration.get(ctx).scaledTouchSlop.toFloat()
    private var held: MotionEvent? = null
    private var passing = false
    private var hovering = false
    private var lastX = 0f
    private var lastY = 0f

    override fun dispatchTouchEvent(ev: MotionEvent): Boolean {
        val page = if (childCount > 0) getChildAt(0) else null
        if (!hoverMode || page == null || page.visibility != View.VISIBLE) {
            return super.dispatchTouchEvent(ev)
        }
        when (ev.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                held?.recycle()
                held = MotionEvent.obtain(ev)
                passing = false
                return true
            }
            MotionEvent.ACTION_MOVE -> {
                if (passing) return super.dispatchTouchEvent(ev)
                val d = held ?: return true
                if (hypot(ev.x - d.x, ev.y - d.y) > slop) {
                    flushHeld()
                    return super.dispatchTouchEvent(ev)
                }
                return true
            }
            MotionEvent.ACTION_UP -> {
                if (passing) return super.dispatchTouchEvent(ev)
                val d = held
                if (d != null) {
                    hover(ev.x, ev.y)
                    d.recycle()
                    held = null
                }
                return true
            }
            MotionEvent.ACTION_CANCEL -> {
                if (passing) return super.dispatchTouchEvent(ev)
                held?.recycle()
                held = null
                return true
            }
            else -> {
                // A second finger (pinch or two-finger scroll): hand the whole gesture to the page.
                if (!passing && held != null) flushHeld()
                return super.dispatchTouchEvent(ev)
            }
        }
    }

    private fun flushHeld() {
        val d = held ?: return
        passing = true
        super.dispatchTouchEvent(d)
        d.recycle()
        held = null
    }

    private fun hover(x: Float, y: Float) {
        lastX = x
        lastY = y
        sendHover(x, y, if (hovering) MotionEvent.ACTION_HOVER_MOVE else MotionEvent.ACTION_HOVER_ENTER)
        hovering = true
        sendHover(x, y, MotionEvent.ACTION_HOVER_MOVE)
    }

    private fun sendHover(x: Float, y: Float, action: Int) {
        val page = if (childCount > 0) getChildAt(0) else return
        val now = SystemClock.uptimeMillis()
        val props = arrayOf(MotionEvent.PointerProperties().apply {
            id = 0
            toolType = MotionEvent.TOOL_TYPE_MOUSE
        })
        val coords = arrayOf(MotionEvent.PointerCoords().apply {
            this.x = x
            this.y = y
            pressure = 0f
            size = 1f
        })
        val e = MotionEvent.obtain(
            now, now, action, 1, props, coords, 0, 0, 1f, 1f, 0, 0, InputDevice.SOURCE_MOUSE, 0
        )
        try {
            page.dispatchGenericMotionEvent(e)
        } finally {
            e.recycle()
        }
    }
}
