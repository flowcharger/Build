package com.liquidair.browser

import android.app.AlertDialog
import android.app.DownloadManager
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.os.Handler
import android.os.Looper
import android.text.Editable
import android.text.TextWatcher
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.ViewOutlineProvider
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.PopupWindow
import android.widget.ScrollView
import android.widget.TextView
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

/**
 * The Downloads page, laid out like Chrome's: a title with a settings button, a search box,
 * "Using 303.52 MB of 103.62 GB", filter chips (All, Images, Pages, Other), then downloads
 * grouped by day. Images show as preview tiles; everything else is a row with a "⋮" menu.
 */
class DownloadsPage(private val act: MainActivity) {
    private val handler = Handler(Looper.getMainLooper())
    private var filter = 0 // 0 all, 1 images, 2 pages, 3 other
    private var query = ""
    private var signature = ""
    private var running = false

    private var scroll: ScrollView? = null
    private var listHost: LinearLayout? = null
    private var usageText: TextView? = null
    private var chipRow: LinearLayout? = null

    private fun dp(v: Int) = act.dp(v)

    private val tick = object : Runnable {
        override fun run() {
            if (!running) return
            val v = scroll
            if (v != null && v.isShown) refresh(false)
            handler.postDelayed(this, 1000)
        }
    }

    /** Starts watching the Download Manager, so progress bars move and finished files appear. */
    fun start() {
        running = true
        signature = ""
        act.downloads.onFinished = { if (running) refresh(true) }
        handler.removeCallbacks(tick)
        handler.post(tick)
    }

    fun stop() {
        running = false
        handler.removeCallbacks(tick)
    }

    // ---- the page --------------------------------------------------------------------------

    fun build(): View {
        val sv = ScrollView(act)
        scroll = sv
        val frame = CappedFrame(act, dp(640))
        sv.addView(frame, FrameLayout.LayoutParams(-1, -2).apply { gravity = Gravity.CENTER_HORIZONTAL })
        val col = LinearLayout(act)
        col.orientation = LinearLayout.VERTICAL
        col.pad(16, 4, 16, 32)
        frame.addView(col, FrameLayout.LayoutParams(-1, -2))

        // Title, "paste a link" and settings.
        val head = LinearLayout(act)
        head.gravity = Gravity.CENTER_VERTICAL
        head.addView(text(act, "Downloads", 28f, C.INK, true), LinearLayout.LayoutParams(0, -2, 1f))
        val paste = iconButton(act, R.drawable.ic_plus, 44, 44, 22, "Download from a link")
        paste.setOnClickListener { askForLink() }
        head.addView(paste)
        val gear = iconButton(act, R.drawable.ic_tune, 44, 44, 22, "Download settings")
        gear.setOnClickListener { act.openSettings("downloads") }
        head.addView(gear)
        col.addView(head, lp(-1, -2).apply { topMargin = dp(4); bottomMargin = dp(10) })

        // Search.
        val search = EditText(act)
        search.hint = "Search your downloads"
        search.setHintTextColor(C.HINT)
        search.setTextColor(C.INK)
        search.textSize = 16f
        search.isSingleLine = true
        search.background = solid(act, C.SOFT, 28f)
        search.pad(22, 0, 22, 0)
        search.addTextChangedListener(object : TextWatcher {
            override fun afterTextChanged(s: Editable?) {
                query = s?.toString()?.trim()?.lowercase(Locale.getDefault()).orEmpty()
                refresh(true)
            }

            override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
        })
        col.addView(search, lp(-1, dp(54)))

        // "Using X of Y" and "Clear all".
        val usageRow = LinearLayout(act)
        usageRow.gravity = Gravity.CENTER_VERTICAL
        val usage = text(act, "", 13f, C.MUTED)
        usageText = usage
        usageRow.addView(usage, LinearLayout.LayoutParams(0, -2, 1f))
        val clear = text(act, "Clear all", 13f, C.MUTED, true)
        clear.pad(10, 8, 10, 8)
        clear.setOnClickListener {
            act.downloads.clearList()
            act.toast("Cleared. The files are still on your device.")
            refresh(true)
        }
        usageRow.addView(clear)
        col.addView(usageRow, lp(-1, -2).apply { topMargin = dp(12) })

        // Filter chips.
        val chips = LinearLayout(act)
        chips.gravity = Gravity.CENTER_VERTICAL
        chipRow = chips
        val hs = HorizontalScrollView(act)
        hs.isHorizontalScrollBarEnabled = false
        hs.addView(chips, FrameLayout.LayoutParams(-2, -2))
        col.addView(hs, lp(-1, -2).apply { topMargin = dp(10); bottomMargin = dp(6) })
        drawChips()

        val list = LinearLayout(act)
        list.orientation = LinearLayout.VERTICAL
        listHost = list
        col.addView(list, lp(-1, -2))
        refresh(true)
        return sv
    }

    private fun drawChips() {
        val row = chipRow ?: return
        row.removeAllViews()
        val defs = listOf(
            Triple("All", R.drawable.ic_download, 0),
            Triple("Images", R.drawable.ic_image, 1),
            Triple("Pages", R.drawable.ic_globe, 2),
            Triple("Other", R.drawable.ic_file, 3)
        )
        for ((label, res, idx) in defs) {
            val on = filter == idx
            val chip = LinearLayout(act)
            chip.gravity = Gravity.CENTER_VERTICAL
            chip.pad(12, 0, 16, 0)
            if (on) {
                chip.background = solid(act, C.MINT, 12f)
            } else {
                val outline = GradientDrawable()
                outline.cornerRadius = act.dpf(12f)
                outline.setColor(Color.TRANSPARENT)
                outline.setStroke(maxOf(1, dp(1)), C.EDGE_DARK)
                chip.background = outline
            }
            chip.addView(
                icon(act, if (on) R.drawable.ic_check else res, 18),
                LinearLayout.LayoutParams(dp(18), dp(18)).apply { rightMargin = dp(8) }
            )
            chip.addView(text(act, label, 15f, C.INK, on))
            chip.setOnClickListener {
                filter = idx
                drawChips()
                refresh(true)
            }
            row.addView(chip, LinearLayout.LayoutParams(-2, dp(40)).apply { rightMargin = dp(8) })
        }
    }

    // ---- listing ---------------------------------------------------------------------------

    private fun refresh(force: Boolean) {
        val host = listHost ?: return
        val items = act.downloads.list()
        val sig = items.joinToString("|") { "${it.id}:${it.status}:${it.sofar}" } + "#$filter#$query"
        if (!force && sig == signature) return
        signature = sig

        val (used, total) = act.downloads.usage(items)
        usageText?.text = if (total > 0) "Using ${fmtSize(used)} of ${fmtSize(total)}" else "Using ${fmtSize(used)}"

        val y = scroll?.scrollY ?: 0
        host.removeAllViews()
        val shown = items.filter { item ->
            val kindOk = filter == 0 || act.downloads.kind(item) == filter
            val queryOk = query.isEmpty() || (item.name + " " + item.host).lowercase(Locale.getDefault()).contains(query)
            kindOk && queryOk
        }
        if (shown.isEmpty()) {
            val msg = text(
                act,
                if (items.isEmpty()) "Files you download will appear here." else "No downloads match.",
                15f, C.MUTED
            )
            msg.gravity = Gravity.CENTER
            msg.pad(8, 48, 8, 48)
            host.addView(msg, lp(-1, -2))
            return
        }

        val now = System.currentTimeMillis()
        var label = ""
        var group = ArrayList<Downloads.Item>()
        fun flush() {
            if (group.isNotEmpty()) addGroup(host, label, group)
            group = ArrayList()
        }
        for (item in shown) {
            val l = groupLabel(item.time, now)
            if (l != label) {
                flush()
                label = l
            }
            group.add(item)
        }
        flush()
        restoreScroll(y)
    }

    private fun restoreScroll(y: Int) {
        val v = scroll ?: return
        if (y > 0) v.post { v.scrollTo(0, y) }
    }

    private fun groupLabel(time: Long, now: Long): String {
        if (now - time in 0L..120000L) return "Just now"
        val c = Calendar.getInstance()
        c.timeInMillis = now
        c.set(Calendar.HOUR_OF_DAY, 0)
        c.set(Calendar.MINUTE, 0)
        c.set(Calendar.SECOND, 0)
        c.set(Calendar.MILLISECOND, 0)
        val todayStart = c.timeInMillis
        c.add(Calendar.DAY_OF_YEAR, -1)
        val yesterdayStart = c.timeInMillis
        val day = SimpleDateFormat("MMM d, yyyy", Locale.getDefault()).format(Date(time))
        return when {
            time >= todayStart -> "Today"
            time >= yesterdayStart -> "Yesterday - $day"
            else -> day
        }
    }

    private fun addGroup(host: LinearLayout, label: String, items: List<Downloads.Item>) {
        val h = text(act, label, 16f, C.INK, false)
        h.pad(2, 22, 2, 8)
        host.addView(h, lp(-1, -2))
        // Finished images become tiles; everything else (and anything still running) is a row.
        val tiles = items.filter { it.done && act.downloads.kind(it) == 1 }
        for (item in items) {
            if (!tiles.contains(item)) host.addView(fileRow(item), lp(-1, -2))
        }
        for (pair in tiles.chunked(2)) {
            val line = LinearLayout(act)
            for (item in pair) {
                line.addView(tile(item), LinearLayout.LayoutParams(0, -2, 1f).apply {
                    leftMargin = dp(4); rightMargin = dp(4); bottomMargin = dp(10)
                })
            }
            if (pair.size == 1) line.addView(View(act), LinearLayout.LayoutParams(0, 1, 1f))
            host.addView(line, lp(-1, -2))
        }
    }

    // ---- one download ----------------------------------------------------------------------

    private fun subtitle(item: Downloads.Item): String {
        val host = item.host
        val tail = if (host.isEmpty()) "" else " • $host"
        return when {
            item.failed -> "Failed$tail"
            item.done -> fmtSize(if (item.total > 0) item.total else item.sofar) + tail
            item.status == DownloadManager.STATUS_PAUSED || item.status == DownloadManager.STATUS_PENDING ->
                "Waiting to download$tail"
            item.total > 0 -> "${fmtSize(item.sofar)} of ${fmtSize(item.total)}$tail"
            else -> fmtSize(item.sofar) + tail
        }
    }

    private fun fileRow(item: Downloads.Item): View {
        val r = LinearLayout(act)
        r.gravity = Gravity.CENTER_VERTICAL
        r.pad(2, 8, 0, 8)
        r.background = withRipple(null)
        r.setOnClickListener { if (item.done) act.downloads.open(item) }

        val badge = FrameLayout(act)
        badge.background = solid(act, C.SOFT, 22f)
        val kindIcon = if (act.downloads.kind(item) == 2) R.drawable.ic_globe else R.drawable.ic_file
        badge.addView(icon(act, kindIcon, 22), FrameLayout.LayoutParams(dp(22), dp(22), Gravity.CENTER))
        r.addView(badge, LinearLayout.LayoutParams(dp(44), dp(44)).apply { rightMargin = dp(14) })

        val col = LinearLayout(act)
        col.orientation = LinearLayout.VERTICAL
        col.addView(oneLine(text(act, item.name, 16f, C.INK, false)))
        val sub = oneLine(text(act, subtitle(item), 13f, if (item.failed) 0xFFD93025.toInt() else C.MUTED))
        col.addView(sub, lp(-2, -2).apply { topMargin = dp(3) })
        if (item.running) {
            val frac = if (item.total > 0) (item.sofar.toFloat() / item.total).coerceIn(0f, 1f) else 0f
            val track = LinearLayout(act)
            track.background = solid(act, C.LINE, 3f)
            val fill = View(act)
            fill.background = solid(act, C.SKY_C, 3f)
            track.addView(fill, LinearLayout.LayoutParams(0, -1, maxOf(frac, 0.02f)))
            track.addView(View(act), LinearLayout.LayoutParams(0, -1, maxOf(1f - frac, 0.0001f)))
            col.addView(track, lp(-1, dp(5)).apply { topMargin = dp(8) })
        }
        r.addView(col, LinearLayout.LayoutParams(0, -2, 1f))

        val more = iconButton(act, R.drawable.ic_more, 44, 44, 22, "More actions")
        more.setOnClickListener { showMenu(more, item) }
        r.addView(more)
        return r
    }

    private fun tile(item: Downloads.Item): View {
        val box = LinearLayout(act)
        box.orientation = LinearLayout.VERTICAL

        val pic = FrameLayout(act)
        pic.background = solid(act, C.SOFT, 16f)
        pic.clipToOutline = true
        pic.outlineProvider = ViewOutlineProvider.BACKGROUND
        val img = ImageView(act)
        img.scaleType = ImageView.ScaleType.CENTER_CROP
        pic.addView(img, FrameLayout.LayoutParams(-1, -1))
        act.downloads.thumbnail(item, dp(320)) { bmp -> if (bmp != null) img.setImageBitmap(bmp) }
        val more = iconButton(act, R.drawable.ic_more, 36, 36, 18, "More actions")
        more.background = solid(act, 0x66000000, 18f)
        more.iconView().imageTintList = ColorStateList.valueOf(Color.WHITE)
        more.setOnClickListener { showMenu(more, item) }
        pic.addView(more, FrameLayout.LayoutParams(dp(36), dp(36), Gravity.TOP or Gravity.END).apply {
            topMargin = dp(6); rightMargin = dp(6)
        })
        pic.setOnClickListener { act.downloads.open(item) }
        box.addView(pic, lp(-1, dp(170)))

        box.addView(oneLine(text(act, item.name, 13f, C.INK, false)), lp(-1, -2).apply { topMargin = dp(6) })
        box.addView(
            oneLine(text(act, fmtSize(if (item.total > 0) item.total else item.sofar), 12f, C.MUTED)),
            lp(-1, -2).apply { topMargin = dp(2) }
        )
        return box
    }

    // ---- the "⋮" menu ----------------------------------------------------------------------

    private fun showMenu(anchor: View, item: Downloads.Item) {
        val labels = ArrayList<String>()
        val actions = ArrayList<() -> Unit>()
        fun add(label: String, run: () -> Unit) {
            labels.add(label)
            actions.add(run)
        }
        val dl = act.downloads
        when {
            item.done -> {
                add("Open") { dl.open(item) }
                add("Share") { dl.share(item) }
                add("Copy download link") { dl.copyLink(item) }
                add("Remove from list") { dl.removeFromList(item); refresh(true) }
                add("Delete file") { dl.delete(item); act.toast("Deleted"); refresh(true) }
            }
            item.failed -> {
                add("Try again") { dl.retry(item); refresh(true) }
                add("Copy download link") { dl.copyLink(item) }
                add("Remove from list") { dl.delete(item); refresh(true) }
            }
            else -> {
                add("Cancel download") { dl.delete(item); refresh(true) }
                add("Copy download link") { dl.copyLink(item) }
            }
        }

        val panel = LinearLayout(act)
        panel.orientation = LinearLayout.VERTICAL
        panel.background = solid(act, C.WHITE, 18f)
        panel.pad(6, 6, 6, 6)
        val holder = arrayOfNulls<PopupWindow>(1)
        for (i in labels.indices) {
            val row = LinearLayout(act)
            row.gravity = Gravity.CENTER_VERTICAL
            row.pad(14, 0, 14, 0)
            row.background = withRipple(null)
            row.addView(text(act, labels[i], 15f, C.INK, false))
            row.setOnClickListener {
                holder[0]?.dismiss()
                actions[i]()
            }
            panel.addView(row, lp(-1, dp(46)))
        }
        val popup = PopupWindow(panel, dp(230), ViewGroup.LayoutParams.WRAP_CONTENT, true)
        popup.elevation = act.dpf(14f)
        popup.setBackgroundDrawable(null)
        popup.isOutsideTouchable = true
        holder[0] = popup
        popup.showAsDropDown(anchor, anchor.width - dp(230), -dp(8))
    }

    private fun askForLink() {
        val input = EditText(act)
        input.hint = "https://…"
        input.isSingleLine = true
        val wrap = FrameLayout(act)
        wrap.pad(22, 8, 22, 0)
        wrap.addView(input, FrameLayout.LayoutParams(-1, -2))
        AlertDialog.Builder(act)
            .setTitle("Download from a link")
            .setView(wrap)
            .setPositiveButton("Download") { _, _ ->
                val url = input.text.toString().trim()
                if (url.isNotEmpty()) {
                    act.downloads.fetch(url)
                    refresh(true)
                }
            }
            .setNegativeButton("Cancel", null)
            .show()
    }
}
