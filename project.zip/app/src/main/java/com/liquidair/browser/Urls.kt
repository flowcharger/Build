package com.liquidair.browser

import java.net.URI
import java.net.URLDecoder
import java.net.URLEncoder
import java.util.Locale

/** Address handling that has no Android dependencies, so it can be tested on its own. */
object Urls {
    private val SCHEME = Regex("^[a-zA-Z][a-zA-Z0-9+.-]*:.*")
    private val DOMAIN = Regex("^([a-z0-9-]+\\.)+[a-z]{2,}(:\\d+)?([/?#].*)?$", RegexOption.IGNORE_CASE)
    private val LOCAL = Regex("^(localhost|\\d{1,3}(\\.\\d{1,3}){3})(:\\d+)?([/?#].*)?$", RegexOption.IGNORE_CASE)

    private val GOOGLE_HOST = Regex("^(www\\.)?google\\.(com|co\\.[a-z]{2}|com\\.[a-z]{2}|[a-z]{2,3})$")

    /** Sites where tracker blocking must stay off (video sites, captchas and checks). */
    private val NO_BLOCK_HOSTS = listOf(
        "youtube.com", "youtu.be", "youtube-nocookie.com", "googlevideo.com", "ytimg.com",
        "cloudflare.com", "cloudflareinsights.com", "hcaptcha.com", "recaptcha.net",
        "arkoselabs.com", "funcaptcha.com", "turnstile.com"
    )

    /**
     * Known ad-serving and ad-iframe hosts. This is checked only on navigations (a page or an
     * iframe loading from one of these hosts) — never on a page's own HTML, CSS or images — so
     * blocking it stops the ad from ever loading without touching how the rest of the page,
     * including inline styles, is built or laid out.
     */
    private val AD_HOSTS = listOf(
        "doubleclick.net", "googlesyndication.com", "googleadservices.com", "adservice.google.com",
        "googletagservices.com", "google-analytics.com", "amazon-adsystem.com", "adnxs.com",
        "adsrvr.org", "bidswitch.net", "casalemedia.com", "contextweb.com", "criteo.com",
        "criteo.net", "media.net", "mgid.com", "moatads.com", "openx.net", "pubmatic.com",
        "revcontent.com", "rlcdn.com", "rubiconproject.com", "scorecardresearch.com",
        "sharethrough.com", "smartadserver.com", "taboola.com", "outbrain.com", "triplelift.com",
        "yieldmo.com", "zedo.com", "popads.net", "propellerads.com", "adcolony.com",
        "applovin.com", "chartboost.com", "exoclick.com", "juicyads.com", "trafficjunky.net",
        "adform.net", "advertising.com", "serving-sys.com", "yahoo.com/serve", "adtech.de",
        "2mdn.net", "adsafeprotected.com", "ads-twitter.com", "quantserve.com", "bluekai.com",
        "demdex.net", "krxd.net", "turn.com", "adroll.com", "aol.com/dartproxy",
        "connexity.net", "flashtalking.com", "spotxchange.com", "springserve.com",
        // Popunder / redirect networks common on ad-heavy, older-style sites — the kind
        // that spawn new tabs or full-page redirects rather than loading inline ads.
        "popcash.net", "admaven.com", "adk2.com", "adk2x.com", "exosrv.com", "clickadu.com",
        "adsterra.com", "hilltopads.net", "popmyads.com", "adskeeper.co.uk", "revenuehits.com",
        "bidvertiser.com", "infolinks.com", "yllix.com", "adbutler.com", "smartyads.com",
        "pubnative.net", "inner-active.mobi", "mobfox.com", "mobpartner.com", "adcash.com",
        "adnium.com", "clicksor.com", "onclickmax.com", "cpalead.com", "cpmstar.com",
        "unityads.unity3d.com", "ironsrc.com", "startapp.com", "tapjoy.com", "vungle.com",
        "zergnet.com", "content.ad", "sovrn.com", "indexexchange.com", "rhythmone.com",
        "telaria.com", "districtm.io", "sonobi.com", "undertone.com", "teads.tv", "gumgum.com",
        "kargo.com", "smaato.net", "fyber.com", "admixer.net", "adition.com", "yieldlab.net",
        "emxdgt.com", "33across.com", "lijit.com", "pulsepoint.com", "lkqd.net",
        "exponential.com", "tribalfusion.com", "burstnet.com", "chitika.com", "adblade.com",
        "contentad.net", "mgcash.com", "adxpansion.com", "trafficstars.com", "exdynsrv.com",
        "onclckmn.com", "adserverplus.com", "yeahmobi.com", "adtelligent.com", "adpone.com",
        "improve-digital.com", "smartclip.net"
    )

    fun hostOf(url: String): String {
        return try {
            (URI(url).host ?: "").lowercase(Locale.US).removePrefix("www.")
        } catch (e: Exception) {
            ""
        }
    }

    /** Turn what the user typed into an address. */
    fun resolveInput(text: String, safeSearch: Boolean, engine: Int = 0): String {
        val t = text.trim()
        if (t.isEmpty()) return t
        if (t.startsWith("about:", true)) return t
        if (SCHEME.matches(t) && t.contains("://")) {
            return if (t.startsWith("http", true)) applySafeSearch(t, safeSearch) else t
        }
        if (!t.contains(' ')) {
            if (LOCAL.matches(t)) return "http://$t"
            if (DOMAIN.matches(t)) return applySafeSearch("https://$t", safeSearch)
        }
        val query = URLEncoder.encode(t, "UTF-8")
        if (engine == 1) return "https://search.brave.com/search?q=$query"
        if (engine == 2) return "https://duckduckgo.com/?q=$query"
        return applySafeSearch("https://www.google.com/search?q=$query", safeSearch)
    }

    fun isGoogleSearch(url: String): Boolean {
        return try {
            val u = URI(url)
            val host = (u.host ?: "").lowercase(Locale.US)
            val google = GOOGLE_HOST.matches(host)
            google && u.path == "/search"
        } catch (e: Exception) {
            false
        }
    }

    /** SafeSearch on: safe=active. SafeSearch off: safe=off. Only on Google search pages. */
    fun applySafeSearch(url: String, on: Boolean): String {
        if (!isGoogleSearch(url)) return url
        var hash = ""
        var base = url
        val at = base.indexOf('#')
        if (at >= 0) {
            hash = base.substring(at)
            base = base.substring(0, at)
        }
        val q = base.indexOf('?')
        var path = base
        val kept = ArrayList<String>()
        if (q >= 0) {
            path = base.substring(0, q)
            for (part in base.substring(q + 1).split("&")) {
                if (part.isEmpty() || part == "safe" || part.startsWith("safe=")) continue
                kept.add(part)
            }
        }
        kept.add(if (on) "safe=active" else "safe=off")
        val rebuilt = path + (if (kept.isEmpty()) "" else "?" + kept.joinToString("&"))
        return rebuilt + hash
    }

    /** The words searched for, when this is a Google results page. */
    fun isBraveSearch(url: String): Boolean {
        return try {
            val u = URI(url)
            (u.host ?: "").lowercase(Locale.US) == "search.brave.com" && u.path == "/search"
        } catch (e: Exception) {
            false
        }
    }

    fun isDuckSearch(url: String): Boolean {
        return try {
            val u = URI(url)
            (u.host ?: "").lowercase(Locale.US) == "duckduckgo.com" && (u.query ?: "").contains("q=")
        } catch (e: Exception) {
            false
        }
    }

    fun searchQuery(url: String): String? {
        if (!isGoogleSearch(url) && !isBraveSearch(url) && !isDuckSearch(url)) return null
        val q = url.indexOf('?')
        if (q < 0) return null
        for (part in url.substring(q + 1).substringBefore('#').split("&")) {
            if (part.startsWith("q=")) {
                return try {
                    URLDecoder.decode(part.substring(2), "UTF-8")
                } catch (e: Exception) {
                    part.substring(2)
                }
            }
        }
        return null
    }

    /** True for pages where tracker/ad blocking must stay off. */
    fun blockerOffFor(url: String): Boolean {
        val host = hostOf(url)
        if (host.isEmpty()) return false
        if (host.contains("captcha") || host.contains("challenge")) return true
        if (url.contains("/recaptcha/") || url.contains("/cdn-cgi/challenge")) return true
        for (h in NO_BLOCK_HOSTS) {
            if (host == h || host.endsWith(".$h")) return true
        }
        return false
    }

    /** The built-in hosts above plus the big list loaded from the app's assets (see AdBlock). */
    @Volatile
    private var adSet: Set<String> = AD_HOSTS.toHashSet()

    /** Adds more ad-serving hosts (the long list shipped in assets/adblock/hosts.txt). */
    fun addAdHosts(extra: Collection<String>) {
        val merged = HashSet<String>(AD_HOSTS)
        merged.addAll(extra)
        adSet = merged
    }

    fun adHostCount(): Int = adSet.size

    /** True when a navigation (a page load or an iframe) is to a known ad-serving host. */
    fun isAdHost(url: String): Boolean {
        var h = hostOf(url)
        if (h.isEmpty()) return false
        val set = adSet
        while (true) {
            if (set.contains(h)) return true
            val dot = h.indexOf('.')
            if (dot < 0) return false
            h = h.substring(dot + 1)
        }
    }

    // ---- link tracking parameters ---------------------------------------------------------

    private val TRACKING_PARAMS = setOf(
        "fbclid", "gclid", "gclsrc", "dclid", "gbraid", "wbraid", "msclkid", "yclid", "twclid",
        "ttclid", "li_fat_id", "igshid", "mc_eid", "mc_cid", "_hsenc", "_hsmi", "mkt_tok",
        "vero_id", "wickedid", "oly_enc_id", "oly_anon_id", "s_cid", "_ga", "_gl", "scid"
    )

    /** The link without utm_*, fbclid, gclid and similar tracking tags. Same link if none. */
    fun stripTracking(url: String): String {
        val q = url.indexOf('?')
        if (q < 0 || !isWeb(url)) return url
        val hashAt = url.indexOf('#', q)
        val base = url.substring(0, q)
        val query = if (hashAt >= 0) url.substring(q + 1, hashAt) else url.substring(q + 1)
        val hash = if (hashAt >= 0) url.substring(hashAt) else ""
        val kept = ArrayList<String>()
        var removed = false
        for (part in query.split("&")) {
            if (part.isEmpty()) continue
            val name = part.substringBefore('=').lowercase(Locale.US)
            if (name.startsWith("utm_") || TRACKING_PARAMS.contains(name)) removed = true else kept.add(part)
        }
        if (!removed) return url
        return base + (if (kept.isEmpty()) "" else "?" + kept.joinToString("&")) + hash
    }

    /** scheme://host[:port] for a web address, or "" when it isn't one. */
    fun originOf(url: String): String {
        return try {
            val u = URI(url.trim())
            val scheme = (u.scheme ?: "").lowercase(Locale.US)
            val host = (u.host ?: "").lowercase(Locale.US)
            if ((scheme != "http" && scheme != "https") || host.isEmpty()) ""
            else scheme + "://" + host + (if (u.port > 0) ":" + u.port else "")
        } catch (e: Exception) {
            ""
        }
    }

    // ---- downloads -------------------------------------------------------------------------

    private val RISKY_EXT = setOf(
        "apk", "apks", "xapk", "exe", "msi", "bat", "cmd", "com", "scr", "pif", "vbs", "vbe", "js",
        "jse", "wsf", "wsh", "ps1", "sh", "jar", "dmg", "pkg", "deb", "rpm", "lnk", "reg", "hta",
        "cpl", "dll", "appimage"
    )

    /** True for programs and scripts that can harm a device if they are run. */
    fun isRiskyFile(name: String, mime: String?): Boolean {
        val ext = name.substringAfterLast('.', "").lowercase(Locale.US)
        if (RISKY_EXT.contains(ext)) return true
        val m = (mime ?: "").lowercase(Locale.US)
        return m == "application/vnd.android.package-archive" || m == "application/x-msdownload" ||
            m == "application/x-sh" || m == "application/x-msdos-program" || m == "application/java-archive"
    }

    /** Short text for the address bar when it is not being edited. */
    fun display(url: String): String {
        if (url.isEmpty() || url == "about:blank") return ""
        searchQuery(url)?.let { return it }
        var s = url.removePrefix("https://").removePrefix("http://").removePrefix("www.")
        if (s.endsWith("/") && s.indexOf('/') == s.length - 1) s = s.dropLast(1)
        return s
    }

    fun isWeb(url: String): Boolean {
        return url.startsWith("http://", true) || url.startsWith("https://", true)
    }
}
