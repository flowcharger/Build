package com.liquidair.browser

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.os.Handler
import android.os.Looper
import android.util.LruCache
import android.view.Gravity
import android.view.View
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Switch
import android.widget.TextView
import android.text.Editable
import android.text.TextWatcher
import android.app.AlertDialog
import org.json.JSONObject
import org.mozilla.geckoview.WebExtension
import org.mozilla.geckoview.WebExtensionController
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.util.Locale
import java.util.concurrent.Executors

/**
 * The extensions market. "Active" lists what is installed (switch it off or remove it);
 * "Browse" searches Mozilla's add-ons site for extensions that work on phones and tablets and adds
 * them with one tap. Extensions run in every tab, the same way they do in Firefox.
 */
class ExtensionsPage(private val act: MainActivity) {

    private class Listing(
        val guid: String,
        val name: String,
        val summary: String,
        val icon: String?,
        val users: Long,
        val xpi: String
    )

    private val ui = Handler(Looper.getMainLooper())
    private val net = Executors.newFixedThreadPool(3)
    private val icons = LruCache<String, Bitmap>(80)

    private var tab = 0
    private var query = ""
    private var installed: List<WebExtension> = emptyList()
    private var results: List<Listing> = emptyList()
    private var status = ""
    private var token = 0
    private val installing = HashSet<String>()

    private lateinit var body: LinearLayout
    private lateinit var tabs: LinearLayout
    private lateinit var searchWrap: View

    private val controller get() = Engine.runtime.webExtensionController

    fun build(): View {
        val root = LinearLayout(act)
        root.orientation = LinearLayout.VERTICAL
        val wide = act.resources.configuration.screenWidthDp >= 600
        val side = if (wide) 24 else 14

        val head = LinearLayout(act)
        head.gravity = Gravity.CENTER_VERTICAL
        head.pad(side, 14, side, 4)
        head.addView(icon(act, R.drawable.ic_extension, 26), LinearLayout.LayoutParams(act.dp(26), act.dp(26)).apply { rightMargin = act.dp(12) })
        head.addView(text(act, "Extensions", 24f, C.INK, true))
        root.addView(head)

        tabs = LinearLayout(act)
        tabs.pad(side, 8, side, 6)
        root.addView(tabs)

        searchWrap = buildSearch(side)
        root.addView(searchWrap)

        val sv = ScrollView(act)
        sv.isVerticalScrollBarEnabled = false
        val frame = CappedFrame(act, act.dp(780))
        body = LinearLayout(act)
        body.orientation = LinearLayout.VERTICAL
        body.pad(side, 4, side, 40)
        frame.addView(body, FrameLayout.LayoutParams(-1, -2))
        sv.addView(frame, FrameLayout.LayoutParams(-1, -2, Gravity.CENTER_HORIZONTAL))
        root.addView(sv, LinearLayout.LayoutParams(-1, 0, 1f))

        drawTabs()
        show()
        return root
    }

    private fun buildSearch(side: Int): View {
        val wrap = FrameLayout(act)
        wrap.pad(side, 4, side, 6)
        val box = LinearLayout(act)
        box.gravity = Gravity.CENTER_VERTICAL
        box.background = solid(act, C.SOFT, 24f)
        box.pad(16, 0, 12, 0)
        box.addView(icon(act, R.drawable.ic_search, 20), LinearLayout.LayoutParams(act.dp(20), act.dp(20)).apply { rightMargin = act.dp(12) })
        val input = EditText(act)
        input.hint = "Search extensions"
        input.setHintTextColor(C.MUTED)
        input.setTextColor(C.INK)
        input.textSize = 16f
        input.background = null
        input.setSingleLine(true)
        input.setText(query)
        input.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, st: Int, c: Int, a: Int) {}
            override fun onTextChanged(s: CharSequence?, st: Int, b: Int, c: Int) {}
            override fun afterTextChanged(e: Editable?) {
                query = e?.toString()?.trim() ?: ""
                searchLater()
            }
        })
        box.addView(input, LinearLayout.LayoutParams(0, act.dp(46), 1f))
        wrap.addView(box, FrameLayout.LayoutParams(-1, act.dp(46)))
        return wrap
    }

    private fun drawTabs() {
        tabs.removeAllViews()
        fun chip(label: String, i: Int) {
            val on = tab == i
            val t = text(act, label, 15f, if (on) C.WHITE else C.INK, on)
            t.pad(18, 9, 18, 9)
            t.background = solid(act, if (on) C.LINK else C.SOFT, 20f)
            t.setOnClickListener {
                tab = i
                drawTabs()
                show()
            }
            tabs.addView(t, LinearLayout.LayoutParams(-2, -2).apply { rightMargin = act.dp(8) })
        }
        chip("Active", 0)
        chip("Browse", 1)
    }

    private fun show() {
        searchWrap.visibility = if (tab == 1) View.VISIBLE else View.GONE
        if (tab == 0) loadInstalled() else search()
    }

    // ---- active ------------------------------------------------------------------

    private fun loadInstalled() {
        body.removeAllViews()
        body.addView(note("Loading..."))
        try {
            controller.list().accept({ list ->
                installed = (list ?: emptyList()).sortedBy { it.metaData?.name?.lowercase(Locale.US) ?: "" }
                if (tab == 0) drawInstalled()
            }, {
                if (tab == 0) {
                    body.removeAllViews()
                    body.addView(note("Couldn't read the extensions list."))
                }
            })
        } catch (e: Exception) {
            body.removeAllViews()
            body.addView(note("Couldn't read the extensions list."))
        }
    }

    private fun drawInstalled() {
        body.removeAllViews()
        if (installed.isEmpty()) {
            body.addView(note("No extensions yet. Open Browse to add some."))
            return
        }
        for (ext in installed) body.addView(activeRow(ext), LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = act.dp(10) })
    }

    private fun activeRow(ext: WebExtension): View {
        val md = ext.metaData
        val name = md?.name ?: ext.id
        val r = rowShell()
        val img = ImageView(act)
        r.addView(img, LinearLayout.LayoutParams(act.dp(44), act.dp(44)).apply { rightMargin = act.dp(14) })
        img.background = solid(act, C.SHADE, 10f)
        try {
            md?.icon?.getBitmap(96)?.accept({ b -> if (b != null) img.setImageBitmap(b) }, { })
        } catch (e: Exception) {
            // Plain placeholder.
        }
        val col = LinearLayout(act)
        col.orientation = LinearLayout.VERTICAL
        col.addView(oneLine(text(act, name, 16f, C.INK, true)))
        val sub = (if (ext.isBuiltIn) "Built in" else "Version " + (md?.version ?: "")) + (md?.description?.let { "  ·  $it" } ?: "")
        val s = text(act, sub, 12.5f, C.MUTED)
        s.maxLines = 2
        s.ellipsize = android.text.TextUtils.TruncateAt.END
        col.addView(s, LinearLayout.LayoutParams(-2, -2).apply { topMargin = act.dp(3) })
        r.addView(col, LinearLayout.LayoutParams(0, -2, 1f))
        if (!ext.isBuiltIn) {
            val sw = Switch(act)
            sw.isChecked = md?.enabled ?: true
            sw.setOnCheckedChangeListener { _, on ->
                val result = if (on) controller.enable(ext, WebExtensionController.EnableSource.USER)
                else controller.disable(ext, WebExtensionController.EnableSource.USER)
                result.accept({ loadInstalledQuiet() }, { act.toast("Couldn't change it") })
            }
            r.addView(sw, LinearLayout.LayoutParams(-2, -2).apply { leftMargin = act.dp(8) })
            val rm = iconButton(act, R.drawable.ic_trash, 40, 40, 20, "Remove")
            rm.setOnClickListener {
                AlertDialog.Builder(act)
                    .setTitle("Remove $name?")
                    .setMessage("Its data is deleted too.")
                    .setPositiveButton("Remove") { _, _ ->
                        controller.uninstall(ext).accept({ act.toast("Removed"); loadInstalledQuiet() }, { act.toast("Couldn't remove it") })
                    }
                    .setNegativeButton("Cancel", null)
                    .show()
            }
            r.addView(rm, LinearLayout.LayoutParams(act.dp(40), act.dp(40)))
        }
        return r
    }

    private fun loadInstalledQuiet() {
        try {
            controller.list().accept({ list ->
                installed = (list ?: emptyList()).sortedBy { it.metaData?.name?.lowercase(Locale.US) ?: "" }
                if (tab == 0) drawInstalled() else drawResults()
            }, { })
        } catch (e: Exception) {
            // Keep what is shown.
        }
    }

    // ---- browse ------------------------------------------------------------------

    private fun searchLater() {
        token++
        val mine = token
        ui.postDelayed({ if (mine == token && tab == 1) search() }, 350)
    }

    private fun search() {
        status = "Loading..."
        drawResults()
        val mine = ++token
        val q = query
        // Make sure we know what is installed, so "Installed" shows on the right rows.
        loadInstalledQuiet()
        net.execute {
            val out = try {
                fetch(q)
            } catch (e: Exception) {
                null
            }
            ui.post {
                if (mine != token) return@post
                if (out == null) {
                    results = emptyList()
                    status = "Couldn't reach the add-ons site. Check your connection."
                } else {
                    results = out
                    status = if (out.isEmpty()) "No extensions found." else ""
                }
                if (tab == 1) drawResults()
            }
        }
    }

    private fun fetch(q: String): List<Listing> {
        // Only extensions that work on Android (phones and tablets), most used first.
        var u = "https://addons.mozilla.org/api/v5/addons/search/?app=android&type=extension&lang=en-US&page_size=30&sort=users"
        if (q.isNotEmpty()) u += "&q=" + URLEncoder.encode(q, "UTF-8")
        val c = URL(u).openConnection() as HttpURLConnection
        c.connectTimeout = 6000
        c.readTimeout = 8000
        c.setRequestProperty("User-Agent", "Mozilla/5.0 (Android) LiquidAir")
        val text = c.inputStream.bufferedReader().use { it.readText() }
        c.disconnect()
        val arr = JSONObject(text).optJSONArray("results") ?: return emptyList()
        val out = ArrayList<Listing>()
        for (i in 0 until arr.length()) {
            val o = arr.optJSONObject(i) ?: continue
            val xpi = o.optJSONObject("current_version")?.optJSONObject("file")?.optString("url") ?: continue
            if (!xpi.startsWith("https://")) continue
            out.add(
                Listing(
                    o.optString("guid"), localized(o.opt("name")), localized(o.opt("summary")),
                    o.optString("icon_url").ifEmpty { null }, o.optLong("average_daily_users"), xpi
                )
            )
        }
        return out
    }

    private fun localized(v: Any?): String {
        if (v is String) return v
        if (v is JSONObject) {
            val keys = v.keys()
            val en = v.optString("en-US")
            if (en.isNotEmpty()) return en
            if (keys.hasNext()) return v.optString(keys.next())
        }
        return ""
    }

    private fun drawResults() {
        body.removeAllViews()
        if (status.isNotEmpty()) body.addView(note(status))
        for (l in results) body.addView(browseRow(l), LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = act.dp(10) })
    }

    private fun browseRow(l: Listing): View {
        val r = rowShell()
        val img = ImageView(act)
        img.background = solid(act, C.SHADE, 10f)
        r.addView(img, LinearLayout.LayoutParams(act.dp(44), act.dp(44)).apply { rightMargin = act.dp(14) })
        if (l.icon != null) {
            val cached = icons.get(l.icon)
            if (cached != null) img.setImageBitmap(cached) else loadIcon(l.icon, img)
        }
        val col = LinearLayout(act)
        col.orientation = LinearLayout.VERTICAL
        col.addView(oneLine(text(act, l.name, 16f, C.INK, true)))
        val s = text(act, l.summary, 12.5f, C.MUTED)
        s.maxLines = 2
        s.ellipsize = android.text.TextUtils.TruncateAt.END
        col.addView(s, LinearLayout.LayoutParams(-2, -2).apply { topMargin = act.dp(3) })
        col.addView(text(act, users(l.users), 12f, C.MUTED), LinearLayout.LayoutParams(-2, -2).apply { topMargin = act.dp(3) })
        r.addView(col, LinearLayout.LayoutParams(0, -2, 1f))

        val have = installed.any { it.id == l.guid }
        val busy = installing.contains(l.guid)
        val btn = text(act, if (have) "Installed" else if (busy) "Adding..." else "Add", 14f, if (have || busy) C.MUTED else C.WHITE, true)
        btn.gravity = Gravity.CENTER
        btn.pad(16, 9, 16, 9)
        btn.background = solid(act, if (have || busy) C.SOFT else C.LINK, 18f)
        if (!have && !busy) btn.setOnClickListener { add(l) }
        r.addView(btn, LinearLayout.LayoutParams(-2, -2).apply { leftMargin = act.dp(10) })
        return r
    }

    private fun users(n: Long): String = when {
        n >= 1_000_000 -> String.format(Locale.US, "%.1fM users", n / 1_000_000.0)
        n >= 1000 -> "${n / 1000}K users"
        else -> "$n users"
    }

    private fun add(l: Listing) {
        installing.add(l.guid)
        drawResults()
        try {
            controller.install(l.xpi).accept({ ext ->
                installing.remove(l.guid)
                act.toast("Added " + (ext?.metaData?.name ?: l.name))
                loadInstalledQuiet()
            }, {
                installing.remove(l.guid)
                act.toast("Not added")
                if (tab == 1) drawResults()
            })
        } catch (e: Exception) {
            installing.remove(l.guid)
            act.toast("Couldn't add it")
            drawResults()
        }
    }

    // ---- bits ---------------------------------------------------------------------

    private fun rowShell(): LinearLayout {
        val r = LinearLayout(act)
        r.gravity = Gravity.CENTER_VERTICAL
        r.pad(14, 12, 14, 12)
        r.background = solid(act, C.SOFT, 16f)
        return r
    }

    private fun note(s: String): TextView {
        val t = text(act, s, 14f, C.MUTED)
        t.pad(6, 14, 6, 14)
        return t
    }

    private fun loadIcon(url: String, into: ImageView) {
        into.tag = url
        net.execute {
            try {
                val c = URL(url).openConnection() as HttpURLConnection
                c.connectTimeout = 4000
                c.readTimeout = 4000
                val bmp = c.inputStream.use { BitmapFactory.decodeStream(it) }
                c.disconnect()
                if (bmp != null) {
                    icons.put(url, bmp)
                    ui.post { if (into.tag == url) into.setImageBitmap(bmp) }
                }
            } catch (e: Exception) {
                // Placeholder stays.
            }
        }
    }
}
