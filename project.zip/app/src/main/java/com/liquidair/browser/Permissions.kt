package com.liquidair.browser

import android.Manifest
import org.mozilla.geckoview.GeckoResult
import org.mozilla.geckoview.GeckoSession

/** Site permission questions: location, camera, microphone and the Android side of them. */
class Permissions(private val act: MainActivity) {

    fun android(perms: Array<out String>?, callback: GeckoSession.PermissionDelegate.Callback) {
        val list = perms?.toList().orEmpty()
        act.askAndroid(list) { ok -> if (ok) callback.grant() else callback.reject() }
    }

    fun content(perm: GeckoSession.PermissionDelegate.ContentPermission): GeckoResult<Int>? {
        val result = GeckoResult<Int>()
        val kind = perm.permission
        return when (kind) {
            GeckoSession.PermissionDelegate.PERMISSION_GEOLOCATION -> {
                val host = Urls.hostOf(perm.uri)
                val site = Sites.location(host)
                if (site == Sites.BLOCK || (site == Sites.ASK && !act.prefs.askLocation)) {
                    return GeckoResult.fromValue(GeckoSession.PermissionDelegate.ContentPermission.VALUE_DENY)
                }
                if (site == Sites.ALLOW) {
                    return GeckoResult.fromValue(GeckoSession.PermissionDelegate.ContentPermission.VALUE_ALLOW)
                }
                val h = Urls.hostOf(perm.uri)
                act.sitePrompt.ask(h, "Use your location", R.drawable.ic_pin) { allow, remember ->
                    if (remember) Sites.setLocation(h, if (allow) Sites.ALLOW else Sites.BLOCK)
                    result.complete(
                        if (allow) GeckoSession.PermissionDelegate.ContentPermission.VALUE_ALLOW
                        else GeckoSession.PermissionDelegate.ContentPermission.VALUE_DENY
                    )
                }
                result
            }
            GeckoSession.PermissionDelegate.PERMISSION_AUTOPLAY_AUDIBLE,
            GeckoSession.PermissionDelegate.PERMISSION_AUTOPLAY_INAUDIBLE,
            GeckoSession.PermissionDelegate.PERMISSION_PERSISTENT_STORAGE,
            GeckoSession.PermissionDelegate.PERMISSION_STORAGE_ACCESS ->
                GeckoResult.fromValue(GeckoSession.PermissionDelegate.ContentPermission.VALUE_ALLOW)
            else ->
                GeckoResult.fromValue(GeckoSession.PermissionDelegate.ContentPermission.VALUE_DENY)
        }
    }

    fun media(
        uri: String,
        video: Array<out GeckoSession.PermissionDelegate.MediaSource>?,
        audio: Array<out GeckoSession.PermissionDelegate.MediaSource>?,
        callback: GeckoSession.PermissionDelegate.MediaCallback
    ) {
        val wantVideo = video != null && video.isNotEmpty()
        val wantAudio = audio != null && audio.isNotEmpty()
        val host = Urls.hostOf(uri)
        val cam = Sites.camera(host)
        val mic = Sites.mic(host)
        if ((wantVideo && cam == Sites.BLOCK) || (wantAudio && mic == Sites.BLOCK)) {
            callback.reject()
            return
        }
        val allowed = (!wantVideo || cam == Sites.ALLOW) && (!wantAudio || mic == Sites.ALLOW)
        if (!allowed && !act.prefs.askMedia) {
            callback.reject()
            return
        }
        val what = when {
            wantVideo && wantAudio -> "camera and microphone"
            wantVideo -> "camera"
            else -> "microphone"
        }
        val decide: ((Boolean) -> Unit) -> Unit = { answer ->
            if (allowed) {
                answer(true)
            } else {
                val icon = if (wantVideo) R.drawable.ic_camera else R.drawable.ic_mic
                act.sitePrompt.ask(host, "Use your $what", icon) { allow, remember ->
                    if (remember) {
                        val v = if (allow) Sites.ALLOW else Sites.BLOCK
                        if (wantVideo) Sites.setCamera(host, v)
                        if (wantAudio) Sites.setMic(host, v)
                    }
                    answer(allow)
                }
            }
        }
        decide { allow ->
            if (!allow) {
                callback.reject()
                return@decide
            }
            val needed = ArrayList<String>()
            if (wantVideo) needed.add(Manifest.permission.CAMERA)
            if (wantAudio) needed.add(Manifest.permission.RECORD_AUDIO)
            act.askAndroid(needed) { ok ->
                if (!ok) {
                    callback.reject()
                } else {
                    val v: GeckoSession.PermissionDelegate.MediaSource? = video?.firstOrNull()
                    val a: GeckoSession.PermissionDelegate.MediaSource? = audio?.firstOrNull()
                    callback.grant(v, a)
                }
            }
        }
    }
}
