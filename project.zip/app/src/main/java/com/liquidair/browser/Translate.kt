package com.liquidair.browser

import android.app.AlertDialog
import android.app.Dialog
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.Window
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.TextView
import org.mozilla.geckoview.GeckoSession
import org.mozilla.geckoview.TranslationsController
import org.mozilla.geckoview.TranslationsController.Language
import org.mozilla.geckoview.TranslationsController.SessionTranslation
import java.net.URLEncoder
import java.util.Locale

/**
 * "Translate page". The first choice is the engine's own translator: free, nothing leaves the
 * device, and a small language pack is downloaded the first time a pair is used. When that can't
 * run on this device (or fails), the same box offers Google Translate's website instead, which
 * needs a connection and sends the page address to Google.
 */
class PageTranslator(private val act: MainActivity) {

    /** Listens to a tab's session so the menu knows what the engine found on the page. */
    fun attach(tab: Tab) {
        try {
            tab.session.setTranslationsSessionDelegate(object : SessionTranslation.Delegate {
                override fun onTranslationStateChange(session: GeckoSession, translationState: SessionTranslation.TranslationState?) {
                    tab.translation = translationState
                }
            })
        } catch (e: Exception) {
            // Translating just won't be offered for this tab.
        }
    }

    /** True while the page on screen is showing a translation. */
    fun isTranslated(tab: Tab?): Boolean {
        val st = tab?.translation ?: return false
        return st.requestedTranslationPair != null && st.hasVisibleChange
    }

    fun restore(tab: Tab) {
        try {
            tab.session.sessionTranslation?.restoreOriginalPage()?.accept({
                tab.translation = null
                act.runOnUiThread { act.toast("Showing the original page") }
            }, { act.runOnUiThread { act.toast("Couldn't restore the page") } })
        } catch (e: Exception) {
            act.toast("Couldn't restore the page")
        }
    }

    fun ask(tab: Tab) {
        if (tab.home || !Urls.isWeb(tab.url)) {
            act.toast("Open a web page first")
            return
        }
        try {
            TranslationsController.RuntimeTranslation.isTranslationsEngineSupported().accept({ ok ->
                if (ok != true) act.runOnUiThread { fallback(tab, "This device can't translate on its own.") }
                else loadLanguages(tab)
            }, { act.runOnUiThread { fallback(tab, "On-device translation isn't available.") } })
        } catch (e: Exception) {
            fallback(tab, "On-device translation isn't available.")
        }
    }

    private fun loadLanguages(tab: Tab) {
        try {
            TranslationsController.RuntimeTranslation.listSupportedLanguages().accept({ support ->
                val from = (support?.fromLanguages ?: emptyList()).sortedBy { name(it).lowercase(Locale.getDefault()) }
                val to = (support?.toLanguages ?: emptyList()).sortedBy { name(it).lowercase(Locale.getDefault()) }
                act.runOnUiThread {
                    if (from.isEmpty() || to.isEmpty()) fallback(tab, "The language list hasn't loaded yet.")
                    else sheet(tab, from, to)
                }
            }, { act.runOnUiThread { fallback(tab, "The language list couldn't be loaded.") } })
        } catch (e: Exception) {
            fallback(tab, "The language list couldn't be loaded.")
        }
    }

    private fun name(l: Language): String = l.localizedDisplayName ?: l.code

    // ---- the box ----------------------------------------------------------------------------

    private fun shell(): Triple<Dialog, LinearLayout, Window?> {
        val dlg = Dialog(act)
        dlg.requestWindowFeature(Window.FEATURE_NO_TITLE)
        val card = LinearLayout(act)
        card.orientation = LinearLayout.VERTICAL
        card.pad(22, 22, 22, 18)
        card.background = solid(act, C.WHITE, 28f)
        dlg.setContentView(card)
        val w = dlg.window
        w?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        w?.setDimAmount(0.45f)
        return Triple(dlg, card, w)
    }

    private fun sizeIt(w: Window?) {
        val wide = act.resources.configuration.screenWidthDp >= 600
        val px = act.resources.displayMetrics.widthPixels
        val width = if (wide) act.dp(440) else (px * 0.92f).toInt()
        w?.setLayout(width, ViewGroup.LayoutParams.WRAP_CONTENT)
        w?.setGravity(if (wide) Gravity.CENTER else Gravity.BOTTOM)
        if (!wide) w?.attributes = w?.attributes?.also { it.y = act.dp(14) }
    }

    private fun header(card: LinearLayout, tab: Tab, title: String) {
        val row = LinearLayout(act)
        row.gravity = Gravity.CENTER_VERTICAL
        val badge = FrameLayout(act)
        badge.background = solid(act, C.MINT, 22f)
        badge.addView(icon(act, R.drawable.ic_globe, 22), FrameLayout.LayoutParams(act.dp(22), act.dp(22), Gravity.CENTER))
        row.addView(badge, lp(act.dp(44), act.dp(44)).apply { rightMargin = act.dp(14) })
        val col = LinearLayout(act)
        col.orientation = LinearLayout.VERTICAL
        col.addView(text(act, title, 20f, C.INK, true))
        col.addView(
            oneLine(text(act, Urls.hostOf(tab.url).removePrefix("www."), 13f, C.MUTED)),
            lp(-2, -2).apply { topMargin = act.dp(2) }
        )
        row.addView(col, LinearLayout.LayoutParams(0, -2, 1f))
        card.addView(row)
    }

    private fun pill(label: String, value: String): Pair<LinearLayout, TextView> {
        val p = LinearLayout(act)
        p.orientation = LinearLayout.VERTICAL
        p.pad(14, 10, 14, 11)
        p.background = withRipple(solid(act, C.SOFT, 18f), solid(act, Color.WHITE, 18f))
        p.addView(text(act, label, 11.5f, C.MUTED))
        val v = text(act, value, 16f, C.INK, true)
        v.maxLines = 1
        v.ellipsize = android.text.TextUtils.TruncateAt.END
        p.addView(v, lp(-1, -2).apply { topMargin = act.dp(2) })
        return Pair(p, v)
    }

    private fun button(label: String, primary: Boolean): TextView {
        val b = text(act, label, 15f, if (primary) C.ON_INK else C.LINK, true)
        b.gravity = Gravity.CENTER
        b.pad(22, 11, 22, 11)
        if (primary) b.background = withRipple(solid(act, C.LINK, 22f), solid(act, Color.WHITE, 22f))
        else b.background = withRipple(null)
        return b
    }

    private fun sheet(tab: Tab, from: List<Language>, to: List<Language>) {
        val (dlg, card, win) = shell()
        header(card, tab, "Translate this page")

        val detected = tab.translation?.detectedLanguages?.docLangTag
        val mine = Locale.getDefault().language
        fun find(list: List<Language>, tag: String?): Language? =
            list.firstOrNull { it.code.equals(tag, true) } ?: list.firstOrNull { it.code.substringBefore('-').equals(tag, true) }

        var src: Language? = find(from, detected) ?: find(from, "en") ?: from.first()
        var dst: Language? = find(to, mine) ?: find(to, "en") ?: to.first()
        if (src?.code == dst?.code) dst = to.firstOrNull { it.code != src?.code } ?: dst

        val (fromPill, fromText) = pill("From", name(src!!))
        val (toPill, toText) = pill("To", name(dst!!))
        val swap = text(act, "⇄", 20f, C.LINK, true)
        swap.gravity = Gravity.CENTER
        swap.background = withRipple(solid(act, C.SOFT, 20f), solid(act, Color.WHITE, 20f))

        val langs = LinearLayout(act)
        langs.gravity = Gravity.CENTER_VERTICAL
        langs.addView(fromPill, LinearLayout.LayoutParams(0, -2, 1f))
        langs.addView(swap, lp(act.dp(40), act.dp(40)).apply { leftMargin = act.dp(8); rightMargin = act.dp(8) })
        langs.addView(toPill, LinearLayout.LayoutParams(0, -2, 1f))
        card.addView(langs, lp(-1, -2).apply { topMargin = act.dp(20) })

        if (detected != null && detected.isNotEmpty() && find(from, detected) != null) {
            card.addView(
                text(act, "Detected: " + name(find(from, detected)!!), 12.5f, C.MUTED),
                lp(-2, -2).apply { topMargin = act.dp(10); leftMargin = act.dp(4) }
            )
        }

        fun choose(title: String, list: List<Language>, current: Language?, done: (Language) -> Unit) {
            val names = list.map { name(it) }.toTypedArray()
            AlertDialog.Builder(act)
                .setTitle(title)
                .setSingleChoiceItems(names, list.indexOfFirst { it.code == current?.code }) { d, i ->
                    done(list[i])
                    d.dismiss()
                }
                .show()
        }
        fromPill.setOnClickListener { choose("Translate from", from, src) { src = it; fromText.text = name(it) } }
        toPill.setOnClickListener { choose("Translate to", to, dst) { dst = it; toText.text = name(it) } }
        swap.setOnClickListener {
            val a = find(to, src?.code)
            val b = find(from, dst?.code)
            if (a != null && b != null) {
                src = b
                dst = a
                fromText.text = name(b)
                toText.text = name(a)
            }
        }

        val status = text(act, "", 13f, C.MUTED)
        status.visibility = View.GONE
        card.addView(status, lp(-1, -2).apply { topMargin = act.dp(14) })
        val bar = ProgressBar(act, null, android.R.attr.progressBarStyleHorizontal)
        bar.isIndeterminate = true
        bar.visibility = View.GONE
        card.addView(bar, lp(-1, act.dp(4)).apply { topMargin = act.dp(8) })

        val go = button("Translate", true)
        val cancel = button("Cancel", false)
        val buttons = LinearLayout(act)
        buttons.gravity = Gravity.END or Gravity.CENTER_VERTICAL
        buttons.addView(cancel)
        buttons.addView(go, lp(-2, -2).apply { leftMargin = act.dp(6) })
        card.addView(buttons, lp(-1, -2).apply { topMargin = act.dp(18) })

        val alt = text(act, "Use Google Translate instead (sends the page address to Google)", 12.5f, C.LINK)
        alt.gravity = Gravity.CENTER
        alt.pad(8, 12, 8, 6)
        card.addView(alt, lp(-1, -2))

        cancel.setOnClickListener { dlg.dismiss() }
        alt.setOnClickListener {
            dlg.dismiss()
            google(tab, dst?.code ?: mine)
        }
        go.setOnClickListener {
            val f = src?.code
            val t = dst?.code
            if (f == null || t == null || f.equals(t, true)) {
                status.visibility = View.VISIBLE
                status.setTextColor(C.MUTED)
                status.text = "Pick two different languages."
                return@setOnClickListener
            }
            go.isEnabled = false
            go.alpha = 0.5f
            bar.visibility = View.VISIBLE
            status.visibility = View.VISIBLE
            status.setTextColor(C.MUTED)
            status.text = "Translating. The first time, a language pack is downloaded, so this can take a moment."
            try {
                val options = SessionTranslation.TranslationOptions.Builder().downloadModel(true).build()
                val result = tab.session.sessionTranslation?.translate(f, t, options)
                if (result == null) {
                    failed(status, bar, go, "This page can't be translated.")
                } else {
                    result.accept({
                        act.runOnUiThread {
                            dlg.dismiss()
                            act.toast("Page translated")
                        }
                    }, { err ->
                        act.runOnUiThread {
                            failed(status, bar, go, explain(err, tab.translation?.error))
                        }
                    })
                }
            } catch (e: Exception) {
                failed(status, bar, go, "The on-device translator couldn't start.")
            }
        }

        dlg.show()
        sizeIt(win)
    }

    /** Plain words for why the on-device translator stopped. */
    private fun explain(err: Throwable?, engineError: String?): String {
        val code = (err as? TranslationsController.TranslationsException)?.code
        val why = when (code) {
            TranslationsController.TranslationsException.ERROR_ENGINE_NOT_SUPPORTED -> "This device can't run the translator."
            TranslationsController.TranslationsException.ERROR_ENGINE_DEACTIVATED -> "The translator was switched off. Try again."
            TranslationsController.TranslationsException.ERROR_LANGUAGE_NOT_SUPPORTED -> "That language pair isn't supported."
            TranslationsController.TranslationsException.ERROR_MODEL_COULD_NOT_DOWNLOAD,
            TranslationsController.TranslationsException.ERROR_MODEL_COULD_NOT_RETRIEVE,
            TranslationsController.TranslationsException.ERROR_MODEL_DOWNLOAD_REQUIRED ->
                "The language pack couldn't be downloaded. Check your connection."
            TranslationsController.TranslationsException.ERROR_COULD_NOT_TRANSLATE -> "This page couldn't be translated."
            else -> engineError ?: err?.message
        }
        return if (why.isNullOrBlank()) "The on-device translator couldn't finish." else why
    }

    private fun failed(status: TextView, bar: ProgressBar, go: TextView, msg: String) {
        bar.visibility = View.GONE
        go.isEnabled = true
        go.alpha = 1f
        status.setTextColor(0xFFD93025.toInt())
        status.text = "$msg Try again, or use Google Translate below."
    }

    /** Shown when the engine's translator can't run: the Google Translate website instead. */
    private fun fallback(tab: Tab, why: String) {
        val (dlg, card, win) = shell()
        header(card, tab, "Translate this page")
        card.addView(text(act, why, 14f, C.INK), lp(-1, -2).apply { topMargin = act.dp(16) })
        card.addView(
            text(act, "You can open this page in Google Translate instead. That needs a connection and sends the page address to Google.", 13f, C.MUTED),
            lp(-1, -2).apply { topMargin = act.dp(8) }
        )
        val go = button("Open in Google Translate", true)
        val cancel = button("Cancel", false)
        val buttons = LinearLayout(act)
        buttons.gravity = Gravity.END or Gravity.CENTER_VERTICAL
        buttons.addView(cancel)
        buttons.addView(go, lp(-2, -2).apply { leftMargin = act.dp(6) })
        card.addView(buttons, lp(-1, -2).apply { topMargin = act.dp(18) })
        cancel.setOnClickListener { dlg.dismiss() }
        go.setOnClickListener {
            dlg.dismiss()
            google(tab, Locale.getDefault().language)
        }
        dlg.show()
        sizeIt(win)
    }

    private fun google(tab: Tab, target: String) {
        var t = target.ifEmpty { "en" }
        if (t.startsWith("zh", true)) t = if (t.contains("Hant", true) || t.contains("TW", true)) "zh-TW" else "zh-CN"
        val url = "https://translate.google.com/translate?sl=auto&tl=" + URLEncoder.encode(t, "UTF-8") +
            "&u=" + URLEncoder.encode(tab.url, "UTF-8")
        act.browser.newTab(url, tab.isPrivate)
    }
}
