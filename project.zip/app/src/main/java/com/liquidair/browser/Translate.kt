package com.liquidair.browser

import android.app.AlertDialog
import android.view.View
import android.widget.ArrayAdapter
import android.widget.LinearLayout
import android.widget.Spinner
import org.mozilla.geckoview.GeckoSession
import org.mozilla.geckoview.TranslationsController
import org.mozilla.geckoview.TranslationsController.SessionTranslation
import java.util.Locale

/**
 * "Translate page", done on the device by the engine's own translator. It is free, needs no
 * account or key, and the page text never leaves the phone. The first time a language pair is used
 * its small language pack is downloaded.
 */
class PageTranslator(private val act: MainActivity) {

    /** Listens to a tab's session so the menu knows what the engine found on the page. */
    fun attach(tab: Tab) {
        try {
            tab.session.setTranslationsSessionDelegate(object : SessionTranslation.Delegate {
                override fun onTranslationStateChange(session: GeckoSession, translationState: SessionTranslation.TranslationState?) {
                    tab.translation = translationState
                }
            })
        } catch (e: Exception) {
            // Translating just won't be offered for this tab.
        }
    }

    /** True while the page on screen is showing a translation. */
    fun isTranslated(tab: Tab?): Boolean {
        val st = tab?.translation ?: return false
        return st.requestedTranslationPair != null && st.hasVisibleChange
    }

    fun restore(tab: Tab) {
        try {
            tab.session.sessionTranslation?.restoreOriginalPage()?.accept({
                tab.translation = null
                act.runOnUiThread { act.toast("Showing the original page") }
            }, { act.runOnUiThread { act.toast("Couldn't restore the page") } })
        } catch (e: Exception) {
            act.toast("Couldn't restore the page")
        }
    }

    fun ask(tab: Tab) {
        if (tab.home || !Urls.isWeb(tab.url)) {
            act.toast("Open a web page first")
            return
        }
        try {
            TranslationsController.RuntimeTranslation.isTranslationsEngineSupported().accept({ ok ->
                if (ok != true) act.runOnUiThread { act.toast("This device can't translate pages") }
                else loadLanguages(tab)
            }, { act.runOnUiThread { act.toast("Translation isn't available") } })
        } catch (e: Exception) {
            act.toast("Translation isn't available")
        }
    }

    private fun loadLanguages(tab: Tab) {
        TranslationsController.RuntimeTranslation.listSupportedLanguages().accept({ support ->
            val from = support?.fromLanguages ?: emptyList()
            val to = support?.toLanguages ?: emptyList()
            act.runOnUiThread {
                if (from.isEmpty() || to.isEmpty()) act.toast("No languages available yet. Try again with a connection.")
                else dialog(tab, from, to)
            }
        }, { act.runOnUiThread { act.toast("Couldn't load the language list") } })
    }

    private fun dialog(tab: Tab, from: List<TranslationsController.Language>, to: List<TranslationsController.Language>) {
        val detected = tab.translation?.detectedLanguages?.docLangTag
        val mine = Locale.getDefault().language

        fun spinner(list: List<TranslationsController.Language>, pick: String?): Spinner {
            val sp = Spinner(act)
            sp.adapter = ArrayAdapter(act, android.R.layout.simple_spinner_dropdown_item, list.map { it.toString() })
            val i = list.indexOfFirst { it.code.equals(pick, true) || it.code.substringBefore('-').equals(pick, true) }
            if (i >= 0) sp.setSelection(i)
            return sp
        }

        val fromSp = spinner(from, detected)
        val toSp = spinner(to, if (to.any { it.code.substringBefore('-').equals(mine, true) }) mine else "en")

        val box = LinearLayout(act)
        box.orientation = LinearLayout.VERTICAL
        box.pad(24, 12, 24, 4)
        box.addView(text(act, "Translate from", 13f, C.MUTED))
        box.addView(fromSp, lp(-1, -2))
        box.addView(text(act, "Translate to", 13f, C.MUTED).also { it.pad(0, 12, 0, 0) })
        box.addView(toSp, lp(-1, -2))
        box.addView(
            text(act, "Done on this device. The first time, a small language pack is downloaded.", 12.5f, C.MUTED)
                .also { it.pad(0, 14, 0, 0) }
        )

        AlertDialog.Builder(act)
            .setTitle("Translate page")
            .setView(box)
            .setPositiveButton("Translate") { _, _ ->
                val f = from[fromSp.selectedItemPosition].code
                val t = to[toSp.selectedItemPosition].code
                if (f.equals(t, true)) {
                    act.toast("Pick two different languages")
                } else {
                    run(tab, f, t)
                }
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun run(tab: Tab, from: String, to: String) {
        act.toast("Translating...")
        try {
            val options = SessionTranslation.TranslationOptions.Builder().downloadModel(true).build()
            tab.session.sessionTranslation?.translate(from, to, options)?.accept({
                act.runOnUiThread { act.toast("Page translated") }
            }, {
                act.runOnUiThread { act.toast("Couldn't translate this page") }
            })
        } catch (e: Exception) {
            act.toast("Couldn't translate this page")
        }
    }
}
