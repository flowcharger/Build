package com.liquidair.browser

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.View
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

/**
 * The optional overview under the start page's search bar (Settings > General > Start page
 * overview). "Wikipedia overview" shows a short summary and a picture from Wikipedia for what is
 * being typed. "AI overview" adds an Ask Perplexity button that opens perplexity.ai in the tab,
 * using the person's own account and limits. It stays hidden when the setting is Off and in
 * private tabs, so the start page looks exactly as it always did.
 */
class HomeOverview(private val act: MainActivity, host: FrameLayout) {

    private val main = Handler(Looper.getMainLooper())
    private var pending: Runnable? = null
    private var token = 0

    private val scroll = ScrollView(act)
    private val card = LinearLayout(act)

    init {
        scroll.isVerticalScrollBarEnabled = false
        scroll.visibility = View.GONE
        card.orientation = LinearLayout.VERTICAL
        card.background = solid(act, C.CARD, 22f)
        card.pad(16, 14, 16, 14)
        scroll.addView(card)
        val capped = CappedFrame(act, act.dp(580))
        capped.addView(scroll, FrameLayout.LayoutParams(-1, -2))
        host.addView(capped, FrameLayout.LayoutParams(-1, -2, Gravity.TOP or Gravity.CENTER_HORIZONTAL).apply {
            leftMargin = act.dp(24)
            rightMargin = act.dp(24)
            topMargin = act.dp(14)
        })
    }

    fun clear() {
        token++
        pending?.let { main.removeCallbacks(it) }
        pending = null
        scroll.visibility = View.GONE
        card.removeAllViews()
    }

    /** Called as the person types on the start page. */
    fun query(raw: String) {
        pending?.let { main.removeCallbacks(it) }
        val mode = act.prefs.overview
        val q = raw.trim()
        val priv = act.browser.active()?.isPrivate == true
        if (mode == 2 || priv || q.length < 3 || q.contains("://") || (!q.contains(' ') && q.contains('.'))) {
            clear()
            return
        }
        val my = ++token
        val run = Runnable { load(q, my, mode) }
        pending = run
        main.postDelayed(run, 450)
    }

    private fun open(url: String) {
        val tab = act.browser.active() ?: return
        act.browser.load(tab, url)
    }

    private fun button(label: String, primary: Boolean, action: () -> Unit): android.widget.TextView {
        val b = text(act, label, 14f, if (primary) C.ON_INK else C.INK, true)
        b.gravity = Gravity.CENTER
        b.pad(14, 0, 14, 0)
        b.background = withRipple(solid(act, if (primary) C.SKY_C else C.SOFT, 18f))
        b.setOnClickListener { action() }
        return b
    }

    private fun load(q: String, my: Int, mode: Int) {
        Thread {
            var title = ""
            var extract = ""
            var page = ""
            var thumb: Bitmap? = null
            try {
                val api = "https://en.wikipedia.org/w/api.php?action=query&format=json&redirects=1" +
                    "&generator=search&gsrlimit=1&gsrsearch=" + Uri.encode(q) +
                    "&prop=extracts%7Cpageimages%7Cinfo&exintro=1&explaintext=1&exsentences=4" +
                    "&piprop=thumbnail&pithumbsize=300&inprop=url"
                val json = JSONObject(get(api))
                val pages = json.optJSONObject("query")?.optJSONObject("pages")
                var first: JSONObject? = null
                if (pages != null) {
                    val names = pages.keys()
                    if (names.hasNext()) first = pages.optJSONObject(names.next())
                }
                if (first != null) {
                    title = first.optString("title")
                    extract = first.optString("extract")
                    page = first.optString("fullurl")
                    val src = first.optJSONObject("thumbnail")?.optString("source") ?: ""
                    if (src.startsWith("https://")) {
                        val bytes = getBytes(src)
                        thumb = BitmapFactory.decodeByteArray(bytes, 0, bytes.size)
                    }
                }
            } catch (e: Exception) {
                // No network or no answer: the card just shows what it has.
            }
            main.post {
                if (my == token) show(q, mode, title, extract, page, thumb)
            }
        }.start()
    }

    private fun show(q: String, mode: Int, title: String, extract: String, page: String, thumb: Bitmap?) {
        card.removeAllViews()
        val haveWiki = title.isNotEmpty() && extract.isNotEmpty()
        if (!haveWiki && mode != 1) {
            scroll.visibility = View.GONE
            return
        }
        if (haveWiki) {
            card.addView(text(act, "OVERVIEW · WIKIPEDIA", 11.5f, C.SKY_C, true))
            card.addView(text(act, title, 18f, C.INK, true), LinearLayout.LayoutParams(-2, -2).apply { topMargin = act.dp(4) })
            val row = LinearLayout(act)
            row.gravity = Gravity.TOP
            if (thumb != null) {
                val img = ImageView(act)
                img.setImageBitmap(thumb)
                img.scaleType = ImageView.ScaleType.CENTER_CROP
                img.background = solid(act, C.SOFT, 14f)
                img.clipToOutline = true
                row.addView(img, LinearLayout.LayoutParams(act.dp(84), act.dp(84)).apply { rightMargin = act.dp(12) })
            }
            row.addView(text(act, extract, 14.5f, C.INK), LinearLayout.LayoutParams(0, -2, 1f))
            card.addView(row, LinearLayout.LayoutParams(-1, -2).apply { topMargin = act.dp(8) })
        }
        val buttons = LinearLayout(act)
        buttons.gravity = Gravity.CENTER_VERTICAL
        if (haveWiki && page.isNotEmpty()) {
            buttons.addView(button("Read on Wikipedia", mode != 1) { open(page) }, LinearLayout.LayoutParams(-2, act.dp(36)))
        }
        if (mode == 1) {
            buttons.addView(
                button("Ask Perplexity", true) { open("https://www.perplexity.ai/search?q=" + Uri.encode(q)) },
                LinearLayout.LayoutParams(-2, act.dp(36)).apply { leftMargin = if (haveWiki) act.dp(10) else 0 }
            )
        }
        card.addView(buttons, LinearLayout.LayoutParams(-2, -2).apply { topMargin = act.dp(12) })
        scroll.visibility = View.VISIBLE
        scroll.arrive(0f, 6f, .98f, 180)
    }

    private fun get(url: String): String = String(getBytes(url), Charsets.UTF_8)

    private fun getBytes(url: String): ByteArray {
        val c = URL(url).openConnection() as HttpURLConnection
        c.connectTimeout = 5000
        c.readTimeout = 6000
        c.setRequestProperty("User-Agent", "LiquidAir/2.0 (Android browser start page)")
        try {
            return c.inputStream.use { it.readBytes() }
        } finally {
            c.disconnect()
        }
    }
}
