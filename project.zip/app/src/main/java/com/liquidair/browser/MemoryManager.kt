package com.liquidair.browser

import android.app.ActivityManager
import android.content.Context
import android.os.Handler
import android.os.Looper

/**
 * The memory limit from Settings. While the browser is on screen it checks, every few seconds, how
 * much memory Liquid Air and its page engine are using. Over the limit, it puts the tab that has been
 * unused the longest to sleep (the page reloads when the tab is opened again). The tab on screen and
 * any tab playing sound are never put to sleep.
 */
object MemoryManager {
    const val STEP_MB = 128
    const val MIN_MB = 512

    private val main = Handler(Looper.getMainLooper())
    private var act: MainActivity? = null
    private var running = false
    private var lastCacheClear = 0L

    private val tick = object : Runnable {
        override fun run() {
            if (!running) return
            enforce()
            main.postDelayed(this, 4000)
        }
    }

    fun start(a: MainActivity) {
        act = a
        if (running) return
        running = true
        main.postDelayed(tick, 4000)
    }

    fun stop() {
        running = false
        main.removeCallbacks(tick)
        act = null
    }

    fun deviceTotalMb(ctx: Context): Int {
        val am = ctx.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        val info = ActivityManager.MemoryInfo()
        am.getMemoryInfo(info)
        return (info.totalMem / 1048576L).toInt()
    }

    /** The most the limit can be set to: 60% of the device's memory, so Android and other apps keep room. */
    fun maxLimitMb(ctx: Context): Int {
        val cap = (deviceTotalMb(ctx) * 0.6).toInt() / STEP_MB * STEP_MB
        return maxOf(MIN_MB + STEP_MB, cap)
    }

    /** The saved limit, kept inside what this device allows. */
    fun limitMb(ctx: Context, prefs: Prefs): Int {
        val v = prefs.ramLimitMb / STEP_MB * STEP_MB
        return v.coerceIn(MIN_MB, maxLimitMb(ctx))
    }

    /** What Liquid Air uses right now, page-engine processes included, in megabytes. */
    fun usedMb(ctx: Context): Int {
        return try {
            val am = ctx.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
            val pkg = ctx.packageName
            val pids = am.runningAppProcesses
                ?.filter { it.processName == pkg || it.processName.startsWith("$pkg:") }
                ?.map { it.pid }
                ?.toIntArray()
            if (pids == null || pids.isEmpty()) return 0
            var kb = 0L
            for (info in am.getProcessMemoryInfo(pids)) kb += info.totalPss
            (kb / 1024L).toInt()
        } catch (e: Exception) {
            0
        }
    }

    /** Brings use back under the limit, one sleeping tab at a time. Safe to call at any moment. */
    fun enforce() {
        val a = act ?: return
        if (!a.prefs.ramLimitOn) return
        val limit = limitMb(a, a.prefs)
        if (usedMb(a) <= limit) return
        if (a.browser.suspendLeastRecent()) return
        // Nothing left to put to sleep: at least empty the page caches (not more than once a minute).
        val now = System.currentTimeMillis()
        if (now - lastCacheClear > 60_000L) {
            lastCacheClear = now
            Engine.clearData(cookiesAndSites = false, caches = true)
        }
    }

    /** "Free memory now": puts every background tab to sleep and empties the caches. */
    fun freeNow() {
        val a = act ?: return
        a.browser.trimBackgroundTabs(0)
        Engine.clearData(cookiesAndSites = false, caches = true)
    }
}
