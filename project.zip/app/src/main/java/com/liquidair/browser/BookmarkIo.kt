package com.liquidair.browser

/**
 * Bookmarks as a ".html" file in the Netscape bookmark format. Chrome, Brave, Edge, Firefox and
 * Safari all export and import exactly this, so it moves bookmarks in or out of Liquid Air.
 */
object BookmarkIo {

    fun toHtml(list: List<Saved>): String {
        val now = System.currentTimeMillis() / 1000
        val sb = StringBuilder()
        sb.append("<!DOCTYPE NETSCAPE-Bookmark-file-1>\n")
        sb.append("<!-- This is an automatically generated file. It will be read and overwritten. DO NOT EDIT! -->\n")
        sb.append("<META HTTP-EQUIV=\"Content-Type\" CONTENT=\"text/html; charset=UTF-8\">\n")
        sb.append("<TITLE>Bookmarks</TITLE>\n<H1>Bookmarks</H1>\n<DL><p>\n")
        sb.append("    <DT><H3 ADD_DATE=\"").append(now).append("\" LAST_MODIFIED=\"").append(now)
            .append("\" PERSONAL_TOOLBAR_FOLDER=\"true\">Liquid Air</H3>\n    <DL><p>\n")
        for (b in list) {
            val title = b.title.ifBlank { Urls.display(b.url) }
            sb.append("        <DT><A HREF=\"").append(escape(b.url)).append("\" ADD_DATE=\"")
                .append(b.time / 1000).append("\">").append(escape(title)).append("</A>\n")
        }
        sb.append("    </DL><p>\n</DL><p>\n")
        return sb.toString()
    }

    /** Every web link in a bookmarks file, in order. Folders are flattened. */
    fun parse(html: String): List<Saved> {
        val out = ArrayList<Saved>()
        val seen = HashSet<String>()
        val link = Regex("<a\\s([^>]*)>(.*?)</a>", setOf(RegexOption.IGNORE_CASE, RegexOption.DOT_MATCHES_ALL))
        val href = Regex("href\\s*=\\s*(?:\"([^\"]*)\"|'([^']*)')", RegexOption.IGNORE_CASE)
        val added = Regex("add_date\\s*=\\s*\"?(\\d+)\"?", RegexOption.IGNORE_CASE)
        val tags = Regex("<[^>]*>")
        for (m in link.findAll(html)) {
            val attrs = m.groupValues[1]
            val h = href.find(attrs) ?: continue
            val url = unescape(h.groupValues[1].ifEmpty { h.groupValues[2] }).trim()
            if (!Urls.isWeb(url) || !seen.add(url)) continue
            val title = unescape(tags.replace(m.groupValues[2], "")).trim().replace(Regex("\\s+"), " ")
            val secs = added.find(attrs)?.groupValues?.get(1)?.toLongOrNull() ?: 0L
            out.add(Saved(title.ifEmpty { Urls.display(url) }, url, if (secs > 0) secs * 1000 else System.currentTimeMillis()))
        }
        return out
    }

    private fun escape(s: String) = s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;").replace("\"", "&quot;")

    private fun unescape(s: String): String {
        var t = Regex("&#(\\d+);").replace(s) { m -> m.groupValues[1].toIntOrNull()?.takeIf { it in 1..0x10FFFF }?.let { String(Character.toChars(it)) } ?: m.value }
        t = Regex("&#[xX]([0-9a-fA-F]+);").replace(t) { m -> m.groupValues[1].toIntOrNull(16)?.takeIf { it in 1..0x10FFFF }?.let { String(Character.toChars(it)) } ?: m.value }
        return t.replace("&lt;", "<").replace("&gt;", ">").replace("&quot;", "\"").replace("&apos;", "'").replace("&amp;", "&")
    }
}
