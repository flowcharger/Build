package com.liquidair.browser

import android.net.Uri
import org.json.JSONArray
import org.json.JSONObject

/**
 * Moves what a person exported from another browser into Liquid Air. Any mix of files can be
 * chosen at once; each one is recognised by what is inside it:
 *  - bookmarks as .html (Chrome, Brave, Edge, Firefox, Safari, Google Takeout), or Chrome's and
 *    Firefox's .json bookmark files
 *  - passwords as .csv (Chrome, Brave, Edge, Firefox, Bitwarden, 1Password, LastPass)
 *  - history as Google Takeout's History.json, or a .csv / .json list of pages
 */
object BrowserImport {

    private class Parsed {
        val bookmarks = ArrayList<Saved>()
        val history = ArrayList<Saved>()
        val passwordFiles = ArrayList<String>()
        var skipped = 0
    }

    fun run(act: MainActivity, uris: List<Uri>, done: () -> Unit) {
        act.toast("Reading ${uris.size} file${if (uris.size == 1) "" else "s"}...")
        Thread {
            val parsed = Parsed()
            for (u in uris) {
                val text = read(act, u)
                if (text == null) parsed.skipped++ else sort(text, parsed)
            }
            act.runOnUiThread { merge(act, parsed, done) }
        }.start()
    }

    private fun read(act: MainActivity, uri: Uri): String? = try {
        act.contentResolver.openInputStream(uri)?.use { s ->
            val bytes = s.readBytes()
            if (bytes.size > 60000000) null else String(bytes, Charsets.UTF_8).removePrefix("﻿")
        }
    } catch (e: Exception) {
        null
    }

    private fun sort(text: String, out: Parsed) {
        val t = text.trimStart()
        try {
            when {
                t.startsWith("{") -> json(JSONObject(t), out)
                t.startsWith("[") -> jsonList(JSONArray(t), out)
                t.contains("<a ", true) && t.contains("href", true) -> {
                    val list = BookmarkIo.parse(text)
                    if (list.isEmpty()) out.skipped++ else out.bookmarks.addAll(list)
                }
                else -> csv(text, out)
            }
        } catch (e: Exception) {
            out.skipped++
        }
    }

    // ---- JSON ----

    private fun json(o: JSONObject, out: Parsed) {
        val visits = o.optJSONArray("Browser History")
        if (visits != null) {
            for (i in 0 until visits.length()) {
                val v = visits.optJSONObject(i) ?: continue
                val url = v.optString("url")
                if (!Urls.isWeb(url)) continue
                val ms = v.optLong("time_usec", 0L) / 1000L
                out.history.add(Saved(v.optString("title").ifBlank { Urls.display(url) }, url, if (ms > 0) ms else System.currentTimeMillis()))
            }
            return
        }
        val before = out.bookmarks.size
        walk(o, out.bookmarks, HashSet())
        if (out.bookmarks.size == before) out.skipped++
    }

    private fun jsonList(a: JSONArray, out: Parsed) {
        val first = a.optJSONObject(0)
        val isHistory = first != null && (first.has("lastVisitTime") || first.has("visitTime") || first.has("visit_time"))
        if (isHistory) {
            for (i in 0 until a.length()) {
                val v = a.optJSONObject(i) ?: continue
                val url = v.optString("url")
                if (!Urls.isWeb(url)) continue
                val t = when {
                    v.has("lastVisitTime") -> v.optDouble("lastVisitTime", 0.0).toLong()
                    v.has("visitTime") -> v.optDouble("visitTime", 0.0).toLong()
                    else -> 0L
                }
                out.history.add(Saved(v.optString("title").ifBlank { Urls.display(url) }, url, if (t > 0) t else System.currentTimeMillis()))
            }
            return
        }
        val before = out.bookmarks.size
        walk(a, out.bookmarks, HashSet())
        if (out.bookmarks.size == before) out.skipped++
    }

    /** Finds every web link in Chrome's "Bookmarks" file or a Firefox bookmark backup. */
    private fun walk(node: Any?, out: ArrayList<Saved>, seen: HashSet<String>) {
        when (node) {
            is JSONObject -> {
                val url = node.optString("url").ifEmpty { node.optString("uri") }
                if (Urls.isWeb(url) && seen.add(url)) {
                    val title = node.optString("name").ifEmpty { node.optString("title") }
                    out.add(Saved(title.ifBlank { Urls.display(url) }, url, System.currentTimeMillis()))
                }
                val names = node.keys()
                while (names.hasNext()) {
                    val k = names.next()
                    val child = node.opt(k)
                    if (child is JSONObject || child is JSONArray) walk(child, out, seen)
                }
            }
            is JSONArray -> for (i in 0 until node.length()) walk(node.opt(i), out, seen)
        }
    }

    // ---- CSV ----

    private fun csv(text: String, out: Parsed) {
        val head = text.lineSequence().firstOrNull { it.isNotBlank() }?.lowercase() ?: run { out.skipped++; return }
        when {
            head.contains("password") -> out.passwordFiles.add(text)
            head.contains("url") || head.contains("address") -> {
                // A plain list of pages: first column that looks like a link on each row.
                val link = Regex("https?://[^\\s,\"']+")
                var n = 0
                for (line in text.lineSequence().drop(1)) {
                    val m = link.find(line) ?: continue
                    val url = m.value
                    val title = line.substringBefore(url).trim().trim(',', '"').ifBlank { Urls.display(url) }
                    out.history.add(Saved(title, url, System.currentTimeMillis() - n * 1000L))
                    n++
                }
                if (n == 0) out.skipped++
            }
            else -> out.skipped++
        }
    }

    // ---- put it all in ----

    private fun merge(act: MainActivity, p: Parsed, done: () -> Unit) {
        val b = act.browser
        val haveMarks = b.bookmarks.map { it.url }.toHashSet()
        val newMarks = p.bookmarks.filter { haveMarks.add(it.url) }
        if (newMarks.isNotEmpty()) {
            b.bookmarks.addAll(newMarks)
            b.saveBookmarks()
        }
        val haveHist = b.history.map { it.url }.toHashSet()
        val newHist = p.history.filter { haveHist.add(it.url) }
        if (newHist.isNotEmpty()) {
            b.history.addAll(newHist)
            b.history.sortByDescending { it.time }
            while (b.history.size > 3000) b.history.removeAt(b.history.size - 1)
            b.saveHistory()
        }
        var pass = 0
        for (c in p.passwordFiles) pass += act.vault.importCsv(c)

        val parts = ArrayList<String>()
        if (newMarks.isNotEmpty()) parts.add("${newMarks.size} bookmarks")
        if (pass > 0) parts.add("$pass passwords")
        if (newHist.isNotEmpty()) parts.add("${newHist.size} history entries")
        val msg = if (parts.isEmpty()) "Nothing new found in those files."
        else "Imported " + parts.joinToString(", ")
        act.toast(if (p.skipped > 0) "$msg ${p.skipped} file(s) weren't recognised." else msg)
        done()
    }
}
