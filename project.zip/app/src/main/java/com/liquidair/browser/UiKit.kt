package com.liquidair.browser

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.ColorFilter
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PixelFormat
import android.graphics.RadialGradient
import android.graphics.Rect
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.Typeface
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.RippleDrawable
import android.content.res.ColorStateList
import android.text.TextUtils
import android.util.TypedValue
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import kotlin.math.max

/** Colours used everywhere. They follow the system light/dark setting (see MainActivity.applyTheme). */
object C {
    var dark = false
    private fun pick(light: Int, night: Int) = if (dark) night else light

    val INK get() = pick(0xFF1B1F1D.toInt(), 0xFFEDF1EE.toInt())
    val ON_INK get() = pick(0xFFFFFFFF.toInt(), 0xFF111513.toInt())
    val MUTED get() = pick(0xFF67716B.toInt(), 0xFFA3ADA7.toInt())
    val LINE get() = pick(0x1A18221C, 0x26FFFFFF)
    /** Solid surface colour (panels, active tab, cards). */
    val WHITE get() = pick(0xFFFFFFFF.toInt(), 0xFF343B38.toInt())
    val SOFT get() = pick(0xFFF2F4F2.toInt(), 0xFF272D2A.toInt())
    val BG get() = pick(0xFFF4F2E9.toInt(), 0xFF101412.toInt())
    val MINT get() = pick(0xFFCFEEDD.toInt(), 0xFF2C4A3A.toInt())
    val GLASS get() = pick(0x4DFFFFFF, 0x8C1C2220.toInt())
    val GLASS_EDGE get() = pick(0x9EFFFFFF.toInt(), 0x40FFFFFF)
    val FIELD get() = pick(0x42FFFFFF, 0xCC2A312F.toInt())
    val BAR get() = pick(0x38FFFFFF, 0x26FFFFFF)
    val HINT get() = pick(0xFF58635C.toInt(), 0xFF9AA59F.toInt())
    val CARD get() = pick(0x99FFFFFF.toInt(), 0x40FFFFFF)
    val SHADE get() = pick(0x14000000, 0x1FFFFFFF)
    val RIPPLE get() = pick(0x22000000, 0x33FFFFFF)
    val EDGE_DARK get() = pick(0x33000000, 0x33FFFFFF)
    const val SKY_A = 0xFF5FC4FF.toInt()
    const val SKY_B = 0xFFC4ECFF.toInt()
    const val SKY_C = 0xFF3D9CF5.toInt()
}

/** True when the system is currently in dark mode. */
fun Context.systemIsDark(): Boolean =
    (resources.configuration.uiMode and android.content.res.Configuration.UI_MODE_NIGHT_MASK) ==
        android.content.res.Configuration.UI_MODE_NIGHT_YES

fun Context.dp(v: Int): Int = (v * resources.displayMetrics.density + 0.5f).toInt()
fun Context.dpf(v: Float): Float = v * resources.displayMetrics.density

/** The frosted "liquid glass" look: a see-through white fill with a bright edge. */
fun glass(ctx: Context, radiusDp: Float, fill: Int = C.GLASS, edge: Int = C.GLASS_EDGE): GradientDrawable {
    // Lighter at the top, like light catching the curve of the glass.
    return GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, intArrayOf(lift(fill), fill)).apply {
        cornerRadius = ctx.dpf(radiusDp)
        setStroke(max(1, ctx.dp(1)), edge)
    }
}

private fun lift(c: Int): Int {
    val a = minOf(255, (Color.alpha(c) * 1.45f).toInt() + 10)
    val r = Color.red(c) + ((255 - Color.red(c)) * 0.3f).toInt()
    val g = Color.green(c) + ((255 - Color.green(c)) * 0.3f).toInt()
    val b = Color.blue(c) + ((255 - Color.blue(c)) * 0.3f).toInt()
    return Color.argb(a, r, g, b)
}

/** The big frosted bar on the start page: bright glass with a soft green glow. */
fun liquidBar(ctx: Context, radiusDp: Float): GradientDrawable {
    val colors = if (C.dark) intArrayOf(0x4DFFFFFF, 0x26FFFFFF)
    else intArrayOf(0x73FFFFFF, 0x40FFFFFF)
    return GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, colors).apply {
        cornerRadius = ctx.dpf(radiusDp)
        setStroke(max(1, ctx.dp(1)), if (C.dark) 0x66FFFFFF else 0x80FFFFFF.toInt())
    }
}

/** A frame that never grows wider than [maxWidthPx]; the parent centres it. */
class CappedFrame(ctx: Context, private val maxWidthPx: Int) : FrameLayout(ctx) {
    override fun onMeasure(widthSpec: Int, heightSpec: Int) {
        val w = View.MeasureSpec.getSize(widthSpec)
        val capped = if (w > maxWidthPx) View.MeasureSpec.makeMeasureSpec(maxWidthPx, View.MeasureSpec.EXACTLY) else widthSpec
        super.onMeasure(capped, heightSpec)
    }
}

fun solid(ctx: Context, color: Int, radiusDp: Float): GradientDrawable {
    return GradientDrawable().apply {
        cornerRadius = ctx.dpf(radiusDp)
        setColor(color)
    }
}

/** Adds a soft touch ripple on top of any background. */
fun withRipple(bg: Drawable?, mask: Drawable? = null): Drawable {
    return RippleDrawable(ColorStateList.valueOf(C.RIPPLE), bg, mask ?: if (bg == null) ColorDrawable(Color.WHITE) else null)
}

fun lp(w: Int, h: Int): LinearLayout.LayoutParams = LinearLayout.LayoutParams(w, h)

fun icon(ctx: Context, res: Int, sizeDp: Int): ImageView {
    return ImageView(ctx).apply {
        setImageResource(res)
        imageTintList = ColorStateList.valueOf(C.INK)
        scaleType = ImageView.ScaleType.FIT_CENTER
        layoutParams = ViewGroup.LayoutParams(ctx.dp(sizeDp), ctx.dp(sizeDp))
    }
}

/** A square touch target holding an icon. */
fun iconButton(ctx: Context, res: Int, boxW: Int, boxH: Int, iconDp: Int, desc: String): FrameLayout {
    val box = FrameLayout(ctx)
    box.layoutParams = LinearLayout.LayoutParams(ctx.dp(boxW), ctx.dp(boxH))
    val img = icon(ctx, res, iconDp)
    img.layoutParams = FrameLayout.LayoutParams(ctx.dp(iconDp), ctx.dp(iconDp), Gravity.CENTER)
    box.addView(img)
    box.contentDescription = desc
    box.isClickable = true
    box.background = RippleDrawable(
        ColorStateList.valueOf(if (C.dark) 0x33FFFFFF else 0x8CFFFFFF.toInt()),
        null, solid(ctx, Color.WHITE, 14f)
    )
    // Gentle press: the button shrinks a little while a finger is on it.
    box.setOnTouchListener { v, e ->
        when (e.actionMasked) {
            android.view.MotionEvent.ACTION_DOWN ->
                if (v.isEnabled) v.animate().scaleX(.9f).scaleY(.9f).setDuration(120).start()
            android.view.MotionEvent.ACTION_UP, android.view.MotionEvent.ACTION_CANCEL ->
                v.animate().scaleX(1f).scaleY(1f).setDuration(120).start()
        }
        false
    }
    return box
}

fun FrameLayout.iconView(): ImageView = getChildAt(0) as ImageView

fun text(ctx: Context, s: String, sp: Float, color: Int = C.INK, bold: Boolean = false): TextView {
    return TextView(ctx).apply {
        text = s
        setTextSize(TypedValue.COMPLEX_UNIT_SP, sp)
        setTextColor(color)
        if (bold) typeface = Typeface.DEFAULT_BOLD
        includeFontPadding = false
    }
}

fun oneLine(tv: TextView): TextView {
    tv.maxLines = 1
    tv.ellipsize = TextUtils.TruncateAt.END
    return tv
}

fun View.pad(l: Int, t: Int, r: Int, b: Int) {
    setPadding(context.dp(l), context.dp(t), context.dp(r), context.dp(b))
}

/** Sky-blue gradient ring: draws a gradient, the card sits inside with a small margin. */
fun skyRing(ctx: Context, radiusDp: Float): GradientDrawable {
    return GradientDrawable(
        GradientDrawable.Orientation.TL_BR,
        intArrayOf(C.SKY_A, C.SKY_B, C.SKY_C)
    ).apply { cornerRadius = ctx.dpf(radiusDp) }
}

/** Slides and fades a view in, the way pages and menus arrive. */
fun View.arrive(dxDp: Float = 0f, dyDp: Float = 0f, fromScale: Float = 1f, ms: Long = 280) {
    alpha = 0f
    translationX = context.dpf(dxDp)
    translationY = context.dpf(dyDp)
    scaleX = fromScale
    scaleY = fromScale
    animate().alpha(1f).translationX(0f).translationY(0f).scaleX(1f).scaleY(1f)
        .setDuration(ms).setInterpolator(android.view.animation.DecelerateInterpolator()).start()
}

/** A thin sky-blue gradient outline (the blue ring around the tab count box). */
class RingDrawable(private val ctx: Context, private val radiusDp: Float, private val widthDp: Float) : Drawable() {
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE }
    override fun draw(canvas: Canvas) {
        val b = bounds
        if (b.width() <= 0) return
        val w = ctx.dpf(widthDp)
        paint.strokeWidth = w
        paint.shader = LinearGradient(
            b.left.toFloat(), b.top.toFloat(), b.right.toFloat(), b.bottom.toFloat(),
            intArrayOf(C.SKY_A, C.SKY_B, C.SKY_C), floatArrayOf(0f, .5f, 1f), Shader.TileMode.CLAMP
        )
        val r = RectF(b.left + w / 2f, b.top + w / 2f, b.right - w / 2f, b.bottom - w / 2f)
        val rad = ctx.dpf(radiusDp)
        canvas.drawRoundRect(r, rad, rad, paint)
    }
    override fun setAlpha(alpha: Int) {}
    override fun setColorFilter(colorFilter: ColorFilter?) {}
    @Suppress("OVERRIDE_DEPRECATION")
    override fun getOpacity(): Int = PixelFormat.TRANSLUCENT
}

/** Smooth value animation helper. */
fun animate(durationMs: Long, from: Float, to: Float, onValue: (Float) -> Unit): ValueAnimator {
    return ValueAnimator.ofFloat(from, to).apply {
        duration = durationMs
        addUpdateListener { onValue(it.animatedValue as Float) }
        start()
    }
}

/**
 * The Liquid Air picture: pale sky, a low sun and layered green hills. Drawn with
 * paths, so it costs almost nothing and stays sharp on any screen.
 */
class ArtDrawable(private val ctx: Context) : Drawable() {
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val hills = arrayOf(
        "M0 560 C170 470 330 520 520 450 C720 380 860 470 1040 420 C1240 365 1420 440 1600 380 L1600 1000 L0 1000Z" to intArrayOf(0xFFCFDCC9.toInt(), 0xFFDFE8D9.toInt()),
        "M0 640 C190 560 360 620 560 560 C760 500 900 590 1100 540 C1290 495 1450 560 1600 520 L1600 1000 L0 1000Z" to intArrayOf(0xFFB5CCB0.toInt(), 0xFFC9DAC3.toInt()),
        "M0 730 C160 660 330 720 540 670 C740 622 900 700 1090 660 C1290 618 1440 690 1600 650 L1600 1000 L0 1000Z" to intArrayOf(0xFF98B996.toInt(), 0xFFB0C9AC.toInt()),
        "M0 810 C200 750 380 800 600 765 C820 730 960 800 1180 770 C1360 745 1490 790 1600 760 L1600 1000 L0 1000Z" to intArrayOf(0xFF7EA282.toInt(), 0xFF97B698.toInt()),
        "M0 900 C230 850 430 890 680 865 C900 842 1060 895 1280 872 C1430 856 1530 880 1600 866 L1600 1000 L0 1000Z" to intArrayOf(0xFF628A6C.toInt(), 0xFF7A9F80.toInt())
    ).map { (d, colors) -> parse(d) to colors }

    private val ridges = arrayOf(
        "M40 748 C200 690 330 735 540 690",
        "M690 668 C820 650 930 700 1090 676",
        "M60 826 C240 780 390 818 600 788",
        "M760 760 C900 752 1000 800 1180 788"
    ).map { parse(it) }

    private val stars = arrayOf(
        floatArrayOf(330f, 190f, 2f), floatArrayOf(560f, 250f, 1.5f), floatArrayOf(760f, 210f, 2.2f),
        floatArrayOf(940f, 290f, 1.5f), floatArrayOf(1330f, 200f, 2f), floatArrayOf(1480f, 270f, 1.5f),
        floatArrayOf(150f, 300f, 1.6f), floatArrayOf(1020f, 180f, 1.6f)
    )

    /** Reads the simple absolute M/C/L/Z path strings used above. */
    private fun parse(d: String): Path {
        val path = Path()
        val tokens = Regex("[MCLZ]|-?\\d+(?:\\.\\d+)?").findAll(d).map { it.value }.toList()
        var i = 0
        fun num(): Float = tokens[i++].toFloat()
        while (i < tokens.size) {
            when (tokens[i++]) {
                "M" -> path.moveTo(num(), num())
                "L" -> path.lineTo(num(), num())
                "C" -> {
                    val a = num(); val b = num(); val c = num(); val e = num(); val f = num(); val g = num()
                    path.cubicTo(a, b, c, e, f, g)
                }
                "Z" -> path.close()
            }
        }
        return path
    }

    override fun draw(canvas: Canvas) {
        val b: Rect = bounds
        val w = b.width().toFloat()
        val h = b.height().toFloat()
        if (w <= 0f || h <= 0f) return

        val night = C.dark
        // Sky.
        val sky = if (night) intArrayOf(0xFF0B101A.toInt(), 0xFF111A27.toInt(), 0xFF18242C.toInt())
        else intArrayOf(0xFFF6F3EA.toInt(), 0xFFEEF1E6.toInt(), 0xFFE3EBDD.toInt())
        paint.shader = LinearGradient(0f, 0f, 0f, h, sky, floatArrayOf(0f, .55f, 1f), Shader.TileMode.CLAMP)
        canvas.drawRect(0f, 0f, w, h, paint)
        paint.shader = null

        // "xMidYMid slice": scale to cover, centred.
        val scale = max(w / 1600f, h / 1000f)
        val dx = (w - 1600f * scale) / 2f
        val dy = (h - 1000f * scale) / 2f
        canvas.save()
        canvas.translate(dx, dy)
        canvas.scale(scale, scale)

        val glow = if (night) intArrayOf(0x40BFD2FF, 0x1F9FB8F0, 0x009FB8F0)
        else intArrayOf(0xF2FFFBE9.toInt(), 0x8CFBF1D3.toInt(), 0x00FBF1D3)
        paint.shader = RadialGradient(1130f, 330f, 260f, glow, floatArrayOf(0f, .6f, 1f), Shader.TileMode.CLAMP)
        canvas.drawCircle(1130f, 330f, 260f, paint)
        paint.shader = null
        paint.color = if (night) 0xFFE6EDF7.toInt() else 0xE6FFFAF0.toInt()
        canvas.drawCircle(1130f, 330f, if (night) 48f else 62f, paint)
        if (night) {
            paint.color = 0x8CFFFFFF.toInt()
            for (st in stars) canvas.drawCircle(st[0], st[1], st[2], paint)
        }

        paint.color = if (night) 0x14FFFFFF else 0x99FFFFFF.toInt()
        canvas.drawOval(160f, 224f, 500f, 276f, paint)
        canvas.drawOval(320f, 202f, 540f, 250f, paint)
        canvas.drawOval(620f, 150f, 900f, 190f, paint)
        canvas.drawOval(1290f, 190f, 1550f, 230f, paint)

        for ((path, colors) in hills) {
            val top = pathTop(path)
            val c0 = if (night) nightShade(colors[0]) else colors[0]
            val c1 = if (night) nightShade(colors[1]) else colors[1]
            paint.shader = LinearGradient(0f, top, 0f, 1000f, c0, c1, Shader.TileMode.CLAMP)
            canvas.drawPath(path, paint)
        }
        paint.shader = null
        paint.style = Paint.Style.STROKE
        paint.strokeWidth = 3f
        paint.strokeCap = Paint.Cap.ROUND
        paint.color = if (night) 0x1FFFFFFF else 0x59FFFFFF
        for (r in ridges) canvas.drawPath(r, paint)
        paint.style = Paint.Style.FILL
        canvas.restore()
    }

    /** Darkens a hill colour for the night picture. */
    private fun nightShade(c: Int): Int {
        val r = (Color.red(c) * 0.22f).toInt()
        val g = (Color.green(c) * 0.30f).toInt()
        val b = (Color.blue(c) * 0.26f).toInt()
        return Color.rgb(r, g + 6, b + 4)
    }

    private fun pathTop(p: Path): Float {
        val r = android.graphics.RectF()
        p.computeBounds(r, true)
        return r.top
    }

    override fun setAlpha(alpha: Int) {}
    override fun setColorFilter(colorFilter: ColorFilter?) {}
    @Suppress("OVERRIDE_DEPRECATION")
    override fun getOpacity(): Int = PixelFormat.OPAQUE
}
