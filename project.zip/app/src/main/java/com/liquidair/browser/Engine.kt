package com.liquidair.browser

import android.content.Context
import org.mozilla.geckoview.ContentBlocking
import org.mozilla.geckoview.GeckoRuntime
import org.mozilla.geckoview.GeckoRuntimeSettings
import org.mozilla.geckoview.GeckoSession
import org.mozilla.geckoview.GeckoSessionSettings
import org.mozilla.geckoview.WebExtension
import org.mozilla.geckoview.WebExtensionController

/**
 * Everything that talks to the browser engine's global settings lives here, so the
 * rest of the app never has to know how the engine is configured.
 */
object Engine {
    private var runtimeOrNull: GeckoRuntime? = null

    /** The built-in network blocker (assets/adblock). Null until the engine has loaded it. */
    private var blocker: WebExtension? = null
    private var blockerWanted = true

    val runtime: GeckoRuntime
        get() = runtimeOrNull ?: error("Engine.start() was not called")

    fun start(context: Context, prefs: Prefs, vault: Vault) {
        if (runtimeOrNull == null) {
            val rt = GeckoRuntime.create(context.applicationContext)
            runtimeOrNull = rt
            // Saved passwords: the engine's login manager stores and finds them in the vault.
            rt.setAutocompleteStorageDelegate(LoginStorage(vault))
            Sites.init(context)
            AdBlock.loadHosts(context.applicationContext)
            installBlocker()
        }
        apply(prefs)
    }

    /** Push the user's choices (blocker, cookies, security, text size, ...) into the engine. */
    fun apply(prefs: Prefs) {
        val settings = runtime.settings
        settings.setJavaScriptEnabled(true)
        settings.setRemoteDebuggingEnabled(false)
        settings.setConsoleOutputEnabled(false)
        // Pages follow the app theme: system default, or the light/dark choice in Settings.
        settings.setPreferredColorScheme(
            when (prefs.theme) {
                1 -> GeckoRuntimeSettings.COLOR_SCHEME_LIGHT
                2 -> GeckoRuntimeSettings.COLOR_SCHEME_DARK
                else -> GeckoRuntimeSettings.COLOR_SCHEME_SYSTEM
            }
        )
        settings.setGlobalPrivacyControl(prefs.gpc)
        settings.setFingerprintingProtection(prefs.fingerprint)
        settings.setFingerprintingProtectionPrivateBrowsing(prefs.fingerprint)
        // HTTPS-only: every connection is upgraded to https, and sites that can't do it fail
        // to load instead of quietly falling back to an unprotected connection.
        settings.setAllowInsecureConnections(
            if (prefs.httpsOnly) GeckoRuntimeSettings.HTTPS_ONLY else GeckoRuntimeSettings.ALLOW_ALL
        )

        val blocking = settings.contentBlocking
        if (prefs.adBlock) {
            // STRICT blocks more ad and tracker networks than DEFAULT. This only ever stops
            // a *request* from leaving the device (an ad iframe, a tracking pixel, a script
            // from a known ad host) — it never touches a page's own HTML, CSS or images, so
            // a site held together with inline styles renders exactly as it otherwise would.
            blocking.setEnhancedTrackingProtectionLevel(ContentBlocking.EtpLevel.STRICT)
            blocking.setAntiTracking(
                ContentBlocking.AntiTracking.AD or
                    ContentBlocking.AntiTracking.ANALYTIC or
                    ContentBlocking.AntiTracking.SOCIAL or
                    ContentBlocking.AntiTracking.CONTENT or
                    ContentBlocking.AntiTracking.CRYPTOMINING or
                    ContentBlocking.AntiTracking.FINGERPRINTING or
                    ContentBlocking.AntiTracking.STP or
                    ContentBlocking.AntiTracking.EMAIL
            )
            blocking.setStrictSocialTrackingProtection(true)
        } else {
            blocking.setEnhancedTrackingProtectionLevel(ContentBlocking.EtpLevel.NONE)
            blocking.setAntiTracking(ContentBlocking.AntiTracking.NONE)
        }

        // Cookies. Set after the blocker so this choice is the one that sticks.
        blocking.setCookieBehavior(
            when (prefs.cookieMode) {
                0 -> ContentBlocking.CookieBehavior.ACCEPT_ALL
                2 -> ContentBlocking.CookieBehavior.ACCEPT_FIRST_PARTY
                3 -> ContentBlocking.CookieBehavior.ACCEPT_NONE
                else -> ContentBlocking.CookieBehavior.ACCEPT_NON_TRACKERS
            }
        )
        // Private tabs never share cookies between sites unless the user blocks them outright.
        blocking.setCookieBehaviorPrivateMode(
            when (prefs.cookieMode) {
                2 -> ContentBlocking.CookieBehavior.ACCEPT_FIRST_PARTY
                3 -> ContentBlocking.CookieBehavior.ACCEPT_NONE
                else -> ContentBlocking.CookieBehavior.ACCEPT_FIRST_PARTY_AND_ISOLATE_OTHERS
            }
        )

        // Phishing and malware warnings.
        blocking.setSafeBrowsing(
            if (prefs.safeBrowsing) ContentBlocking.SafeBrowsing.DEFAULT else ContentBlocking.SafeBrowsing.NONE
        )

        settings.setAutomaticFontSizeAdjustment(false)
        settings.setFontInflationEnabled(true)
        settings.setFontSizeFactor(prefs.zoom / 100f)

        // The extension stays on so per-site JavaScript blocking works; it asks the app whether
        // ads should be blocked for each page, and the answer follows this switch.
        SiteBridge.adBlockOn = prefs.adBlock
        blockerWanted = true
        syncBlocker()
    }

    // ---- the network blocker ------------------------------------------------------------------

    /** Loads the blocker that ships inside the app. If anything goes wrong the browser carries
     *  on with the engine's own tracking protection, exactly as before. */
    private fun installBlocker() {
        try {
            val controller = runtime.webExtensionController
            controller.ensureBuiltIn(BLOCKER_URI, BLOCKER_ID).accept({ ext ->
                if (ext != null) {
                    blocker = ext
                    ext.setMessageDelegate(SiteBridge, SiteBridge.APP)
                    // Private tabs get the blocker too.
                    controller.setAllowedInPrivateBrowsing(ext, true).accept({ updated ->
                        if (updated != null) {
                            blocker = updated
                            updated.setMessageDelegate(SiteBridge, SiteBridge.APP)
                        }
                        syncBlocker()
                    }, { syncBlocker() })
                }
            }, { })
        } catch (e: Exception) {
            // No blocker: the engine's tracking protection still applies.
        }
    }

    /** Turns the network blocker on or off to match the Settings switch. */
    private fun syncBlocker() {
        val ext = blocker ?: return
        try {
            val controller = runtime.webExtensionController
            val isOn = ext.metaData.enabled
            if (blockerWanted && !isOn) {
                controller.enable(ext, WebExtensionController.EnableSource.USER).accept({ blocker = it ?: blocker }, { })
            } else if (!blockerWanted && isOn) {
                controller.disable(ext, WebExtensionController.EnableSource.USER).accept({ blocker = it ?: blocker }, { })
            }
        } catch (e: Exception) {
            // Leave it as it is.
        }
    }

    // ---- sessions and stored data --------------------------------------------------------------

    /** A fresh page session. Private tabs get a separate private session. */
    fun newSession(private: Boolean, desktop: Boolean): GeckoSession {
        val builder = GeckoSessionSettings.Builder()
            .usePrivateMode(private)
            .userAgentMode(
                if (desktop) GeckoSessionSettings.USER_AGENT_MODE_DESKTOP
                else GeckoSessionSettings.USER_AGENT_MODE_MOBILE
            )
            .viewportMode(
                if (desktop) GeckoSessionSettings.VIEWPORT_MODE_DESKTOP
                else GeckoSessionSettings.VIEWPORT_MODE_MOBILE
            )
        return GeckoSession(builder.build())
    }

    fun clearData(cookiesAndSites: Boolean, caches: Boolean) {
        var flags = 0L
        if (cookiesAndSites) flags = flags or
            org.mozilla.geckoview.StorageController.ClearFlags.SITE_DATA
        if (caches) flags = flags or
            org.mozilla.geckoview.StorageController.ClearFlags.ALL_CACHES
        if (flags != 0L) runtime.storageController.clearData(flags)
    }

    private const val BLOCKER_URI = "resource://android/assets/adblock/"
    private const val BLOCKER_ID = "blocker@liquidair.app"
}
