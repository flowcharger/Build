package com.liquidair.browser

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.app.KeyguardManager
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.content.res.ColorStateList
import android.graphics.drawable.RippleDrawable
import android.graphics.Outline
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.ViewOutlineProvider
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.widget.CheckBox
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.PopupWindow
import android.widget.ScrollView
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast
import org.mozilla.geckoview.AllowOrDeny
import org.mozilla.geckoview.GeckoResult
import org.mozilla.geckoview.GeckoSession
import org.mozilla.geckoview.GeckoSessionSettings
import org.mozilla.geckoview.GeckoView
import android.media.AudioManager

/**
 * Liquid Air. The page area is GeckoView (the engine); everything around it is drawn
 * here in plain Android views: tab strip, toolbar, start page, tab view and menus.
 */
class MainActivity : Activity() {
    lateinit var prefs: Prefs
    lateinit var browser: Browser
    lateinit var downloads: Downloads
    lateinit var prompts: PromptUi
    lateinit var permissions: Permissions
    lateinit var geckoView: GeckoView
    lateinit var vault: Vault
    private lateinit var settingsUi: SettingsPage
    private lateinit var downloadsUi: DownloadsPage

    /** Which section of Settings is showing (see SettingsPage). */
    var settingsSection = "general"
    private var bookmarkBtn: FrameLayout? = null
    private var siteBtn: FrameLayout? = null
    private var homeView: GeckoView? = null
    private var homeSession: GeckoSession? = null
    private var homeKey = ""
    private lateinit var sitePanel: SitePanel

    private val main = Handler(Looper.getMainLooper())

    private lateinit var root: FrameLayout
    private lateinit var strip: LinearLayout
    private lateinit var toolbar: LinearLayout
    private lateinit var content: FrameLayout
    private lateinit var home: LinearLayout
    private lateinit var homeInput: EditText
    private lateinit var tabsScroll: HorizontalScrollView
    private lateinit var tabsRow: LinearLayout
    private lateinit var modes: FrameLayout
    private lateinit var modePill: View
    private lateinit var modeA: TextView
    private lateinit var addressInput: EditText
    private lateinit var counter: TextView
    private lateinit var progress: View
    private lateinit var homeButton: FrameLayout
    private lateinit var backButton: FrameLayout
    private lateinit var forwardButton: FrameLayout
    private lateinit var reloadButton: FrameLayout
    private lateinit var menuButton: FrameLayout
    private lateinit var overview: FrameLayout
    private lateinit var overviewBody: LinearLayout
    private lateinit var toolPage: FrameLayout
    private lateinit var plusView: FrameLayout
    private lateinit var findBar: LinearLayout
    private lateinit var findInput: EditText
    private lateinit var toolTitle: TextView
    private lateinit var toolBody: LinearLayout
    private lateinit var toolScroll: ScrollView
    private lateinit var toolCustom: FrameLayout

    private var menu: PopupWindow? = null
    private var zoomLabel: TextView? = null
    private var currentTool = ""
    private var clearRange = "all"
    private var clearHistory = true
    private var clearCookies = true
    private var clearCache = true
    private var fullscreen = false

    private class Pill(val view: View, val mark: FrameLayout, val title: TextView, val tab: Tab)

    private val pills = HashMap<Int, Pill>()

    private val androidAsks = HashMap<Int, (Boolean) -> Unit>()
    private var askCode = 200
    private var filePicked: ((List<Uri>) -> Unit)? = null
    private var documentPicked: ((Uri) -> Unit)? = null
    private var authThen: (() -> Unit)? = null
    private var lastAuth = 0L

    // ---- start-up -------------------------------------------------------

    override fun onCreate(savedInstanceState: Bundle?) {
        prefs = Prefs(this)
        setTheme(if (wantDark()) R.style.AppThemeDark else R.style.AppThemeLight)
        super.onCreate(savedInstanceState)
        vault = Vault(this)
        Engine.start(this, prefs, vault)
        // "Clear cookies and site data on exit": done the next time the app starts.
        if (prefs.clearOnExit) Engine.clearData(true, false)
        downloads = Downloads(this)
        downloads.register()
        downloadsUi = DownloadsPage(this)
        settingsUi = SettingsPage(this)
        prompts = PromptUi(this)
        permissions = Permissions(this)
        browser = Browser(this, prefs)
        applyTheme()
        buildUi()
        val first = intent?.data?.toString()
        if (first != null || !prefs.restoreTabs || !restoreSession()) browser.newTab(first)
        if (Build.VERSION.SDK_INT >= 33 && prefs.bgPlay) {
            askAndroid(listOf(Manifest.permission.POST_NOTIFICATIONS)) { }
        }
    }

    /** Light or dark, exactly as the system says. */
    private fun wantDark(): Boolean = when (prefs.theme) {
        1 -> false
        2 -> true
        else -> systemIsDark()
    }

    /** Re-draws the whole screen in the current theme, keeping tabs and the open page. */
    private fun paintBookmark() {
        val b = bookmarkBtn ?: return
        val t = browser.active()
        val saved = t != null && browser.bookmarks.any { it.url == t.url }
        b.background = if (saved) solid(this, C.MINT, 18f) else RippleDrawable(
            ColorStateList.valueOf(if (C.dark) 0x33FFFFFF else 0x8CFFFFFF.toInt()), null, solid(this, Color.WHITE, 18f))
        b.isSelected = saved
        b.alpha = if (t == null || t.isPrivate || t.home || !Urls.isWeb(t.url)) 0.4f else 1f
    }

    private fun toggleBookmark() {
        val t = browser.active()
        if (t == null || t.isPrivate || t.home || !Urls.isWeb(t.url)) {
            toast("Open a page to bookmark")
            return
        }
        if (browser.bookmarks.any { it.url == t.url }) {
            browser.bookmarks.removeAll { it.url == t.url }
            browser.saveBookmarks()
            toast("Bookmark removed")
        } else {
            browser.bookmarks.add(0, Saved(t.label(), t.url))
            browser.saveBookmarks()
            toast("Bookmarked")
        }
        paintBookmark()
    }

    fun reTheme() {
        val tool = currentTool
        menu?.dismiss()
        setTheme(if (wantDark()) R.style.AppThemeDark else R.style.AppThemeLight)
        applyTheme()
        Engine.apply(prefs)
        buildUi()
        currentTool = ""
        syncMode(false)
        rebuildPills()
        showActive()
        refreshToolbar()
        if (tool == "settings" || tool == "downloads") openTool(tool)
    }

    private fun applyTheme() {
        C.flat = prefs.style == 1
        C.dark = wantDark()
        window.statusBarColor = C.BG
        window.navigationBarColor = C.WHITE
        if (!fullscreen) setBars(false)
    }

    @Suppress("DEPRECATION")
    private fun setBars(immersive: Boolean) {
        var f = View.SYSTEM_UI_FLAG_LAYOUT_STABLE
        if (immersive) {
            f = f or View.SYSTEM_UI_FLAG_FULLSCREEN or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or
                View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
        } else if (!C.dark) {
            f = f or View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR
            if (Build.VERSION.SDK_INT >= 26) f = f or View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR
        }
        window.decorView.systemUiVisibility = f
    }

    override fun onConfigurationChanged(newConfig: android.content.res.Configuration) {
        super.onConfigurationChanged(newConfig)
        if (!::root.isInitialized) return
        if (prefs.theme == 0 && wantDark() != C.dark) {
            reTheme()
            return
        }
        // Settings switches between a side list and a top row when the width changes.
        if (currentTool == "settings") renderTool()
    }

    override fun onNewIntent(intent: Intent?) {
        super.onNewIntent(intent)
        val url = intent?.data?.toString() ?: return
        browser.newTab(url)
    }

    /** Remembers the open pages (not private ones) for the next start. */
    private fun saveSession() {
        if (!prefs.restoreTabs) {
            prefs.session = ""
            return
        }
        try {
            val arr = org.json.JSONArray()
            var active = 0
            for (t in browser.tabs) {
                if (t.isPrivate || t.home || !Urls.isWeb(t.url)) continue
                if (t.id == browser.activeId) active = arr.length()
                arr.put(t.url)
            }
            prefs.session = org.json.JSONObject().put("urls", arr).put("active", active).toString()
        } catch (e: Exception) {
        }
    }

    private fun restoreSession(): Boolean {
        return try {
            val o = org.json.JSONObject(prefs.session)
            val arr = o.getJSONArray("urls")
            if (arr.length() == 0) return false
            val n = minOf(arr.length(), 5)
            val active = o.optInt("active", 0).coerceIn(0, n - 1)
            var pick: Tab? = null
            for (i in 0 until n) {
                val t = browser.newTab(arr.getString(i), false, false)
                if (i == active) pick = t
            }
            pick?.let { browser.select(it) }
            true
        } catch (e: Exception) {
            false
        }
    }

    override fun onPause() {
        super.onPause()
        downloadsUi.stop()
        saveSession()
        val audio = getSystemService(Context.AUDIO_SERVICE) as AudioManager
        val playing = prefs.bgPlay && audio.isMusicActive
        if (playing) {
            try {
                startForegroundService(Intent(this, PlaybackService::class.java))
            } catch (e: Exception) {
                // Android refused to start it; playback may stop with the screen.
            }
        }
        // Leaving the app: let go of every background tab's session but the one playing
        // audio, if any. Nothing is lost — each tab reopens its url the moment it's picked.
        browser.trimBackgroundTabs(if (playing) 1 else 0)
    }

    override fun onResume() {
        super.onResume()
        stopService(Intent(this, PlaybackService::class.java))
        if (currentTool == "downloads") downloadsUi.start()
    }

    override fun onDestroy() {
        if (::downloadsUi.isInitialized) downloadsUi.stop()
        if (::downloads.isInitialized) downloads.unregister()
        super.onDestroy()
    }

    /** The system is short on memory. Free what we can without losing anything the user
     *  would notice: background tab sessions first, then our own bitmap caches. */
    override fun onTrimMemory(level: Int) {
        super.onTrimMemory(level)
        when {
            level >= android.content.ComponentCallbacks2.TRIM_MEMORY_COMPLETE ||
                level >= android.content.ComponentCallbacks2.TRIM_MEMORY_MODERATE -> {
                browser.trimBackgroundTabs(0)
                Engine.clearData(cookiesAndSites = false, caches = true)
            }
            level >= android.content.ComponentCallbacks2.TRIM_MEMORY_RUNNING_CRITICAL ||
                level >= android.content.ComponentCallbacks2.TRIM_MEMORY_RUNNING_LOW -> {
                browser.trimBackgroundTabs(1)
            }
        }
    }

    // ---- building the screen -------------------------------------------

    private fun buildUi() {
        root = FrameLayout(this)
        root.background = if (C.flat) ColorDrawable(C.BG) else ArtDrawable(this)
        // Stop the system's own "dark mode for apps" from greying the picture.
        if (Build.VERSION.SDK_INT >= 29) root.isForceDarkAllowed = false
        // Stop the system's own "dark mode for apps" from greying the picture.
        if (Build.VERSION.SDK_INT >= 29) root.isForceDarkAllowed = false

        val column = LinearLayout(this)
        column.orientation = LinearLayout.VERTICAL
        root.addView(column, FrameLayout.LayoutParams(-1, -1))

        strip = buildStrip()
        column.addView(strip, lp(-1, dp(50)))
        toolbar = buildToolbar()
        column.addView(toolbar, lp(-1, dp(58)))

        progress = View(this)
        progress.background = GradientDrawable(
            GradientDrawable.Orientation.LEFT_RIGHT, intArrayOf(C.SKY_A, C.SKY_C)
        )
        progress.pivotX = 0f
        progress.scaleX = 0f
        column.addView(progress, lp(-1, dp(2)))

        content = FrameLayout(this)
        column.addView(content, LinearLayout.LayoutParams(-1, 0, 1f))
        if (!::geckoView.isInitialized) geckoView = GeckoView(this)
        (geckoView.parent as? ViewGroup)?.removeView(geckoView)
        content.addView(geckoView, FrameLayout.LayoutParams(-1, -1))
        home = buildHome()
        content.addView(home, FrameLayout.LayoutParams(-1, -1))
        findBar = buildFindBar()
        findBar.visibility = View.GONE
        content.addView(findBar, FrameLayout.LayoutParams(-1, dp(46), Gravity.TOP).apply {
            leftMargin = dp(8); rightMargin = dp(8); topMargin = dp(6)
        })

        overview = buildOverviewShell()
        overview.visibility = View.GONE
        root.addView(overview, FrameLayout.LayoutParams(-1, -1))
        toolPage = buildToolShell()
        toolPage.visibility = View.GONE
        root.addView(toolPage, FrameLayout.LayoutParams(-1, -1))

        setContentView(root)
        root.addOnLayoutChangeListener { _, l, t, r, b, ol, ot, orr, ob ->
            if (r - l != orr - ol || b - t != ob - ot) {
                Backdrop.rebuild(this, root)
                Backdrop.redraw(root)
            }
        }
    }

    private fun buildStrip(): LinearLayout {
        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        row.gravity = Gravity.CENTER_VERTICAL
        row.pad(10, 0, 10, 0)

        // The A / InPrivate switch.
        modes = FrameLayout(this)
        modes.background = glass(this, 19f)
        modePill = View(this)
        modePill.background = solid(this, C.MINT, 16f)
        modes.addView(modePill, FrameLayout.LayoutParams(dp(32), dp(32)).apply {
            leftMargin = dp(3)
            topMargin = dp(3)
        })
        modeA = text(this, "A", 15f, C.INK, true)
        modeA.gravity = Gravity.CENTER
        modes.addView(modeA, FrameLayout.LayoutParams(dp(32), dp(32)).apply {
            leftMargin = dp(3)
            topMargin = dp(3)
        })
        val eyeBox = FrameLayout(this)
        eyeBox.contentDescription = "InPrivate tabs"
        eyeBox.addView(icon(this, R.drawable.ic_eye_off, 23), FrameLayout.LayoutParams(dp(23), dp(23), Gravity.CENTER))
        modes.addView(eyeBox, FrameLayout.LayoutParams(dp(34), dp(38)).apply { leftMargin = dp(37) })
        modeA.setOnClickListener { switchMode(false) }
        eyeBox.setOnClickListener { switchMode(true) }
        modes.setOnClickListener { }
        row.addView(modes, lp(dp(74), dp(38)))

        tabsScroll = HorizontalScrollView(this)
        tabsScroll.isHorizontalScrollBarEnabled = false
        tabsRow = LinearLayout(this)
        tabsRow.orientation = LinearLayout.HORIZONTAL
        tabsRow.gravity = Gravity.CENTER_VERTICAL
        tabsScroll.addView(tabsRow, FrameLayout.LayoutParams(-2, -1))
        row.addView(tabsScroll, LinearLayout.LayoutParams(0, -1, 1f).apply { leftMargin = dp(8) })

        val plus = FrameLayout(this)
        plus.background = glass(this, 18f)
        val plusIcon = icon(this, R.drawable.ic_plus, 20)
        plus.addView(plusIcon, FrameLayout.LayoutParams(dp(20), dp(20), Gravity.CENTER))
        plus.contentDescription = "New tab"
        plus.setOnClickListener { browser.newTab() }
        plusView = plus
        return row
    }

    private fun buildToolbar(): LinearLayout {
        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        row.gravity = Gravity.CENTER_VERTICAL
        row.pad(6, 0, 6, 0)

        homeButton = iconButton(this, R.drawable.ic_home, 38, 40, 25, "Home")
        backButton = iconButton(this, R.drawable.ic_back, 38, 40, 25, "Back")
        forwardButton = iconButton(this, R.drawable.ic_forward, 38, 40, 25, "Forward")
        reloadButton = iconButton(this, R.drawable.ic_reload, 38, 40, 25, "Reload")
        for (b in listOf(homeButton, backButton, forwardButton, reloadButton)) row.addView(b)

        homeButton.setOnClickListener { browser.active()?.let { browser.goHome(it) } }
        backButton.setOnClickListener { browser.active()?.let { if (browser.canBack(it)) browser.back(it) } }
        forwardButton.setOnClickListener { browser.active()?.let { if (browser.canForward(it)) browser.forward(it) } }
        reloadButton.setOnClickListener {
            browser.active()?.let {
                browser.reload(it)
                reloadButton.iconView().animate().rotationBy(360f).setDuration(600)
                    .setInterpolator(android.view.animation.PathInterpolator(.3f, .9f, .3f, 1f)).start()
            }
        }

        addressInput = EditText(this)
        addressInput.background = null
        addressInput.setTextColor(C.INK)
        addressInput.setHintTextColor(C.HINT)
        addressInput.hint = "Search or URL"
        addressInput.textSize = 14.5f
        addressInput.maxLines = 1
        addressInput.isSingleLine = true
        addressInput.imeOptions = EditorInfo.IME_ACTION_GO
        addressInput.inputType = InputType.TYPE_TEXT_VARIATION_URI
        addressInput.setSelectAllOnFocus(true)
        addressInput.pad(42, 0, 44, 0)
        addressInput.setOnEditorActionListener { v, actionId, _ ->
            if (actionId == EditorInfo.IME_ACTION_GO) {
                submit(v.text.toString())
                true
            } else false
        }
        addressInput.setOnFocusChangeListener { _, focused ->
            val tab = browser.active()
            if (focused && tab != null && !tab.home) {
                addressInput.setText(tab.url)
                addressInput.selectAll()
            } else if (!focused) {
                refreshToolbar()
            }
        }
        val addrBox = FrameLayout(this)
        addrBox.background = glass(this, 20f, C.FIELD)
        addrBox.addView(addressInput, FrameLayout.LayoutParams(-1, -1))
        sitePanel = SitePanel(this)
        val wb = iconButton(this, R.drawable.ic_wrench, 36, 36, 19, "Site status and permissions")
        wb.layoutParams = FrameLayout.LayoutParams(dp(36), dp(36), Gravity.START or Gravity.CENTER_VERTICAL).apply { leftMargin = dp(2) }
        wb.setOnClickListener { browser.active()?.let { sitePanel.show(it) } }
        siteBtn = wb
        addrBox.addView(wb)
        val bb = iconButton(this, R.drawable.ic_bookmark, 36, 36, 20, "Bookmark page")
        bb.layoutParams = FrameLayout.LayoutParams(dp(36), dp(36), Gravity.END or Gravity.CENTER_VERTICAL).apply { rightMargin = dp(2) }
        bb.setOnClickListener { toggleBookmark() }
        bookmarkBtn = bb
        addrBox.addView(bb)
        row.addView(addrBox, LinearLayout.LayoutParams(0, dp(40), 1f).apply {
            leftMargin = dp(2)
            rightMargin = dp(6)
        })
        paintBookmark()

        counter = text(this, "1", 13f, C.INK, true)
        counter.gravity = Gravity.CENTER
        counter.background = glass(this, 12f).also { it.ring = true }
        counter.contentDescription = "Tabs"
        counter.setOnClickListener { showOverview() }
        row.addView(counter, lp(dp(36), dp(36)).apply { rightMargin = dp(2) })

        menuButton = iconButton(this, R.drawable.ic_tune, 38, 40, 24, "Settings menu")
        menuButton.setOnClickListener { showMenu() }
        row.addView(menuButton)
        return row
    }

    /** The start page is a local web page (assets/home) shown in its own engine view. */
    private fun buildHome(): LinearLayout {
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        homeView?.releaseSession()
        val gv = GeckoView(this)
        homeView = gv
        homeKey = ""
        col.addView(gv, LinearLayout.LayoutParams(-1, -1))
        // Kept only so the rest of the screen can set its hint and keyboard flags; never shown.
        homeInput = EditText(this)
        return col
    }

    private val homeNav = object : GeckoSession.NavigationDelegate {
        override fun onLoadRequest(
            session: GeckoSession,
            request: GeckoSession.NavigationDelegate.LoadRequest
        ): GeckoResult<AllowOrDeny>? {
            val uri = request.uri
            if (uri.startsWith("resource://android/assets/home/")) return GeckoResult.allow()
            if (uri.startsWith("liquidair://")) {
                val parsed = Uri.parse(uri)
                val kind = parsed.host ?: ""
                val q = parsed.getQueryParameter("q") ?: ""
                main.post { openFromHome(kind, q) }
            } else if (Urls.isWeb(uri)) {
                main.post { browser.active()?.let { browser.load(it, uri) } }
            }
            return GeckoResult.deny()
        }
    }

    /** A search typed on the start page, or the "Ask Perplexity" button. */
    private fun openFromHome(kind: String, q: String) {
        val tab = browser.active() ?: return
        val value = q.trim()
        if (value.isEmpty()) return
        hideKeyboard()
        when (kind) {
            "search" -> browser.load(tab, value)
            "perplexity" -> browser.load(tab, "https://www.perplexity.ai/search?q=" + Uri.encode(value))
        }
    }

    private fun showHomePage(tab: Tab) {
        val gv = homeView ?: return
        var s = homeSession
        if (s == null) {
            s = GeckoSession(GeckoSessionSettings.Builder().usePrivateMode(false).build())
            s.navigationDelegate = homeNav
            s.open(Engine.runtime)
            homeSession = s
        }
        if (gv.session !== s) {
            gv.releaseSession()
            gv.setSession(s)
        }
        s.setActive(true)
        val params = "dark=" + (if (C.dark) 1 else 0) + "&style=" + prefs.style + "&priv=" + (if (tab.isPrivate) 1 else 0) +
            "&ov=" + prefs.overview
        val key = tab.id.toString() + "|" + params
        if (key != homeKey) {
            homeKey = key
            s.loadUri("resource://android/assets/home/index.html?" + params)
        }
    }

    // ---- find in page --------------------------------------------------

    private fun buildFindBar(): LinearLayout {
        val bar = LinearLayout(this)
        bar.gravity = Gravity.CENTER_VERTICAL
        bar.background = solid(this, C.WHITE, 23f)
        bar.elevation = dpf(6f)
        bar.pad(14, 0, 4, 0)
        findInput = EditText(this)
        findInput.background = null
        findInput.hint = "Find in page"
        findInput.setTextColor(C.INK)
        findInput.setHintTextColor(C.HINT)
        findInput.textSize = 15f
        findInput.isSingleLine = true
        findInput.imeOptions = EditorInfo.IME_ACTION_SEARCH
        findInput.setOnEditorActionListener { _, id, _ ->
            if (id == EditorInfo.IME_ACTION_SEARCH) { findNext(false); true } else false
        }
        findInput.addTextChangedListener(object : android.text.TextWatcher {
            override fun afterTextChanged(e: android.text.Editable?) { findNext(false) }
            override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
        })
        bar.addView(findInput, LinearLayout.LayoutParams(0, -1, 1f))
        fun btn(label: String, action: () -> Unit) {
            val b = text(this, label, 20f, C.INK, true)
            b.gravity = Gravity.CENTER
            b.background = withRipple(null)
            b.setOnClickListener { action() }
            bar.addView(b, lp(dp(40), dp(40)))
        }
        btn("\u2039") { findNext(true) }
        btn("\u203A") { findNext(false) }
        btn("\u2715") { hideFind() }
        return bar
    }

    private fun showFind() {
        val tab = browser.active()
        if (tab == null || tab.home) { toast("Open a page first"); return }
        findBar.visibility = View.VISIBLE
        findInput.requestFocus()
        val imm = getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
        imm.showSoftInput(findInput, 0)
    }

    private fun hideFind() {
        if (findBar.visibility != View.VISIBLE) return
        findBar.visibility = View.GONE
        findInput.setText("")
        findInput.clearFocus()
        hideKeyboard()
        try { browser.active()?.session?.finder?.clear() } catch (e: Exception) { }
    }

    private fun findNext(backwards: Boolean) {
        val tab = browser.active() ?: return
        val q = findInput.text.toString()
        try {
            if (q.isEmpty()) tab.session.finder.clear()
            else tab.session.finder.find(
                q, if (backwards) GeckoSession.FINDER_FIND_BACKWARDS else GeckoSession.FINDER_FIND_FORWARD
            )
        } catch (e: Exception) {
            // The page is not ready for searching yet.
        }
    }

    /** Takes a picture of the page and saves it in Pictures/LiquidAir. */
    private fun saveScreenshot() {
        val tab = browser.active()
        if (tab == null || tab.home || geckoView.session !== tab.session) {
            toast("Open a page first")
            return
        }
        if (tab.isPrivate) {
            toast("Screenshots are off in private tabs")
            return
        }
        if (Build.VERSION.SDK_INT < 29) {
            toast("Screenshots need Android 10 or newer")
            return
        }
        try {
            geckoView.capturePixels().accept({ bmp ->
                if (bmp == null) toast("Could not take the screenshot") else storeScreenshot(bmp)
            }, { toast("Could not take the screenshot") })
        } catch (e: Exception) {
            toast("Could not take the screenshot")
        }
    }

    private fun storeScreenshot(bmp: android.graphics.Bitmap) {
        try {
            val values = android.content.ContentValues().apply {
                put(android.provider.MediaStore.Images.Media.DISPLAY_NAME, "LiquidAir-" + System.currentTimeMillis() + ".png")
                put(android.provider.MediaStore.Images.Media.MIME_TYPE, "image/png")
                put(android.provider.MediaStore.Images.Media.RELATIVE_PATH, "Pictures/LiquidAir")
            }
            val uri = contentResolver.insert(android.provider.MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values)
            if (uri == null) {
                toast("Could not save the screenshot")
                return
            }
            contentResolver.openOutputStream(uri)?.use { bmp.compress(android.graphics.Bitmap.CompressFormat.PNG, 100, it) }
            toast("Screenshot saved in Pictures")
        } catch (e: Exception) {
            toast("Could not save the screenshot")
        }
    }

    private fun copyLink() {
        val tab = browser.active()
        if (tab == null || tab.home || tab.url.isEmpty()) { toast("Nothing to copy"); return }
        val cm = getSystemService(Context.CLIPBOARD_SERVICE) as android.content.ClipboardManager
        cm.setPrimaryClip(android.content.ClipData.newPlainText("link", tab.url))
        toast("Link copied")
    }

    // ---- the callbacks the browser brain uses --------------------------

    private var toastView: TextView? = null

    /** A small glass pill that fades up from the bottom, like the old browser. */
    fun toast(message: String) {
        if (!::root.isInitialized) {
            Toast.makeText(this, message, Toast.LENGTH_SHORT).show()
            return
        }
        toastView?.let { root.removeView(it) }
        val t = text(this, message, 14f, C.INK)
        t.gravity = Gravity.CENTER
        t.pad(18, 11, 18, 11)
        t.background = GradientDrawable().apply {
            cornerRadius = dpf(30f)
            setColor(if (C.dark) 0xE6262B29.toInt() else 0xE6FFFFFF.toInt())
            setStroke(dp(1), if (C.dark) 0x33FFFFFF else 0xCCFFFFFF.toInt())
        }
        t.elevation = dpf(8f)
        root.addView(t, FrameLayout.LayoutParams(-2, -2, Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL).apply {
            bottomMargin = dp(22)
            leftMargin = dp(16)
            rightMargin = dp(16)
        })
        toastView = t
        t.arrive(0f, 8f, 1f, 180)
        main.postDelayed({
            if (toastView === t) {
                t.animate().alpha(0f).setDuration(180).withEndAction { root.removeView(t) }.start()
                toastView = null
            }
        }, 2000)
    }

    /** The set of tabs changed (opened, closed, renamed). */
    fun onTabsChanged() {
        rebuildPills()
        refreshToolbar()
        if (overview.visibility == View.VISIBLE) buildOverview()
    }

    /** The active tab, the mode or the home/web state changed. */
    fun onActiveChanged() {
        syncMode(true)
        rebuildPills()
        showActive()
        refreshToolbar()
        if (overview.visibility == View.VISIBLE) buildOverview()
        // Keep only a couple of background tabs' engine sessions alive; the rest free
        // their memory and reload on demand. Posted so the newly active page attaches first.
        main.postDelayed({ browser.trimBackgroundTabs(2) }, 400)
    }

    /** Something about one tab changed (title, icon, loading, address). */
    fun onTabChanged(tab: Tab) {
        pills[tab.id]?.let { updatePill(it) }
        if (tab.id == browser.activeId) refreshToolbar()
    }

    private fun showActive() {
        val tab = browser.active() ?: return
        if (::findBar.isInitialized && findBar.visibility == View.VISIBLE) hideFind()
        applyPrivacy(tab)
        if (tab.home) {
            geckoView.visibility = View.INVISIBLE
            home.visibility = View.VISIBLE
            content.setBackgroundColor(Color.TRANSPARENT)
            showHomePage(tab)
        } else {
            homeSession?.setActive(false)
            home.visibility = View.GONE
            geckoView.visibility = View.VISIBLE
            content.setBackgroundColor(C.WHITE)
            attach(tab, 0)
        }
    }

    /** Private tabs: hide from screenshots and recent apps, and stop the keyboard learning what is typed. */
    fun applyPrivacy(tab: Tab) {
        if (tab.isPrivate && prefs.secureTabs) {
            window.addFlags(android.view.WindowManager.LayoutParams.FLAG_SECURE)
        } else {
            window.clearFlags(android.view.WindowManager.LayoutParams.FLAG_SECURE)
        }
        val noLearn = EditorInfo.IME_FLAG_NO_PERSONALIZED_LEARNING
        val base = if (tab.isPrivate) {
            InputType.TYPE_TEXT_VARIATION_URI or InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS
        } else {
            InputType.TYPE_TEXT_VARIATION_URI
        }
        if (addressInput.inputType != base) addressInput.inputType = base
        if (homeInput.inputType != base) homeInput.inputType = base
        addressInput.imeOptions = EditorInfo.IME_ACTION_GO or (if (tab.isPrivate) noLearn else 0)
        homeInput.imeOptions = EditorInfo.IME_ACTION_SEARCH or (if (tab.isPrivate) noLearn else 0)
    }

    private fun attach(tab: Tab, tries: Int) {
        browser.wake(tab)
        if (!tab.session.isOpen) {
            if (tries < 40) {
                main.postDelayed({
                    if (browser.active() === tab && !tab.home) attach(tab, tries + 1)
                }, 60)
            }
            return
        }
        if (geckoView.session !== tab.session) {
            val old = geckoView.releaseSession()
            old?.setActive(false)
            geckoView.setSession(tab.session)
        }
        tab.session.setActive(true)
    }

    fun detach(tab: Tab) {
        if (geckoView.session === tab.session) geckoView.releaseSession()
    }

    fun setFullscreen(on: Boolean) {
        fullscreen = on
        strip.visibility = if (on) View.GONE else View.VISIBLE
        toolbar.visibility = if (on) View.GONE else View.VISIBLE
        progress.visibility = if (on) View.GONE else View.VISIBLE
        setBars(on)
        // Keep the screen awake while a video is full screen.
        if (on) window.addFlags(android.view.WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        else window.clearFlags(android.view.WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
    }

    // ---- submitting addresses ------------------------------------------

    private fun submit(textIn: String) {
        val tab = browser.active() ?: return
        val value = textIn.trim()
        if (value.isEmpty()) return
        addressInput.clearFocus()
        homeInput.clearFocus()
        hideKeyboard()
        browser.load(tab, value)
    }

    private fun hideKeyboard() {
        val imm = getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
        imm.hideSoftInputFromWindow(root.windowToken, 0)
    }

    // ---- mode switch ------------------------------------------------

    private fun switchMode(priv: Boolean) {
        if (browser.privateMode == priv) return
        captureThen(browser.active()) { browser.setMode(priv) }
    }

    private fun syncMode(animated: Boolean) {
        val target = if (browser.privateMode) dp(34).toFloat() else 0f
        if (animated) modePill.animate().translationX(target).setDuration(320).start()
        else modePill.translationX = target
    }

    // ---- the tab strip --------------------------------------------------

    private val seenTabs = HashSet<Int>()
    private var pillsReady = false

    private fun rebuildPills() {
        tabsRow.removeAllViews()
        pills.clear()
        var activePill: View? = null
        var fresh = false
        for (tab in browser.modeTabs()) {
            val pill = makePill(tab)
            pills[tab.id] = pill
            tabsRow.addView(pill.view, lp(dp(250), dp(36)).apply { rightMargin = dp(8) })
            if (tab.id == browser.activeId) activePill = pill.view
            if (seenTabs.add(tab.id) && pillsReady) {
                fresh = true
                pill.view.arrive(40f, 0f, .7f, 230)
            }
        }
        pillsReady = true
        if (fresh) {
            plusView.animate().rotationBy(90f).translationX(dpf(10f)).setDuration(130).withEndAction {
                plusView.animate().translationX(0f).setDuration(130).start()
            }.start()
        }
        (plusView.parent as? ViewGroup)?.removeView(plusView)
        tabsRow.addView(plusView, lp(dp(36), dp(36)))
        activePill?.let { v -> tabsScroll.post { tabsScroll.smoothScrollTo(v.left - dp(8), 0) } }
    }

    private fun makePill(tab: Tab): Pill {
        val active = tab.id == browser.activeId
        val view = LinearLayout(this)
        view.orientation = LinearLayout.HORIZONTAL
        view.gravity = Gravity.CENTER_VERTICAL
        view.pad(8, 0, 6, 0)
        val groupColor = (C.INK and 0x00FFFFFF) or 0x59000000
        view.background = if (active) {
            solid(this, C.WHITE, 18f).also { if (tab.grouped) it.setStroke(dp(2), groupColor) }
        } else {
            glass(this, 18f).also { if (tab.grouped) it.extraStroke(dp(2), groupColor) }
        }
        if (active) view.elevation = dpf(2f)

        val mark = FrameLayout(this)
        mark.background = solid(this, C.SHADE, 10f)
        view.addView(mark, lp(dp(20), dp(20)))

        val title = oneLine(text(this, "", 13f))
        view.addView(title, LinearLayout.LayoutParams(0, -2, 1f).apply {
            leftMargin = dp(8)
            rightMargin = dp(4)
        })
        val close = icon(this, R.drawable.ic_close, 14)
        close.contentDescription = "Close tab"
        close.setPadding(dp(8), dp(8), dp(8), dp(8))
        view.addView(close, lp(dp(30), dp(30)))

        view.setOnClickListener {
            if (tab.id != browser.activeId) captureThen(browser.active()) { browser.select(tab) }
        }
        close.setOnClickListener { closePillAnimated(view, tab) }
        val pill = Pill(view, mark, title, tab)
        updatePill(pill)
        return pill
    }

    /** The tab shrinks and fades before it goes. */
    private fun closePillAnimated(v: View, tab: Tab) {
        val params = v.layoutParams as? LinearLayout.LayoutParams
        if (params == null) {
            browser.close(tab)
            return
        }
        v.isClickable = false
        val w0 = params.width
        animate(240, 0f, 1f) { f ->
            params.width = (w0 * (1f - f)).toInt()
            params.rightMargin = (dp(8) * (1f - f)).toInt()
            v.alpha = 1f - f
            v.scaleX = 1f - .28f * f
            v.layoutParams = params
        }.addListener(object : android.animation.AnimatorListenerAdapter() {
            override fun onAnimationEnd(animation: android.animation.Animator) {
                browser.close(tab)
            }
        })
    }

    private fun updatePill(p: Pill) {
        p.title.text = p.tab.label()
        p.mark.removeAllViews()
        val icon = p.tab.icon
        if (icon != null && !p.tab.isPrivate) {
            val img = ImageView(this)
            img.setImageBitmap(icon)
            p.mark.addView(img, FrameLayout.LayoutParams(dp(18), dp(18), Gravity.CENTER))
        } else {
            val letter = text(this, if (p.tab.isPrivate) "P" else "A", 10f, C.INK, true)
            letter.gravity = Gravity.CENTER
            p.mark.addView(letter, FrameLayout.LayoutParams(-1, -1))
        }
    }

    // ---- the toolbar ----------------------------------------------------

    private fun enable(b: FrameLayout, on: Boolean) {
        b.isEnabled = on
        b.iconView().alpha = if (on) 1f else 0.3f
    }

    private fun refreshToolbar() {
        val tab = browser.active() ?: return
        enable(backButton, browser.canBack(tab))
        enable(forwardButton, browser.canForward(tab))
        enable(homeButton, !tab.home)
        reloadButton.iconView().setImageResource(if (tab.loading) R.drawable.ic_stop else R.drawable.ic_reload)
        val count = browser.modeTabs().size.toString()
        if (counter.text.toString() != count) {
            counter.text = count
            counter.animate().scaleX(1.15f).scaleY(1.15f).setDuration(120).withEndAction {
                counter.animate().scaleX(1f).scaleY(1f).setDuration(120).start()
            }.start()
        }
        if (!addressInput.hasFocus()) {
            addressInput.setText(if (tab.home) "" else Urls.display(tab.url))
        }
        val p = if (tab.loading && !tab.home) tab.progress / 100f else 0f
        progress.animate().scaleX(p).setDuration(120).start()
        paintBookmark()
        siteBtn?.alpha = if (tab.home || !Urls.isWeb(tab.url)) 0.4f else 1f
    }

    // ---- tab thumbnails ---------------------------------------------------

    /** Takes a small picture of the page (for the tab view), then runs [then]. */
    private fun captureThen(tab: Tab?, then: () -> Unit) {
        if (tab == null || tab.home || geckoView.session !== tab.session ||
            geckoView.visibility != View.VISIBLE
        ) {
            then()
            return
        }
        var done = false
        val finish = {
            if (!done) {
                done = true
                then()
            }
        }
        main.postDelayed({ finish() }, 450)
        try {
            geckoView.capturePixels().accept({ bmp ->
                if (bmp != null) {
                    val w = 420
                    val h = (bmp.height * (w.toFloat() / bmp.width)).toInt().coerceAtLeast(1)
                    val scaled = Bitmap.createScaledBitmap(bmp, w, h, true)
                    // The full-resolution screenshot (never shown anywhere, only ever used to
                    // make the small one above) is freed immediately rather than waiting on the
                    // garbage collector. The previous thumbnail is left alone: a tab card already
                    // on screen may still be holding it, and recycling under it would crash.
                    if (scaled !== bmp) bmp.recycle()
                    tab.thumb = scaled
                }
                finish()
            }, { _ -> finish() })
        } catch (e: Exception) {
            finish()
        }
    }

    // ---- the tab view (opened by the number box) --------------------------

    private fun buildOverviewShell(): FrameLayout {
        val shell = FrameLayout(this)
        shell.background = if (C.flat) ColorDrawable(C.BG) else ArtDrawable(this)
        shell.isClickable = true
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        shell.addView(col, FrameLayout.LayoutParams(-1, -1))

        val header = LinearLayout(this)
        header.gravity = Gravity.CENTER_VERTICAL
        header.pad(12, 8, 12, 8)
        val back = iconButton(this, R.drawable.ic_back, 44, 44, 24, "Back")
        back.background = glass(this, 22f)
        back.setOnClickListener { hideOverview() }
        header.addView(back)
        val title = text(this, "Tabs", 22f, C.INK, true)
        header.addView(title, LinearLayout.LayoutParams(0, -2, 1f).apply { leftMargin = dp(14) })
        val clear = text(this, "Clear all", 14f, C.INK, true)
        clear.gravity = Gravity.CENTER
        clear.pad(16, 0, 16, 0)
        clear.background = glass(this, 20f)
        clear.setOnClickListener {
            for (i in 0 until overviewBody.childCount) {
                overviewBody.getChildAt(i).animate().alpha(0f).translationY(-dpf(10f))
                    .scaleX(.88f).scaleY(.88f).setDuration(480).start()
            }
            for (i in 0 until tabsRow.childCount) {
                tabsRow.getChildAt(i).animate().alpha(0f).translationY(-dpf(10f)).setDuration(480).start()
            }
            playShine(overview)
            main.postDelayed({ browser.closeAllInMode() }, 480)
        }
        header.addView(clear, lp(-2, dp(40)))
        val add = iconButton(this, R.drawable.ic_plus, 44, 44, 22, "New tab")
        add.background = glass(this, 22f)
        add.setOnClickListener {
            hideOverview()
            browser.newTab()
        }
        header.addView(add, LinearLayout.LayoutParams(dp(44), dp(44)).apply { leftMargin = dp(8) })
        col.addView(header, lp(-1, -2))

        val scroll = ScrollView(this)
        overviewBody = LinearLayout(this)
        overviewBody.orientation = LinearLayout.VERTICAL
        overviewBody.pad(10, 4, 10, 24)
        scroll.addView(overviewBody, FrameLayout.LayoutParams(-1, -2))
        col.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        return shell
    }

    private fun showOverview() {
        closeMenu()
        hideKeyboard()
        captureThen(browser.active()) {
            buildOverview()
            overview.visibility = View.VISIBLE
            overview.arrive(20f)
        }
    }

    private fun hideOverview() {
        overview.visibility = View.GONE
    }

    private fun buildOverview() {
        overviewBody.removeAllViews()
        val list = browser.modeTabs()
        var row: LinearLayout? = null
        for ((i, tab) in list.withIndex()) {
            if (i % 2 == 0) {
                row = LinearLayout(this)
                overviewBody.addView(row, lp(-1, -2))
            }
            row?.addView(makeCard(tab), LinearLayout.LayoutParams(0, -2, 1f))
        }
        if (list.size % 2 == 1) row?.addView(View(this), LinearLayout.LayoutParams(0, 1, 1f))
    }

    private fun makeCard(tab: Tab): View {
        val active = tab.id == browser.activeId
        val wrap = FrameLayout(this)
        wrap.setPadding(dp(5), dp(5), dp(5), dp(5))
        val ring = FrameLayout(this)
        ring.setPadding(dp(3), dp(3), dp(3), dp(3))
        ring.background = if (active) skyRing(this, 24f) else null
        wrap.addView(ring, FrameLayout.LayoutParams(-1, -2))

        val card = LinearLayout(this)
        card.orientation = LinearLayout.VERTICAL
        card.background = if (active) solid(this, C.WHITE, 21f) else glass(this, 21f, C.CARD)
        ring.addView(card, FrameLayout.LayoutParams(-1, -2))

        val pic = ImageView(this)
        pic.scaleType = ImageView.ScaleType.CENTER_CROP
        pic.setBackgroundColor(C.SHADE)
        pic.clipToOutline = true
        pic.outlineProvider = object : ViewOutlineProvider() {
            override fun getOutline(view: View, outline: Outline) {
                val r = dpf(18f)
                outline.setRoundRect(0, 0, view.width, view.height + r.toInt(), r)
            }
        }
        val thumb = tab.thumb
        if (thumb != null) pic.setImageBitmap(thumb)
        card.addView(pic, LinearLayout.LayoutParams(-1, dp(150)))

        val bottom = LinearLayout(this)
        bottom.gravity = Gravity.CENTER_VERTICAL
        bottom.pad(10, 0, 4, 0)
        val label = oneLine(text(this, tab.label(), 13f))
        bottom.addView(label, LinearLayout.LayoutParams(0, -2, 1f))
        val close = icon(this, R.drawable.ic_close, 14)
        close.setPadding(dp(10), dp(10), dp(10), dp(10))
        close.setOnClickListener {
            wrap.isEnabled = false
            wrap.animate().alpha(0f).scaleX(.88f).scaleY(.88f).setDuration(200)
                .withEndAction { browser.close(tab) }.start()
        }
        bottom.addView(close, lp(dp(36), dp(36)))
        card.addView(bottom, lp(-1, dp(38)))

        card.setOnClickListener {
            hideOverview()
            browser.select(tab)
        }
        return wrap
    }

    /** A soft reflection that sweeps across the screen. */
    private fun playShine(host: FrameLayout) {
        val band = View(this)
        band.background = GradientDrawable(
            GradientDrawable.Orientation.LEFT_RIGHT,
            intArrayOf(0x00FFFFFF, 0xB3FFFFFF.toInt(), 0x00FFFFFF)
        )
        band.rotation = 14f
        val w = host.width.coerceAtLeast(dp(300))
        host.addView(band, FrameLayout.LayoutParams(dp(130), host.height + dp(200)).apply { topMargin = -dp(100) })
        band.translationX = -dp(200).toFloat()
        band.animate().translationX(w + dp(100).toFloat()).setDuration(800).withEndAction {
            host.removeView(band)
        }.start()
    }

    // ---- the menu ---------------------------------------------------------

    private fun closeMenu() {
        menu?.dismiss()
        menu = null
    }

    private fun showMenu() {
        if (menu != null) {
            closeMenu()
            return
        }
        val panel = LinearLayout(this)
        panel.orientation = LinearLayout.VERTICAL
        panel.pad(8, 8, 8, 8)

        fun item(res: Int, label: String, action: () -> Unit): TextView {
            val row = LinearLayout(this)
            row.gravity = Gravity.CENTER_VERTICAL
            row.pad(12, 0, 12, 0)
            row.background = withRipple(null)
            row.addView(icon(this, res, 27))
            val t = text(this, label, 16f)
            row.addView(t, LinearLayout.LayoutParams(-2, -2).apply { leftMargin = dp(17) })
            row.setOnClickListener {
                closeMenu()
                action()
            }
            panel.addView(row, lp(-1, dp(54)))
            return t
        }
        fun divider() {
            val d = View(this)
            d.setBackgroundColor(C.LINE)
            panel.addView(d, LinearLayout.LayoutParams(-1, dp(1)).apply {
                topMargin = dp(6)
                bottomMargin = dp(6)
                leftMargin = dp(7)
                rightMargin = dp(7)
            })
        }

        item(R.drawable.ic_newtab, "New tab") { browser.newTab() }
        val current = browser.active()
        item(R.drawable.ic_group, if (current?.grouped == true) "Remove tab from group" else "Move tab to group") {
            val t = browser.active()
            if (t != null) {
                t.grouped = !t.grouped
                rebuildPills()
                toast(if (t.grouped) "Tab moved to a group" else "Tab removed from its group")
            }
        }
        item(R.drawable.ic_copy, "Duplicate tab") {
            val t = browser.active()
            if (t != null && !t.home && Urls.isWeb(t.url)) browser.newTab(t.url, t.isPrivate)
            else toast("Open a page first")
        }
        item(R.drawable.ic_close, "Close other tabs") {
            val keep = browser.activeId
            val others = browser.modeTabs().filter { it.id != keep }
            for (t in others) browser.close(t)
            toast(if (others.isEmpty()) "No other tabs" else "Closed " + others.size + " tabs")
        }
        divider()
        item(R.drawable.ic_history, "History") { openTool("history") }
        item(R.drawable.ic_download, "Downloads") { openTool("downloads") }
        item(R.drawable.ic_bookmark, "Bookmarks") { openTool("bookmarks") }
        item(R.drawable.ic_recent, "Recent tabs") { openTool("recent") }
        if (browser.closed.isNotEmpty()) {
            item(R.drawable.ic_newtab, "Reopen closed tab") {
                val last = browser.closed.firstOrNull()
                if (last != null) browser.reopenClosed(last)
            }
        }
        divider()
        val here = browser.active()
        val saved = here != null && browser.bookmarks.any { it.url == here.url }
        item(R.drawable.ic_bookmark, if (saved) "Remove bookmark" else "Bookmark page") {
            val t = browser.active()
            if (t == null || t.isPrivate || t.home || !Urls.isWeb(t.url)) {
                toast("Open a page to bookmark")
            } else if (browser.bookmarks.any { it.url == t.url }) {
                browser.bookmarks.removeAll { it.url == t.url }
                browser.saveBookmarks()
                toast("Bookmark removed")
            } else {
                browser.bookmarks.add(0, Saved(t.label(), t.url))
                browser.saveBookmarks()
                toast("Bookmarked")
            }
        }
        item(R.drawable.ic_camera, "Save screenshot") { saveScreenshot() }
        item(R.drawable.ic_search, "Find in page") { showFind() }
        item(R.drawable.ic_copy, "Copy link") { copyLink() }
        item(R.drawable.ic_share, "Share page") { sharePage() }
        item(R.drawable.ic_desktop, if (prefs.desktop) "Mobile mode" else "Desktop mode") {
            browser.setDesktop(!prefs.desktop)
            toast(if (prefs.desktop) "Desktop mode on" else "Mobile mode on")
        }

        val zoom = LinearLayout(this)
        zoom.gravity = Gravity.CENTER_VERTICAL
        zoom.pad(12, 0, 4, 0)
        zoom.addView(icon(this, R.drawable.ic_zoom, 27))
        zoom.addView(text(this, "Zoom", 16f), LinearLayout.LayoutParams(0, -2, 1f).apply { leftMargin = dp(17) })
        fun step(label: String, delta: Int) {
            val b = text(this, label, 20f, C.INK, true)
            b.gravity = Gravity.CENTER
            b.background = withRipple(solid(this, C.SOFT, 16f))
            b.setOnClickListener {
                prefs.zoom += delta
                Engine.apply(prefs)
                zoomLabel?.text = prefs.zoom.toString() + "%"
            }
            zoom.addView(b, lp(dp(34), dp(34)))
        }
        step("−", -10)
        val z = text(this, prefs.zoom.toString() + "%", 13f)
        z.gravity = Gravity.CENTER
        zoomLabel = z
        zoom.addView(z, lp(dp(46), dp(34)))
        step("+", 10)
        panel.addView(zoom, lp(-1, dp(54)))
        divider()
        item(R.drawable.ic_tune, "Settings") { openTool("settings") }

        val scroller = android.widget.ScrollView(this)
        scroller.isVerticalScrollBarEnabled = false
        scroller.background = GradientDrawable().apply {
            cornerRadius = dpf(22f)
            setColor(if (C.dark) 0xEB262B29.toInt() else 0xE0FFFFFF.toInt())
            setStroke(dp(1), if (C.dark) 0x33FFFFFF else 0xCCFFFFFF.toInt())
        }
        scroller.clipToOutline = true
        panel.background = null
        scroller.addView(panel)
        val maxH = resources.displayMetrics.heightPixels - dp(130)
        val panelW = minOf(dp(330), resources.displayMetrics.widthPixels - dp(16))
        panel.measure(
            View.MeasureSpec.makeMeasureSpec(panelW, View.MeasureSpec.EXACTLY),
            View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED)
        )
        val popup = PopupWindow(scroller, panelW, minOf(panel.measuredHeight, maxH), true)
        popup.elevation = dpf(14f)
        popup.setBackgroundDrawable(null)
        popup.isOutsideTouchable = true
        popup.setOnDismissListener { menu = null }
        val where = IntArray(2)
        menuButton.getLocationOnScreen(where)
        val wantedLeft = resources.displayMetrics.widthPixels - dp(8) - panelW
        popup.showAsDropDown(menuButton, wantedLeft - where[0], dp(12))
        scroller.pivotX = panelW.toFloat()
        scroller.pivotY = 0f
        scroller.arrive(0f, -5f, .98f, 160)
        menu = popup
    }

    private fun sharePage() {
        val tab = browser.active()
        if (tab == null || tab.home || !Urls.isWeb(tab.url)) {
            toast("Open a page to share.")
            return
        }
        val send = Intent(Intent.ACTION_SEND)
        send.type = "text/plain"
        send.putExtra(Intent.EXTRA_SUBJECT, tab.title)
        send.putExtra(Intent.EXTRA_TEXT, tab.url)
        startActivity(Intent.createChooser(send, "Share page"))
    }

    // ---- tool pages: history, downloads, bookmarks, recent, settings -------

    private fun buildToolShell(): FrameLayout {
        val shell = FrameLayout(this)
        shell.setBackgroundColor(C.WHITE)
        shell.isClickable = true
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        shell.addView(col, FrameLayout.LayoutParams(-1, -1))

        val header = LinearLayout(this)
        header.gravity = Gravity.CENTER_VERTICAL
        header.pad(14, 12, 14, 8)
        val back = iconButton(this, R.drawable.ic_back, 44, 44, 24, "Back")
        back.background = solid(this, C.SOFT, 22f)
        back.setOnClickListener { closeTool() }
        header.addView(back)
        toolTitle = text(this, "", 24f, C.INK, true)
        header.addView(toolTitle, LinearLayout.LayoutParams(-2, -2).apply { leftMargin = dp(16) })
        col.addView(header, lp(-1, -2))

        val scroll = ScrollView(this)
        toolScroll = scroll
        toolBody = LinearLayout(this)
        toolBody.orientation = LinearLayout.VERTICAL
        toolBody.pad(16, 8, 16, 32)
        scroll.addView(toolBody, FrameLayout.LayoutParams(-1, -2))
        col.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))

        // Settings and Downloads draw their own full-height pages here instead of a plain list.
        toolCustom = FrameLayout(this)
        toolCustom.visibility = View.GONE
        col.addView(toolCustom, LinearLayout.LayoutParams(-1, 0, 1f))
        return shell
    }

    fun openTool(kind: String) {
        currentTool = kind
        hideKeyboard()
        renderTool()
        val wasShowing = toolPage.visibility == View.VISIBLE
        toolPage.visibility = View.VISIBLE
        if (!wasShowing) toolPage.arrive(20f)
    }

    /** Opens Settings on one of its sections: general, themes, privacy, passwords, downloads, data, about. */
    fun openSettings(section: String) {
        settingsSection = section
        openTool("settings")
    }

    private fun closeTool() {
        downloadsUi.stop()
        toolPage.visibility = View.GONE
        currentTool = ""
    }


    private fun renderTool() {
        downloadsUi.stop()
        toolBody.removeAllViews()
        toolCustom.removeAllViews()
        val custom = currentTool == "settings" || currentTool == "downloads"
        toolScroll.visibility = if (custom) View.GONE else View.VISIBLE
        toolCustom.visibility = if (custom) View.VISIBLE else View.GONE
        // The Downloads page draws its own big "Downloads" heading, like Chrome's.
        toolTitle.text = when (currentTool) {
            "history" -> "History"
            "downloads" -> ""
            "bookmarks" -> "Bookmarks"
            "recent" -> "Recent tabs"
            else -> "Settings"
        }
        when (currentTool) {
            "history" -> renderHistory()
            "downloads" -> {
                toolCustom.addView(downloadsUi.build(), FrameLayout.LayoutParams(-1, -1))
                downloadsUi.start()
            }
            "bookmarks" -> renderBookmarks()
            "recent" -> renderRecent()
            else -> toolCustom.addView(settingsUi.build(), FrameLayout.LayoutParams(-1, -1))
        }
    }

    private fun row(title: String, subtitle: String?, onClick: (() -> Unit)?, trailing: View? = null): LinearLayout {
        val r = LinearLayout(this)
        r.gravity = Gravity.CENTER_VERTICAL
        r.pad(6, 10, 6, 10)
        r.minimumHeight = dp(60)
        if (onClick != null) {
            r.background = withRipple(null)
            r.setOnClickListener { onClick() }
        }
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.addView(oneLine(text(this, title, 15.5f, C.INK, true)))
        if (!subtitle.isNullOrEmpty()) {
            val s = oneLine(text(this, subtitle, 12.5f, C.MUTED))
            col.addView(s, lp(-2, -2).apply { topMargin = dp(4) })
        }
        r.addView(col, LinearLayout.LayoutParams(0, -2, 1f))
        if (trailing != null) r.addView(trailing)
        toolBody.addView(r, lp(-1, -2))
        val d = View(this)
        d.setBackgroundColor(C.LINE)
        toolBody.addView(d, lp(-1, dp(1)))
        return r
    }

    private fun empty(message: String) {
        val t = text(this, message, 15f, C.MUTED)
        t.gravity = Gravity.CENTER
        t.pad(8, 40, 8, 40)
        toolBody.addView(t, lp(-1, -2))
    }

    private fun removeButton(onClick: () -> Unit): ImageView {
        val b = icon(this, R.drawable.ic_close, 16)
        b.setPadding(dp(10), dp(10), dp(10), dp(10))
        b.layoutParams = LinearLayout.LayoutParams(dp(40), dp(40))
        b.setOnClickListener { onClick() }
        return b
    }

    private fun openSaved(item: Saved) {
        closeTool()
        val tab = browser.active()
        if (tab != null && tab.home) browser.load(tab, item.url) else browser.newTab(item.url)
    }

    private fun renderHistory() {
        // Delete browsing data.
        val panel = LinearLayout(this)
        panel.orientation = LinearLayout.VERTICAL
        panel.background = solid(this, C.SOFT, 22f)
        panel.pad(16, 14, 16, 16)
        panel.addView(text(this, "Delete browsing data", 16f, C.INK, true))

        val chips = LinearLayout(this)
        fun chip(key: String, label: String) {
            val on = clearRange == key
            val c = text(this, label, 13f, if (on) C.ON_INK else C.INK, true)
            c.gravity = Gravity.CENTER
            c.background = solid(this, if (on) C.INK else C.CARD, 18f)
            c.setOnClickListener {
                clearRange = key
                renderTool()
            }
            chips.addView(c, LinearLayout.LayoutParams(0, dp(36), 1f).apply { rightMargin = dp(8) })
        }
        chip("hour", "Last hour")
        chip("day", "Today")
        chip("all", "All time")
        panel.addView(chips, lp(-1, -2).apply { topMargin = dp(10) })

        fun check(label: String, value: Boolean, set: (Boolean) -> Unit) {
            val cb = CheckBox(this)
            cb.text = label
            cb.textSize = 15f
            cb.setTextColor(C.INK)
            cb.isChecked = value
            cb.setOnCheckedChangeListener { _, v -> set(v) }
            panel.addView(cb, lp(-1, dp(44)))
        }
        check("Browsing history", clearHistory) { clearHistory = it }
        check("Cookies and site data", clearCookies) { clearCookies = it }
        check("Cached images and files", clearCache) { clearCache = it }

        val go = text(this, "Delete data", 15f, C.INK, true)
        go.gravity = Gravity.CENTER
        go.pad(26, 0, 26, 0)
        go.background = glass(this, 22f, C.CARD, C.EDGE_DARK)
        go.setOnClickListener {
            if (!clearHistory && !clearCookies && !clearCache) {
                toast("Choose what to delete.")
            } else {
                if (clearHistory) {
                    val now = System.currentTimeMillis()
                    val since = when (clearRange) {
                        "hour" -> now - 3600000L
                        "day" -> now - (now % 86400000L)
                        else -> 0L
                    }
                    browser.clearHistory(since)
                }
                Engine.clearData(clearCookies, clearCache)
                renderTool()
                playShine(toolPage)
                toast("Browsing data deleted.")
            }
        }
        panel.addView(go, lp(-2, dp(44)).apply { topMargin = dp(8) })
        toolBody.addView(panel, lp(-1, -2).apply { bottomMargin = dp(16) })

        if (browser.history.isEmpty()) {
            empty("Your browsing history will appear here.")
            return
        }
        val search = EditText(this)
        search.hint = "Search history"
        search.textSize = 15f
        search.isSingleLine = true
        search.background = solid(this, C.SOFT, 22f)
        search.pad(18, 0, 18, 0)
        toolBody.addView(search, lp(-1, dp(44)).apply { bottomMargin = dp(6) })

        val rows = ArrayList<Pair<View, String>>()
        val heads = ArrayList<View>()
        var last = ""
        val startOfDay = System.currentTimeMillis().let { it - (it % 86400000L) }
        for (item in browser.history.toList()) {
            val group = when {
                item.time <= 0L -> "Earlier"
                item.time >= startOfDay -> "Today"
                item.time >= startOfDay - 86400000L -> "Yesterday"
                else -> "Earlier"
            }
            if (group != last) {
                last = group
                val h = text(this, group.uppercase(), 12f, C.MUTED, true)
                h.pad(6, 14, 6, 2)
                toolBody.addView(h, lp(-1, -2))
                heads.add(h)
            }
            val before = toolBody.childCount
            row(item.title, Urls.display(item.url), { openSaved(item) },
                removeButton {
                    browser.history.remove(item)
                    browser.saveHistory()
                    renderTool()
                })
            for (i in before until toolBody.childCount) {
                rows.add(toolBody.getChildAt(i) to (item.title + " " + item.url).lowercase())
            }
        }
        search.addTextChangedListener(object : android.text.TextWatcher {
            override fun afterTextChanged(s: android.text.Editable?) {
                val q = s.toString().trim().lowercase()
                for ((v, key) in rows) v.visibility = if (q.isEmpty() || key.contains(q)) View.VISIBLE else View.GONE
                for (h in heads) h.visibility = if (q.isEmpty()) View.VISIBLE else View.GONE
            }
            override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
        })
    }

    private fun renderBookmarks() {
        val tab = browser.active()
        if (tab != null && !tab.isPrivate && !tab.home && Urls.isWeb(tab.url)) {
            val add = text(this, "+ Bookmark this page", 15f, C.INK, true)
            add.gravity = Gravity.CENTER
            add.background = solid(this, C.SOFT, 22f)
            add.setOnClickListener {
                if (browser.bookmarks.none { it.url == tab.url }) {
                    browser.bookmarks.add(0, Saved(tab.label(), tab.url))
                    browser.saveBookmarks()
                }
                renderTool()
            }
            toolBody.addView(add, lp(-1, dp(46)).apply { bottomMargin = dp(10) })
        }
        if (browser.bookmarks.isEmpty()) {
            empty("Your bookmarks will appear here.")
            return
        }
        for (b in browser.bookmarks.toList()) {
            row(b.title, Urls.display(b.url), { openSaved(b) }, removeButton {
                browser.bookmarks.remove(b)
                browser.saveBookmarks()
                renderTool()
            })
        }
    }

    private fun renderRecent() {
        if (browser.closed.isEmpty()) {
            empty("Tabs you close will appear here.")
            return
        }
        for (c in browser.closed.toList()) {
            row(c.title, Urls.display(c.url), {
                closeTool()
                browser.reopenClosed(c)
            })
        }
    }

    fun openBatterySettings() {
        try {
            startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
        } catch (e: Exception) {
            try {
                startActivity(
                    Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName"))
                )
            } catch (e2: Exception) {
                toast("Open Settings > Apps > Liquid Air > Battery")
            }
        }
    }

    // ---- long-press menu ----------------------------------------------------

    fun showContextMenu(tab: Tab, link: String?, src: String?, type: Int) {
        val labels = ArrayList<String>()
        val actions = ArrayList<() -> Unit>()
        if (link != null) {
            labels.add("Open in new tab")
            actions.add { browser.newTab(link, tab.isPrivate) }
            if (!tab.isPrivate) {
                labels.add("Open in private tab")
                actions.add { browser.newTab(link, true) }
            }
            labels.add("Download link")
            actions.add { downloads.fetch(link) }
            labels.add("Copy link")
            actions.add { copy(link) }
            labels.add("Share link")
            actions.add {
                val send = Intent(Intent.ACTION_SEND)
                send.type = "text/plain"
                send.putExtra(Intent.EXTRA_TEXT, link)
                startActivity(Intent.createChooser(send, "Share link"))
            }
        }
        if (src != null && type == GeckoSession.ContentDelegate.ContextElement.TYPE_IMAGE) {
            labels.add("Open image in new tab")
            actions.add { browser.newTab(src, tab.isPrivate) }
            labels.add("Save image")
            actions.add { downloads.fetch(src) }
            labels.add("Copy image link")
            actions.add { copy(src) }
        }
        if (labels.isEmpty()) return
        AlertDialog.Builder(this)
            .setItems(labels.toTypedArray<CharSequence>()) { _, which -> actions[which]() }
            .show()
    }

    private fun copy(value: String) {
        val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        cm.setPrimaryClip(ClipData.newPlainText("link", value))
        toast("Copied")
    }

    // ---- Android permissions and file picking -------------------------------

    fun askAndroid(wanted: List<String>, answer: (Boolean) -> Unit) {
        val missing = wanted.filter { checkSelfPermission(it) != PackageManager.PERMISSION_GRANTED }
        if (missing.isEmpty()) {
            answer(true)
            return
        }
        val code = askCode++
        androidAsks[code] = answer
        requestPermissions(missing.toTypedArray(), code)
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        val cb = androidAsks.remove(requestCode) ?: return
        cb(grantResults.isNotEmpty() && grantResults.all { it == PackageManager.PERMISSION_GRANTED })
    }

    fun pickFiles(mimeTypes: List<String>, multiple: Boolean, answer: (List<Uri>) -> Unit) {
        filePicked = answer
        val i = Intent(Intent.ACTION_GET_CONTENT)
        i.addCategory(Intent.CATEGORY_OPENABLE)
        i.type = if (mimeTypes.size == 1) mimeTypes[0] else "*/*"
        if (mimeTypes.size > 1) i.putExtra(Intent.EXTRA_MIME_TYPES, mimeTypes.toTypedArray())
        i.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, multiple)
        try {
            startActivityForResult(Intent.createChooser(i, "Choose a file"), REQ_FILE)
        } catch (e: Exception) {
            filePicked = null
            answer(emptyList())
        }
    }

    /** Lets the person choose a file to read (a bookmarks or passwords export). */
    fun pickDocument(onPicked: (Uri) -> Unit) {
        documentPicked = onPicked
        val i = Intent(Intent.ACTION_OPEN_DOCUMENT)
        i.addCategory(Intent.CATEGORY_OPENABLE)
        i.type = "*/*"
        try {
            startActivityForResult(i, REQ_OPEN_DOC)
        } catch (e: Exception) {
            documentPicked = null
            toast("No file picker found.")
        }
    }

    /** Lets the person choose where to save a new file. */
    fun createDocument(name: String, mime: String, onPicked: (Uri) -> Unit) {
        documentPicked = onPicked
        val i = Intent(Intent.ACTION_CREATE_DOCUMENT)
        i.addCategory(Intent.CATEGORY_OPENABLE)
        i.type = mime
        i.putExtra(Intent.EXTRA_TITLE, name)
        try {
            startActivityForResult(i, REQ_CREATE_DOC)
        } catch (e: Exception) {
            documentPicked = null
            toast("No file picker found.")
        }
    }

    /**
     * Asks for the phone's screen lock (PIN, pattern, fingerprint) before showing or exporting
     * passwords, like Chrome does. A recent check counts for two minutes. A phone with no screen
     * lock has nothing to ask, so the action just goes ahead.
     */
    fun requireAuth(reason: String, then: () -> Unit) {
        if (System.currentTimeMillis() - lastAuth < 120000L) {
            then()
            return
        }
        val km = getSystemService(Context.KEYGUARD_SERVICE) as KeyguardManager
        val intent = if (km.isDeviceSecure) km.createConfirmDeviceCredentialIntent("Liquid Air", reason) else null
        if (intent == null) {
            then()
            return
        }
        authThen = then
        try {
            startActivityForResult(intent, REQ_AUTH)
        } catch (e: Exception) {
            authThen = null
            toast("Couldn't ask for your screen lock.")
        }
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        when (requestCode) {
            REQ_AUTH -> {
                val then = authThen
                authThen = null
                if (resultCode == RESULT_OK) {
                    lastAuth = System.currentTimeMillis()
                    then?.invoke()
                } else {
                    toast("Not confirmed.")
                }
                return
            }
            REQ_OPEN_DOC, REQ_CREATE_DOC -> {
                val cb = documentPicked
                documentPicked = null
                val uri = data?.data
                if (resultCode == RESULT_OK && uri != null) cb?.invoke(uri)
                return
            }
        }
        if (requestCode != REQ_FILE) return
        val cb = filePicked ?: return
        filePicked = null
        val out = ArrayList<Uri>()
        if (resultCode == RESULT_OK && data != null) {
            val clip = data.clipData
            if (clip != null) {
                for (i in 0 until clip.itemCount) out.add(clip.getItemAt(i).uri)
            } else {
                data.data?.let { out.add(it) }
            }
        }
        cb(out)
    }

    // ---- the Back button -----------------------------------------------------

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        when {
            menu != null -> closeMenu()
            findBar.visibility == View.VISIBLE -> hideFind()
            toolPage.visibility == View.VISIBLE -> closeTool()
            overview.visibility == View.VISIBLE -> hideOverview()
            fullscreen -> browser.active()?.session?.exitFullScreen()
            else -> {
                val tab = browser.active()
                if (tab != null && browser.canBack(tab)) browser.back(tab)
                else if (tab != null && tab.openedByEngine && !tab.home && browser.modeTabs().size > 1) browser.close(tab)
                else moveTaskToBack(true)
            }
        }
    }

    companion object {
        private const val REQ_FILE = 1001
        private const val REQ_OPEN_DOC = 1002
        private const val REQ_CREATE_DOC = 1003
        private const val REQ_AUTH = 1004
    }
}
