package com.liquidair.browser

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

/** A saved page: used by history, bookmarks and "recent tabs". */
data class Saved(val title: String, val url: String, val time: Long = System.currentTimeMillis())

/** Everything the browser remembers between runs. */
class Prefs(context: Context) {
    private val sp = context.getSharedPreferences("liquid_air", Context.MODE_PRIVATE)

    var adBlock: Boolean
        get() = sp.getBoolean("adBlock", true)
        set(v) { sp.edit().putBoolean("adBlock", v).apply() }

    var bgPlay: Boolean
        get() = sp.getBoolean("bgPlay", true)
        set(v) { sp.edit().putBoolean("bgPlay", v).apply() }

    var safeSearch: Boolean
        get() = sp.getBoolean("safeSearch", true)
        set(v) { sp.edit().putBoolean("safeSearch", v).apply() }

    var desktop: Boolean
        get() = sp.getBoolean("desktop", false)
        set(v) { sp.edit().putBoolean("desktop", v).apply() }

    /** 0 = follow the system (default), 1 = always light, 2 = always dark. */
    var theme: Int
        get() = sp.getInt("theme", 0)
        set(v) { sp.edit().putInt("theme", v.coerceIn(0, 2)).apply() }

    /** 0 = Liquid Glass (the original look), 1 = Chrome + Perplexity. */
    var style: Int
        get() = sp.getInt("style", 0)
        set(v) { sp.edit().putInt("style", v.coerceIn(0, 1)).apply() }

    /** Chrome + Perplexity background: 0 = Paper, 1 = Gold glow, 2 = Blush, 3 = Sage, 4 = Sky. */
    var bgPreset: Int
        get() = sp.getInt("bgPreset", 0)
        set(v) { sp.edit().putInt("bgPreset", v.coerceIn(0, 4)).apply() }

    /** True when the person picked their own picture for the Chrome + Perplexity background. */
    var bgPicture: Boolean
        get() = sp.getBoolean("bgPicture", false)
        set(v) { sp.edit().putBoolean("bgPicture", v).apply() }

    /** What the start page shows under the search bar: 0 = Wikipedia overview, 1 = AI overview (Perplexity), 2 = nothing (the default). */
    var overview: Int
        get() = sp.getInt("overview", 2)
        set(v) { sp.edit().putInt("overview", v.coerceIn(0, 2)).apply() }

    /** Private tabs stay out of screenshots and the recent-apps picture. */
    var secureTabs: Boolean
        get() = sp.getBoolean("secureTabs", true)
        set(v) { sp.edit().putBoolean("secureTabs", v).apply() }

    var restoreTabs: Boolean
        get() = sp.getBoolean("restoreTabs", true)
        set(v) { sp.edit().putBoolean("restoreTabs", v).apply() }

    /** The pages that were open last time (normal tabs only), so they come back. */
    var session: String
        get() = sp.getString("session", "") ?: ""
        set(v) { sp.edit().putString("session", v).apply() }

    /** 0 = Google, 1 = Brave Search (the default), 2 = DuckDuckGo. */
    var searchEngine: Int
        get() = sp.getInt("searchEngine", 1)
        set(v) { sp.edit().putInt("searchEngine", v.coerceIn(0, 2)).apply() }

    var zoom: Int
        get() = sp.getInt("zoom", 100)
        set(v) { sp.edit().putInt("zoom", v.coerceIn(50, 150)).apply() }

    private fun flag(key: String, def: Boolean) = sp.getBoolean(key, def)
    private fun put(key: String, v: Boolean) { sp.edit().putBoolean(key, v).apply() }

    // ---- privacy and security -----------------------------------------------------------

    /** 0 = allow all cookies, 1 = block cross-site tracking cookies (default),
     *  2 = block all third-party cookies, 3 = block all cookies. */
    var cookieMode: Int
        get() = sp.getInt("cookieMode", 1)
        set(v) { sp.edit().putInt("cookieMode", v.coerceIn(0, 3)).apply() }

    /** Forget cookies and site data the next time Liquid Air starts. */
    var clearOnExit: Boolean
        get() = flag("clearOnExit", false)
        set(v) { put("clearOnExit", v) }

    /** Only open sites over a secure (https) connection. */
    var httpsOnly: Boolean
        get() = flag("httpsOnly", false)
        set(v) { put("httpsOnly", v) }

    /** Warn about phishing and malware pages. */
    var safeBrowsing: Boolean
        get() = flag("safeBrowsing", true)
        set(v) { put("safeBrowsing", v) }

    var fingerprint: Boolean
        get() = flag("fingerprint", true)
        set(v) { put("fingerprint", v) }

    /** The "Global Privacy Control" opt-out signal sent to sites. */
    var gpc: Boolean
        get() = flag("gpc", true)
        set(v) { put("gpc", v) }

    /** Remove utm_*, fbclid, gclid and friends from links. */
    var stripTracking: Boolean
        get() = flag("stripTracking", true)
        set(v) { put("stripTracking", v) }

    var blockPopups: Boolean
        get() = flag("blockPopups", true)
        set(v) { put("blockPopups", v) }

    /** Stop a page from launching another app on its own (no tap from the user). */
    var blockExternal: Boolean
        get() = flag("blockExternal", true)
        set(v) { put("blockExternal", v) }

    /** Ask before downloading programs/scripts or files from insecure (http) links. */
    var warnDownloads: Boolean
        get() = flag("warnDownloads", true)
        set(v) { put("warnDownloads", v) }

    var askLocation: Boolean
        get() = flag("askLocation", true)
        set(v) { put("askLocation", v) }

    var askMedia: Boolean
        get() = flag("askMedia", true)
        set(v) { put("askMedia", v) }

    var savePasswords: Boolean
        get() = flag("savePasswords", true)
        set(v) { put("savePasswords", v) }

    /** Sites where the user said "never save passwords". */
    var neverSave: Set<String>
        get() = HashSet(sp.getStringSet("neverSave", emptySet()) ?: emptySet())
        set(v) { sp.edit().putStringSet("neverSave", HashSet(v)).apply() }

    /** Downloads removed from the Downloads list (the files themselves are kept). */
    var hiddenDownloads: Set<Long>
        get() = (sp.getStringSet("hiddenDownloads", emptySet()) ?: emptySet())
            .mapNotNull { it.toLongOrNull() }.toHashSet()
        set(v) { sp.edit().putStringSet("hiddenDownloads", v.map { it.toString() }.toHashSet()).apply() }

    fun loadList(key: String): MutableList<Saved> {
        val out = ArrayList<Saved>()
        try {
            val arr = JSONArray(sp.getString(key, "[]"))
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                out.add(Saved(o.optString("t"), o.optString("u"), o.optLong("x")))
            }
        } catch (e: Exception) {
            // A damaged list is simply treated as empty.
        }
        return out
    }

    fun saveList(key: String, list: List<Saved>, max: Int) {
        val arr = JSONArray()
        for (item in list.take(max)) {
            arr.put(JSONObject().put("t", item.title).put("u", item.url).put("x", item.time))
        }
        sp.edit().putString(key, arr.toString()).apply()
    }
}
