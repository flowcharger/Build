package com.liquidair.browser

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

/** A saved page: used by history, bookmarks and "recent tabs". */
data class Saved(val title: String, val url: String, val time: Long = System.currentTimeMillis())

/** Everything the browser remembers between runs. */
class Prefs(context: Context) {
    private val sp = context.getSharedPreferences("liquid_air", Context.MODE_PRIVATE)

    var adBlock: Boolean
        get() = sp.getBoolean("adBlock", true)
        set(v) { sp.edit().putBoolean("adBlock", v).apply() }

    var bgPlay: Boolean
        get() = sp.getBoolean("bgPlay", true)
        set(v) { sp.edit().putBoolean("bgPlay", v).apply() }

    var safeSearch: Boolean
        get() = sp.getBoolean("safeSearch", true)
        set(v) { sp.edit().putBoolean("safeSearch", v).apply() }

    var desktop: Boolean
        get() = sp.getBoolean("desktop", false)
        set(v) { sp.edit().putBoolean("desktop", v).apply() }

    /** 0 = follow the system (default), 1 = always light, 2 = always dark. */
    var theme: Int
        get() = sp.getInt("theme", 0)
        set(v) { sp.edit().putInt("theme", v.coerceIn(0, 2)).apply() }

    var restoreTabs: Boolean
        get() = sp.getBoolean("restoreTabs", true)
        set(v) { sp.edit().putBoolean("restoreTabs", v).apply() }

    /** The pages that were open last time (normal tabs only), so they come back. */
    var session: String
        get() = sp.getString("session", "") ?: ""
        set(v) { sp.edit().putString("session", v).apply() }

    /** 0 = Google, 1 = Brave Search (the default), 2 = DuckDuckGo. */
    var searchEngine: Int
        get() = sp.getInt("searchEngine", 1)
        set(v) { sp.edit().putInt("searchEngine", v.coerceIn(0, 2)).apply() }

    var zoom: Int
        get() = sp.getInt("zoom", 100)
        set(v) { sp.edit().putInt("zoom", v.coerceIn(50, 150)).apply() }

    fun loadList(key: String): MutableList<Saved> {
        val out = ArrayList<Saved>()
        try {
            val arr = JSONArray(sp.getString(key, "[]"))
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                out.add(Saved(o.optString("t"), o.optString("u"), o.optLong("x")))
            }
        } catch (e: Exception) {
            // A damaged list is simply treated as empty.
        }
        return out
    }

    fun saveList(key: String, list: List<Saved>, max: Int) {
        val arr = JSONArray()
        for (item in list.take(max)) {
            arr.put(JSONObject().put("t", item.title).put("u", item.url).put("x", item.time))
        }
        sp.edit().putString(key, arr.toString()).apply()
    }
}
