package com.liquidair.browser

import java.net.URLEncoder

/** The search engines you can pick in Settings. Index 0..2 keep their old meaning (saved choices still work). */
object Engines {
    class Engine(val name: String, val search: String, val suggest: String?)

    const val CUSTOM = 12

    val all = listOf(
        Engine("Google", "https://www.google.com/search?q=%s", "https://suggestqueries.google.com/complete/search?client=firefox&q=%s"),
        Engine("Brave Search", "https://search.brave.com/search?q=%s", "https://search.brave.com/api/suggest?q=%s"),
        Engine("DuckDuckGo", "https://duckduckgo.com/?q=%s", "https://duckduckgo.com/ac/?type=list&q=%s"),
        Engine("Bing", "https://www.bing.com/search?q=%s", "https://api.bing.com/osjson.aspx?query=%s"),
        Engine("Startpage", "https://www.startpage.com/do/search?q=%s", null),
        Engine("Ecosia", "https://www.ecosia.org/search?q=%s", "https://ac.ecosia.org/autocomplete?type=list&q=%s"),
        Engine("Qwant", "https://www.qwant.com/?q=%s", null),
        Engine("Yahoo", "https://search.yahoo.com/search?p=%s", null),
        Engine("Yandex", "https://yandex.com/search/?text=%s", null),
        Engine("Mojeek", "https://www.mojeek.com/search?q=%s", null),
        Engine("Perplexity", "https://www.perplexity.ai/search?q=%s", null),
        Engine("Wikipedia", "https://en.wikipedia.org/wiki/Special:Search?search=%s&go=Go", "https://en.wikipedia.org/w/api.php?action=opensearch&limit=6&search=%s"),
        Engine("Custom...", "", null)
    )

    val names: Array<String> get() = all.map { it.name }.toTypedArray()

    fun name(index: Int, custom: String): String {
        val i = index.coerceIn(0, all.size - 1)
        return if (i == CUSTOM) (hostOf(custom).ifEmpty { "Custom" }) else all[i].name
    }

    private fun hostOf(t: String) = Urls.hostOf(t.replace("%s", "x")).removePrefix("www.")

    /** The address that searches for `query` (already URL-encoded) with the chosen engine. */
    fun searchUrl(index: Int, encoded: String, custom: String): String {
        val i = index.coerceIn(0, all.size - 1)
        val template = if (i == CUSTOM) {
            if (custom.contains("%s")) custom else all[0].search
        } else all[i].search
        return template.replace("%s", encoded)
    }

    /** The address that returns typed-ahead suggestions, or null if this engine has no open one. */
    fun suggestUrl(index: Int, text: String): String? {
        val i = index.coerceIn(0, all.size - 1)
        val t = all[i].suggest ?: return null
        return t.replace("%s", URLEncoder.encode(text, "UTF-8"))
    }
}
