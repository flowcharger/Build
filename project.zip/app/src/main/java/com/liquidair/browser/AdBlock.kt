package com.liquidair.browser

import android.content.Context

/**
 * The ad blocker has two layers that share one list of hosts (assets/adblock/hosts.txt):
 *
 *  1. A built-in network blocker (the extension in assets/adblock) that cancels requests to ad and
 *     tracker hosts — scripts, frames, pixels, beacons — before they leave the device.
 *  2. A navigation check in Browser.onLoadRequest that refuses to open an ad host as a page or
 *     frame (pop-unders and redirect ads).
 *
 * Neither layer ever edits a page's own HTML, CSS or images.
 */
object AdBlock {
    @Volatile
    var loaded = false
        private set

    /** Reads the host list on a background thread; the built-in hosts work meanwhile. */
    fun loadHosts(context: Context) {
        if (loaded) return
        val app = context.applicationContext
        Thread {
            try {
                val hosts = ArrayList<String>(45000)
                app.assets.open("adblock/hosts.txt").bufferedReader().useLines { lines ->
                    for (line in lines) {
                        val h = line.trim()
                        if (h.isNotEmpty()) hosts.add(h)
                    }
                }
                Urls.addAdHosts(hosts)
                loaded = true
            } catch (e: Exception) {
                // The short built-in list keeps working.
            }
        }.start()
    }
}
