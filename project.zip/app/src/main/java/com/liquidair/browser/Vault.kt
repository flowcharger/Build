package com.liquidair.browser

import android.content.Context
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import android.util.Base64
import org.json.JSONArray
import org.json.JSONObject
import org.mozilla.geckoview.Autocomplete
import org.mozilla.geckoview.GeckoResult
import java.security.KeyStore
import java.util.UUID
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec

/** One saved sign-in. [origin] looks like https://example.com (scheme + host [+ port]). */
data class Login(
    val id: String,
    val origin: String,
    val username: String,
    val password: String,
    val time: Long
) {
    val host: String get() = Urls.hostOf(origin).ifEmpty { origin }
}

/**
 * Saved passwords. They are encrypted with an AES-256 key that lives in the Android Keystore
 * (it never leaves the secure hardware/OS store), and the encrypted blob is all that is written
 * to disk. If the key is ever lost (a new phone, a wiped lock screen) the blob simply can't be
 * read and the vault comes back empty rather than showing garbage.
 */
class Vault(context: Context) {
    private val sp = context.applicationContext.getSharedPreferences("liquid_air_vault", Context.MODE_PRIVATE)
    private var cache: MutableList<Login>? = null

    /** False if this device can't give us a secure key: nothing is saved in that case. */
    var usable = true
        private set

    // ---- reading and changing -------------------------------------------------------------

    fun all(): List<Login> = load().toList()

    fun count(): Int = load().size

    /** Logins for a site. [domain] may be a host or its base domain (example.com). */
    fun forDomain(domain: String): List<Login> {
        val d = domain.lowercase().removePrefix("www.")
        if (d.isEmpty()) return emptyList()
        return load().filter {
            val h = it.host.lowercase().removePrefix("www.")
            h == d || h.endsWith(".$d") || d.endsWith(".$h")
        }
    }

    fun find(origin: String, username: String): Login? =
        load().firstOrNull { sameSite(it.origin, origin) && it.username == username }

    /** Adds a login, or updates the password if this site + username is already saved. */
    fun save(origin: String, username: String, password: String, id: String? = null): Boolean {
        val o = Urls.originOf(origin)
        if (o.isEmpty() || password.isEmpty()) return false
        val list = load()
        val at = list.indexOfFirst { (id != null && it.id == id) || (sameSite(it.origin, o) && it.username == username) }
        val login = Login(
            if (at >= 0) list[at].id else (id ?: UUID.randomUUID().toString()),
            o, username, password, System.currentTimeMillis()
        )
        if (at >= 0) list[at] = login else list.add(0, login)
        return persist(list)
    }

    fun delete(id: String) {
        val list = load()
        if (list.removeAll { it.id == id }) persist(list)
    }

    fun deleteAll() {
        persist(ArrayList())
    }

    // ---- comma-separated files (the Chrome / Brave / Firefox format) ----------------------

    /** name,url,username,password,note — the same columns Chrome and Brave export. */
    fun toCsv(): String {
        val sb = StringBuilder("name,url,username,password,note\r\n")
        for (l in load()) {
            sb.append(csv(l.host)).append(',').append(csv(l.origin)).append(',')
                .append(csv(l.username)).append(',').append(csv(l.password)).append(',').append("\"\"\r\n")
        }
        return sb.toString()
    }

    /** Reads a Chrome, Brave, Edge, Firefox or Bitwarden export. Returns how many were added. */
    fun importCsv(text: String): Int {
        val rows = parseCsv(text.removePrefix("﻿"))
        if (rows.size < 2) return 0
        val head = rows[0].map { it.trim().lowercase() }
        fun col(vararg names: String): Int {
            for (n in names) {
                val i = head.indexOf(n)
                if (i >= 0) return i
            }
            return -1
        }
        val cUrl = col("url", "login_uri", "login url", "origin", "website", "web site")
        val cUser = col("username", "login_username", "user", "login", "email")
        val cPass = col("password", "login_password", "pass")
        if (cUrl < 0 || cPass < 0) return 0
        val list = load()
        var added = 0
        for (r in rows.drop(1)) {
            fun at(i: Int) = if (i in r.indices) r[i].trim() else ""
            val origin = Urls.originOf(at(cUrl).let { if (it.contains("://")) it else "https://$it" })
            val pass = if (cPass in r.indices) r[cPass] else ""
            if (origin.isEmpty() || pass.isEmpty()) continue
            val user = at(cUser)
            val i = list.indexOfFirst { sameSite(it.origin, origin) && it.username == user }
            val login = Login(if (i >= 0) list[i].id else UUID.randomUUID().toString(), origin, user, pass, System.currentTimeMillis())
            if (i >= 0) {
                if (list[i].password == pass) continue
                list[i] = login
            } else {
                list.add(login)
            }
            added++
        }
        if (added > 0) persist(list)
        return added
    }

    private fun csv(s: String): String = "\"" + s.replace("\"", "\"\"") + "\""

    private fun parseCsv(text: String): List<List<String>> {
        val rows = ArrayList<List<String>>()
        var row = ArrayList<String>()
        val cell = StringBuilder()
        var quoted = false
        var i = 0
        while (i < text.length) {
            val c = text[i]
            when {
                quoted -> when {
                    c == '"' && i + 1 < text.length && text[i + 1] == '"' -> { cell.append('"'); i++ }
                    c == '"' -> quoted = false
                    else -> cell.append(c)
                }
                c == '"' -> quoted = true
                c == ',' -> { row.add(cell.toString()); cell.setLength(0) }
                c == '\n' || c == '\r' -> {
                    if (c == '\r' && i + 1 < text.length && text[i + 1] == '\n') i++
                    row.add(cell.toString()); cell.setLength(0)
                    if (row.any { it.isNotEmpty() }) rows.add(row)
                    row = ArrayList()
                }
                else -> cell.append(c)
            }
            i++
        }
        if (cell.isNotEmpty() || row.isNotEmpty()) {
            row.add(cell.toString())
            if (row.any { it.isNotEmpty() }) rows.add(row)
        }
        return rows
    }

    private fun sameSite(a: String, b: String): Boolean =
        Urls.hostOf(a).removePrefix("www.") == Urls.hostOf(b).removePrefix("www.")

    // ---- encrypted storage ----------------------------------------------------------------

    private fun load(): MutableList<Login> {
        cache?.let { return it }
        val out = ArrayList<Login>()
        try {
            val blob = sp.getString("blob", null)
            if (!blob.isNullOrEmpty()) {
                val raw = Base64.decode(blob, Base64.NO_WRAP)
                val iv = raw.copyOfRange(0, 12)
                val c = Cipher.getInstance("AES/GCM/NoPadding")
                c.init(Cipher.DECRYPT_MODE, key(), GCMParameterSpec(128, iv))
                val json = JSONArray(String(c.doFinal(raw, 12, raw.size - 12), Charsets.UTF_8))
                for (i in 0 until json.length()) {
                    val o = json.getJSONObject(i)
                    out.add(Login(o.getString("i"), o.getString("o"), o.optString("u"), o.getString("p"), o.optLong("t")))
                }
            }
        } catch (e: Exception) {
            // Unreadable (key gone or data damaged): start empty.
        }
        cache = out
        return out
    }

    private fun persist(list: MutableList<Login>): Boolean {
        return try {
            val json = JSONArray()
            for (l in list) {
                json.put(JSONObject().put("i", l.id).put("o", l.origin).put("u", l.username).put("p", l.password).put("t", l.time))
            }
            val c = Cipher.getInstance("AES/GCM/NoPadding")
            c.init(Cipher.ENCRYPT_MODE, key())
            val sealed = c.doFinal(json.toString().toByteArray(Charsets.UTF_8))
            sp.edit().putString("blob", Base64.encodeToString(c.iv + sealed, Base64.NO_WRAP)).apply()
            cache = list
            true
        } catch (e: Exception) {
            usable = false
            false
        }
    }

    private fun key(): SecretKey {
        val ks = KeyStore.getInstance("AndroidKeyStore")
        ks.load(null)
        if (!ks.containsAlias(ALIAS)) {
            val gen = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore")
            gen.init(
                KeyGenParameterSpec.Builder(ALIAS, KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT)
                    .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
                    .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
                    .setKeySize(256)
                    .build()
            )
            gen.generateKey()
        }
        return ks.getKey(ALIAS, null) as SecretKey
    }

    companion object {
        private const val ALIAS = "liquidair_vault_key"
    }
}

/**
 * Lets the engine's built-in login manager use the [Vault]: it asks for saved logins when a
 * sign-in form appears and hands over new ones after a successful sign-in.
 */
class LoginStorage(private val vault: Vault) : Autocomplete.StorageDelegate {

    private fun entry(l: Login): Autocomplete.LoginEntry =
        Autocomplete.LoginEntry.Builder()
            .guid(l.id)
            .origin(l.origin)
            .formActionOrigin(l.origin)
            .username(l.username)
            .password(l.password)
            .build()

    override fun onLoginFetch(domain: String): GeckoResult<Array<Autocomplete.LoginEntry>>? {
        val found = vault.forDomain(domain).map { entry(it) }
        return GeckoResult.fromValue(found.toTypedArray())
    }

    override fun onLoginFetch(): GeckoResult<Array<Autocomplete.LoginEntry>>? {
        return GeckoResult.fromValue(vault.all().map { entry(it) }.toTypedArray())
    }

    override fun onLoginSave(login: Autocomplete.LoginEntry) {
        // Same site + username updates in place, so this is safe to run after the save prompt
        // has already stored the login.
        vault.save(login.origin, login.username, login.password)
    }
}
