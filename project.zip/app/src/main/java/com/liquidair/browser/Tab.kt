package com.liquidair.browser

import android.graphics.Bitmap
import org.mozilla.geckoview.GeckoSession

/** One browser tab: a page session plus what the interface shows about it. */
class Tab(val id: Int, var session: GeckoSession, val isPrivate: Boolean) {
    var url: String = ""
    var title: String = ""

    /** True while the Liquid Air start page is showing instead of a website. */
    var home: Boolean = true

    /** True when the user went Back from the first page: Forward returns to the website. */
    var parkedHome: Boolean = false

    /** Marked with a ring ("Move tab to group"). */
    var grouped: Boolean = false

    var progress: Int = 0
    var loading: Boolean = false
    var canGoBack: Boolean = false
    var canGoForward: Boolean = false
    var desktop: Boolean = false

    var icon: Bitmap? = null
    var thumb: Bitmap? = null

    /** Gecko opens sessions it creates itself (pop-ups); we must not open those twice. */
    var openedByEngine: Boolean = false

    /** True while this tab's engine session has been let go to free memory. The tab still
     *  shows in the strip with its url/title/icon; it reloads the moment it's selected. */
    var suspended: Boolean = false

    val host: String get() = Urls.hostOf(url)

    /** What the tab pill and card call this tab. */
    fun label(): String {
        if (isPrivate) return "Private tab"
        if (home) return "New tab"
        val search = Urls.searchQuery(url)
        if (search != null) return "$search – Liquid Air"
        if (title.isNotBlank() && title != url) return title
        return host.ifEmpty { url }
    }
}
