package com.liquidair.browser

import android.app.AlertDialog
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.CheckBox
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.PopupWindow
import android.content.res.ColorStateList

/**
 * The question a website asks when it wants your location, camera or microphone. Like Chrome's, it
 * drops down from the gear next to the address bar (not in the middle of the screen) and the page
 * stays usable while it is open. If more than one site asks, they are shown one after another.
 */
class SitePrompt(private val act: MainActivity) {

    private class Request(
        val host: String,
        val what: String,
        val icon: Int,
        val answer: (allow: Boolean, remember: Boolean) -> Unit
    )

    private val queue = ArrayDeque<Request>()
    private var current: Request? = null
    private var popup: PopupWindow? = null
    private var done = false

    fun ask(host: String, what: String, icon: Int, answer: (Boolean, Boolean) -> Unit) {
        queue.addLast(Request(host, what, icon, answer))
        if (current == null) next()
    }

    /** The person moved to another tab or page: whatever was being asked is answered with "no", not remembered. */
    fun cancelAll() {
        val waiting = ArrayList<Request>(queue)
        queue.clear()
        finish(false, false)
        for (r in waiting) r.answer(false, false)
    }

    private fun finish(allow: Boolean, remember: Boolean) {
        val r = current ?: return
        if (done) return
        done = true
        current = null
        try {
            popup?.dismiss()
        } catch (e: Exception) {
        }
        popup = null
        r.answer(allow, remember)
        next()
    }

    private fun next() {
        val r = queue.removeFirstOrNull() ?: return
        current = r
        done = false
        val anchor = act.siteAnchor()
        if (anchor == null) {
            fallback(r)
            return
        }
        val card = LinearLayout(act)
        card.orientation = LinearLayout.VERTICAL
        card.pad(18, 16, 18, 12)
        card.background = GradientDrawable().apply {
            cornerRadius = act.dpf(14f)
            setColor(C.WHITE)
            setStroke(act.dp(1), C.LINE)
        }

        card.addView(text(act, r.host.removePrefix("www.").ifEmpty { "This site" } + " wants to", 14f, C.MUTED))
        val what = LinearLayout(act)
        what.gravity = Gravity.CENTER_VERTICAL
        what.addView(icon(act, r.icon, 22), LinearLayout.LayoutParams(act.dp(22), act.dp(22)).apply { rightMargin = act.dp(12) })
        what.addView(text(act, r.what, 17f, C.INK, true), LinearLayout.LayoutParams(0, -2, 1f))
        card.addView(what, LinearLayout.LayoutParams(-1, -2).apply { topMargin = act.dp(12) })

        val remember = CheckBox(act)
        remember.text = "Remember my choice"
        remember.isChecked = true
        remember.setTextColor(C.INK)
        remember.textSize = 13.5f
        remember.buttonTintList = ColorStateList.valueOf(C.LINK)
        card.addView(remember, LinearLayout.LayoutParams(-2, -2).apply { topMargin = act.dp(6) })

        val buttons = LinearLayout(act)
        buttons.gravity = Gravity.END or Gravity.CENTER_VERTICAL
        val block = button("Block", false) { finish(false, remember.isChecked) }
        val allow = button("Allow", true) { finish(true, remember.isChecked) }
        buttons.addView(block, LinearLayout.LayoutParams(-2, act.dp(38)))
        buttons.addView(allow, LinearLayout.LayoutParams(-2, act.dp(38)).apply { leftMargin = act.dp(8) })
        card.addView(buttons, LinearLayout.LayoutParams(-1, -2).apply { topMargin = act.dp(10) })

        // A little transparent margin lets the card's shadow show.
        val m = act.dp(10)
        val frame = FrameLayout(act)
        frame.clipChildren = false
        frame.clipToPadding = false
        frame.setPadding(m, m, m, m)
        card.elevation = act.dpf(8f)
        frame.addView(card, FrameLayout.LayoutParams(-1, -2))

        val width = minOf(act.dp(340), act.resources.displayMetrics.widthPixels - act.dp(8)) + 2 * m
        val pop = PopupWindow(frame, width, ViewGroup.LayoutParams.WRAP_CONTENT, false)
        pop.setBackgroundDrawable(null)
        pop.isOutsideTouchable = false
        popup = pop
        try {
            pop.showAsDropDown(anchor, -act.dp(6) - m, act.dp(6) - m)
            card.pivotX = 0f
            card.pivotY = 0f
            card.arrive(0f, -5f, .98f, 160)
        } catch (e: Exception) {
            popup = null
            fallback(r)
        }
    }

    private fun button(label: String, primary: Boolean, click: () -> Unit): android.widget.TextView {
        val b = text(act, label, 14.5f, if (primary) Color.WHITE else C.INK, true)
        b.gravity = Gravity.CENTER
        b.pad(20, 0, 20, 0)
        b.background = withRipple(solid(act, if (primary) C.LINK else C.SOFT, 19f))
        b.setOnClickListener { click() }
        return b
    }

    /** Only if the gear isn't on screen (full-screen video, say): an ordinary dialog. */
    private fun fallback(r: Request) {
        var answered = false
        fun once(allow: Boolean) {
            if (answered) return
            answered = true
            if (current === r) {
                current = null
                r.answer(allow, false)
                next()
            }
        }
        AlertDialog.Builder(act)
            .setMessage("Allow ${r.host.ifEmpty { "this site" }} to ${r.what.replaceFirstChar { it.lowercase() }}?")
            .setPositiveButton("Allow") { _, _ -> once(true) }
            .setNegativeButton("Block") { _, _ -> once(false) }
            .setOnCancelListener { once(false) }
            .show()
    }
}
