package com.liquidair.browser

import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Handler
import android.os.Looper
import org.mozilla.geckoview.AllowOrDeny
import org.mozilla.geckoview.GeckoResult
import org.mozilla.geckoview.GeckoSession
import org.mozilla.geckoview.GeckoSessionSettings
import org.mozilla.geckoview.WebRequestError
import org.mozilla.geckoview.WebResponse
import java.net.HttpURLConnection
import java.net.URL

/**
 * The brain: owns the tabs, the Normal/InPrivate mode, history and bookmarks, and
 * listens to what each page session reports. The screen only draws what it says.
 */
class Browser(private val act: MainActivity, val prefs: Prefs) {
    val tabs = ArrayList<Tab>()
    var privateMode = false
        private set
    var activeId = -1
        private set

    val history: MutableList<Saved> = prefs.loadList("history")
    val bookmarks: MutableList<Saved> = prefs.loadList("bookmarks")
    val closed = ArrayList<Saved>()

    private var nextId = 1
    private val lastActive = HashMap<Boolean, Int>()
    // Capped so a long session visiting many sites doesn't pile up favicons forever; the
    // oldest-fetched one is just dropped from the cache (never recycled — a tab showing it
    // right now keeps its own reference, so this never pulls an icon out from under a tab).
    private val icons = object : LinkedHashMap<String, Bitmap>(16, 0.75f, false) {
        override fun removeEldestEntry(eldest: MutableMap.MutableEntry<String, Bitmap>) = size > 120
    }
    private val main = Handler(Looper.getMainLooper())

    // ---- the tab list ---------------------------------------------------

    fun modeTabs(): List<Tab> = tabs.filter { it.isPrivate == privateMode }

    fun active(): Tab? = tabs.firstOrNull { it.id == activeId }

    fun bySession(session: GeckoSession): Tab? = tabs.firstOrNull { it.session === session }

    /** Make a tab. New tabs follow the current mode unless told otherwise. */
    fun newTab(input: String? = null, priv: Boolean = privateMode, select: Boolean = true, session: GeckoSession? = null): Tab {
        if (priv != privateMode) {
            privateMode = priv
        }
        val tab = Tab(nextId++, session ?: Engine.newSession(priv, prefs.desktop), priv)
        tab.desktop = prefs.desktop
        tab.openedByEngine = session != null
        bind(tab)
        tabs.add(tab)
        if (select) select(tab) else act.onTabsChanged()
        if (input != null) load(tab, input)
        return tab
    }

    fun select(tab: Tab) {
        activeId = tab.id
        lastActive[tab.isPrivate] = tab.id
        if (tab.isPrivate != privateMode) privateMode = tab.isPrivate
        act.onActiveChanged()
    }

    fun close(tab: Tab) {
        val index = tabs.indexOf(tab)
        if (index < 0) return
        if (!tab.isPrivate && !tab.home && Urls.isWeb(tab.url)) {
            closed.add(0, Saved(tab.label(), tab.url))
            while (closed.size > 20) closed.removeAt(closed.size - 1)
        }
        val wasActive = tab.id == activeId
        act.detach(tab)
        tabs.remove(tab)
        try {
            if (tab.session.isOpen) tab.session.close()
        } catch (e: Exception) {
            // Already closed by the engine.
        }
        if (wasActive) {
            val same = modeTabs()
            val next = same.firstOrNull { it.id == lastActive[privateMode] }
                ?: same.getOrNull(index.coerceAtMost(same.size - 1))
            if (next != null) select(next) else newTab()
        } else {
            act.onTabsChanged()
        }
    }

    /** Close every tab of the current mode (the other mode is untouched). */
    fun closeAllInMode() {
        for (t in modeTabs().toList()) {
            act.detach(t)
            tabs.remove(t)
            try {
                if (t.session.isOpen) t.session.close()
            } catch (e: Exception) {
            }
        }
        newTab()
    }

    fun reopenClosed(item: Saved) {
        closed.remove(item)
        val t = newTab(item.url, false)
        if (t.isPrivate != privateMode) act.onActiveChanged()
    }

    fun setMode(priv: Boolean) {
        if (priv == privateMode) return
        privateMode = priv
        val same = modeTabs()
        val target = same.firstOrNull { it.id == lastActive[priv] } ?: same.firstOrNull()
        if (target != null) select(target) else newTab()
    }

    // ---- navigation -----------------------------------------------------

    fun load(tab: Tab, input: String) {
        val url = Urls.resolveInput(input, prefs.safeSearch, prefs.searchEngine)
        if (url.isEmpty()) return
        tab.home = false
        tab.parkedHome = false
        tab.url = url
        tab.title = ""
        tab.icon = null
        ensureOpen(tab)
        if (tab.id == activeId) act.onActiveChanged()
        tab.session.loadUri(url)
    }

    private fun ensureOpen(tab: Tab) {
        if (!tab.session.isOpen && !tab.openedByEngine) {
            tab.session.open(Engine.runtime)
        }
    }

    fun back(tab: Tab) {
        if (tab.canGoBack) {
            tab.session.goBack()
        } else if (!tab.home) {
            tab.home = true
            tab.parkedHome = true
            act.onActiveChanged()
        }
    }

    fun forward(tab: Tab) {
        if (tab.home && tab.parkedHome) {
            tab.home = false
            tab.parkedHome = false
            act.onActiveChanged()
        } else if (tab.canGoForward) {
            tab.session.goForward()
        }
    }

    fun canBack(tab: Tab) = tab.canGoBack || !tab.home
    fun canForward(tab: Tab) = tab.canGoForward || (tab.home && tab.parkedHome)

    fun goHome(tab: Tab) {
        if (!tab.home) {
            tab.home = true
            tab.parkedHome = true
            act.onActiveChanged()
        }
    }

    fun reload(tab: Tab) {
        if (tab.loading) tab.session.stop() else if (!tab.home) tab.session.reload()
    }

    fun setDesktop(on: Boolean) {
        prefs.desktop = on
        for (t in tabs) {
            t.desktop = on
            applyDesktop(t)
        }
        active()?.let { if (!it.home) it.session.reload() }
    }

    private fun applyDesktop(tab: Tab) {
        val s = tab.session.settings
        s.userAgentMode = if (tab.desktop) GeckoSessionSettings.USER_AGENT_MODE_DESKTOP
        else GeckoSessionSettings.USER_AGENT_MODE_MOBILE
        s.viewportMode = if (tab.desktop) GeckoSessionSettings.VIEWPORT_MODE_DESKTOP
        else GeckoSessionSettings.VIEWPORT_MODE_MOBILE
    }

    // ---- history & bookmarks -------------------------------------------

    private fun record(tab: Tab) {
        if (tab.isPrivate || !Urls.isWeb(tab.url)) return
        val title = if (tab.title.isBlank()) Urls.display(tab.url) else tab.title
        val top = history.firstOrNull()
        if (top != null && top.url == tab.url) {
            history[0] = Saved(title, tab.url, top.time)
        } else {
            history.add(0, Saved(title, tab.url))
            while (history.size > 300) history.removeAt(history.size - 1)
        }
        prefs.saveList("history", history, 300)
    }

    fun saveHistory() = prefs.saveList("history", history, 300)
    fun saveBookmarks() = prefs.saveList("bookmarks", bookmarks, 200)

    fun clearHistory(sinceMillis: Long) {
        if (sinceMillis <= 0L) history.clear() else history.removeAll { it.time >= sinceMillis }
        saveHistory()
    }

    // ---- favicons -------------------------------------------------------

    private fun fetchIcon(tab: Tab) {
        if (tab.isPrivate || !Urls.isWeb(tab.url)) return
        val host = tab.host
        val cached = icons[host]
        if (cached != null) {
            tab.icon = cached
            return
        }
        val base = try {
            val u = URL(tab.url)
            u.protocol + "://" + u.host
        } catch (e: Exception) {
            return
        }
        Thread {
            var bmp: Bitmap? = null
            try {
                val c = URL("$base/favicon.ico").openConnection() as HttpURLConnection
                c.connectTimeout = 4000
                c.readTimeout = 4000
                c.instanceFollowRedirects = true
                if (c.responseCode == 200) {
                    val raw = BitmapFactory.decodeStream(c.inputStream)
                    if (raw != null) {
                        bmp = Bitmap.createScaledBitmap(raw, 48, 48, true)
                        // Only the 48x48 copy above is ever kept; free the full-size decode
                        // (often far bigger than 48x48) the moment it's no longer needed.
                        if (bmp !== raw) raw.recycle()
                    }
                }
                c.disconnect()
            } catch (e: Exception) {
                // No icon: the tab keeps its letter.
            }
            val result = bmp
            if (result != null) {
                main.post {
                    icons[host] = result
                    for (t in tabs) {
                        if (t.host == host && !t.isPrivate) {
                            t.icon = result
                            act.onTabChanged(t)
                        }
                    }
                }
            }
        }.start()
    }

    // ---- connecting a tab to its page session ---------------------------

    fun bind(tab: Tab) {
        val d = Delegates(tab)
        val s = tab.session
        s.navigationDelegate = d
        s.progressDelegate = d
        s.contentDelegate = d
        s.promptDelegate = d
        s.permissionDelegate = d
    }

    /** The engine process for a tab died: give the tab a fresh session and reload it. */
    private fun recover(tab: Tab) {
        val wasActive = tab.id == activeId
        act.detach(tab)
        try {
            if (tab.session.isOpen) tab.session.close()
        } catch (e: Exception) {
        }
        tab.session = Engine.newSession(tab.isPrivate, tab.desktop)
        tab.openedByEngine = false
        tab.canGoBack = false
        tab.canGoForward = false
        tab.loading = false
        bind(tab)
        if (!tab.home && tab.url.isNotEmpty()) {
            ensureOpen(tab)
            tab.session.loadUri(tab.url)
        }
        if (wasActive) act.onActiveChanged() else act.onTabsChanged()
    }

    // ---- memory ------------------------------------------------------------
    //
    // Each open engine session costs real RAM. A background tab the user isn't looking
    // at doesn't need to keep one alive: its url, title and thumbnail already say
    // everything the strip needs to show, and the page just reloads the moment it's
    // picked again. Keeping that count low leaves more headroom for everything else
    // on the device.

    /** Lets go of one background tab's engine session. Safe to call on any tab; it only
     *  acts on ones that are actually in the background, open, idle and not already gone. */
    fun suspend(tab: Tab) {
        if (tab.id == activeId || tab.home || tab.loading || tab.suspended) return
        if (!tab.session.isOpen) return
        act.detach(tab)
        try {
            tab.session.close()
        } catch (e: Exception) {
        }
        tab.suspended = true
    }

    /** Brings a suspended tab's session back and reloads its page. */
    private fun resume(tab: Tab) {
        if (!tab.suspended) return
        tab.suspended = false
        tab.session = Engine.newSession(tab.isPrivate, tab.desktop)
        tab.openedByEngine = false
        tab.canGoBack = false
        tab.canGoForward = false
        bind(tab)
        if (tab.url.isNotEmpty()) {
            ensureOpen(tab)
            tab.session.loadUri(tab.url)
        }
    }

    /** Called when a tab is about to be shown: wakes it up first if it had been let go. */
    fun wake(tab: Tab) {
        if (tab.suspended) resume(tab)
    }

    /** Keeps at most [keep] background tabs holding a live engine session; the rest are
     *  suspended. Call this whenever a tab opens or the app drops into the background. */
    fun trimBackgroundTabs(keep: Int) {
        val background = tabs.filter { it.id != activeId && !it.home && !it.suspended && it.session.isOpen && !it.loading }
        for (t in background.dropLast(keep.coerceAtLeast(0))) suspend(t)
    }

    private fun errorPage(uri: String?): String {
        val safe = (uri ?: "").replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")
            .replace("\"", "&quot;").replace("'", "&#39;")
        val html = "<html><head><meta name='viewport' content='width=device-width,initial-scale=1'>" +
            "<style>body{font-family:sans-serif;background:#f4f2e9;color:#1b1f1d;margin:0;padding:48px 28px;text-align:center}" +
            "h1{font-size:22px}p{color:#67716b;word-break:break-all}a{display:inline-block;margin-top:18px;padding:12px 26px;" +
            "border-radius:999px;background:#1b1f1d;color:#fff;text-decoration:none}</style></head><body>" +
            "<h1>This page can’t be opened</h1><p>$safe</p><a href=\"$safe\">Try again</a></body></html>"
        return "data:text/html;charset=utf-8," + Uri.encode(html)
    }

    private fun openExternal(uri: String): Boolean {
        return try {
            val intent = if (uri.startsWith("intent:", true)) {
                Intent.parseUri(uri, Intent.URI_INTENT_SCHEME).apply {
                    addCategory(Intent.CATEGORY_BROWSABLE)
                    selector = null
                }
            } else {
                Intent(Intent.ACTION_VIEW, Uri.parse(uri))
            }
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            act.startActivity(intent)
            true
        } catch (e: Exception) {
            false
        }
    }

    /** All the messages one page session sends us. */
    inner class Delegates(private val tab: Tab) :
        GeckoSession.NavigationDelegate,
        GeckoSession.ProgressDelegate,
        GeckoSession.ContentDelegate,
        GeckoSession.PromptDelegate,
        GeckoSession.PermissionDelegate {

        // -- navigation --

        override fun onLocationChange(
            session: GeckoSession,
            url: String?,
            perms: MutableList<GeckoSession.PermissionDelegate.ContentPermission>,
            hasUserGesture: Boolean
        ) {
            val u = url ?: ""
            if (u.isEmpty() || u == "about:blank") return
            val hostChanged = Urls.hostOf(u) != tab.host
            tab.url = u
            val wasHome = tab.home
            if (!tab.parkedHome) tab.home = false
            if (hostChanged) {
                tab.icon = null
                fetchIcon(tab)
            }
            if (wasHome && !tab.home && tab.id == activeId) act.onActiveChanged() else act.onTabChanged(tab)
        }

        override fun onCanGoBack(session: GeckoSession, canGoBack: Boolean) {
            tab.canGoBack = canGoBack
            act.onTabChanged(tab)
        }

        override fun onCanGoForward(session: GeckoSession, canGoForward: Boolean) {
            tab.canGoForward = canGoForward
            act.onTabChanged(tab)
        }

        override fun onLoadRequest(
            session: GeckoSession,
            request: GeckoSession.NavigationDelegate.LoadRequest
        ): GeckoResult<AllowOrDeny>? {
            val uri = request.uri
            val lower = uri.lowercase()
            if (lower.startsWith("javascript:") || lower.startsWith("file:")) {
                return GeckoResult.deny()
            }
            if (lower.startsWith("about:") && lower != "about:blank") {
                // Engine pages such as about:config are not for browsing.
                act.toast("That page is not available.")
                return GeckoResult.deny()
            }
            if (!(Urls.isWeb(uri) || lower.startsWith("about:") || lower.startsWith("data:") || lower.startsWith("blob:"))) {
                if (!openExternal(uri)) act.toast("No app can open this link.")
                return GeckoResult.deny()
            }
            if (Urls.isWeb(uri)) {
                val wanted = Urls.applySafeSearch(uri, prefs.safeSearch)
                if (wanted != uri) {
                    session.loadUri(wanted)
                    return GeckoResult.deny()
                }
                // Tracker blocking stays off on video sites and captcha pages.
                session.settings.useTrackingProtection = prefs.adBlock && !Urls.blockerOffFor(uri)
                // Known ad/iframe hosts are refused outright, on top of the engine's own
                // tracking protection. This only stops the ad's own navigation from loading —
                // it never changes anything about the page that embedded it.
                if (prefs.adBlock && !Urls.blockerOffFor(uri) && Urls.isAdHost(uri)) {
                    return GeckoResult.deny()
                }
            }
            return GeckoResult.allow()
        }

        override fun onNewSession(session: GeckoSession, uri: String): GeckoResult<GeckoSession>? {
            val fresh = Engine.newSession(tab.isPrivate, tab.desktop)
            val t = newTab(null, tab.isPrivate, true, fresh)
            t.home = false
            t.url = uri
            act.onActiveChanged()
            return GeckoResult.fromValue(fresh)
        }

        override fun onLoadError(
            session: GeckoSession,
            uri: String?,
            error: WebRequestError
        ): GeckoResult<String>? {
            return GeckoResult.fromValue(errorPage(uri))
        }

        // -- progress --

        override fun onPageStart(session: GeckoSession, url: String) {
            tab.loading = true
            tab.progress = 5
            act.onTabChanged(tab)
        }

        override fun onPageStop(session: GeckoSession, success: Boolean) {
            tab.loading = false
            tab.progress = 100
            if (success) record(tab)
            act.onTabChanged(tab)
        }

        override fun onProgressChange(session: GeckoSession, progress: Int) {
            tab.progress = progress
            act.onTabChanged(tab)
        }

        // -- content --

        override fun onTitleChange(session: GeckoSession, title: String?) {
            tab.title = title ?: ""
            record(tab)
            act.onTabChanged(tab)
        }

        override fun onFullScreen(session: GeckoSession, fullScreen: Boolean) {
            if (tab.id == activeId) act.setFullscreen(fullScreen)
        }

        override fun onCloseRequest(session: GeckoSession) {
            close(tab)
        }

        override fun onCrash(session: GeckoSession) {
            recover(tab)
        }

        override fun onKill(session: GeckoSession) {
            recover(tab)
        }

        override fun onContextMenu(
            session: GeckoSession,
            screenX: Int,
            screenY: Int,
            element: GeckoSession.ContentDelegate.ContextElement
        ) {
            act.showContextMenu(tab, element.linkUri, element.srcUri, element.type)
        }

        override fun onExternalResponse(session: GeckoSession, response: WebResponse) {
            act.downloads.save(response)
        }

        // -- prompts and permissions: drawn by the activity --

        override fun onAlertPrompt(session: GeckoSession, prompt: GeckoSession.PromptDelegate.AlertPrompt) =
            act.prompts.alert(prompt)

        override fun onButtonPrompt(session: GeckoSession, prompt: GeckoSession.PromptDelegate.ButtonPrompt) =
            act.prompts.button(prompt)

        override fun onTextPrompt(session: GeckoSession, prompt: GeckoSession.PromptDelegate.TextPrompt) =
            act.prompts.text(prompt)

        override fun onChoicePrompt(session: GeckoSession, prompt: GeckoSession.PromptDelegate.ChoicePrompt) =
            act.prompts.choice(prompt)

        override fun onFilePrompt(session: GeckoSession, prompt: GeckoSession.PromptDelegate.FilePrompt) =
            act.prompts.file(prompt)

        override fun onPopupPrompt(session: GeckoSession, prompt: GeckoSession.PromptDelegate.PopupPrompt):
            GeckoResult<GeckoSession.PromptDelegate.PromptResponse> =
            GeckoResult.fromValue(prompt.confirm(AllowOrDeny.DENY))

        override fun onAndroidPermissionsRequest(
            session: GeckoSession,
            permissions: Array<out String>?,
            callback: GeckoSession.PermissionDelegate.Callback
        ) {
            act.permissions.android(permissions, callback)
        }

        override fun onContentPermissionRequest(
            session: GeckoSession,
            perm: GeckoSession.PermissionDelegate.ContentPermission
        ): GeckoResult<Int>? = act.permissions.content(perm)

        override fun onMediaPermissionRequest(
            session: GeckoSession,
            uri: String,
            video: Array<out GeckoSession.PermissionDelegate.MediaSource>?,
            audio: Array<out GeckoSession.PermissionDelegate.MediaSource>?,
            callback: GeckoSession.PermissionDelegate.MediaCallback
        ) {
            act.permissions.media(uri, video, audio, callback)
        }
    }
}
