package com.liquidair.browser

import android.app.AlertDialog
import android.app.DownloadManager
import android.content.BroadcastReceiver
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.os.Handler
import android.os.Looper
import android.os.StatFs
import android.util.LruCache
import android.webkit.MimeTypeMap
import org.mozilla.geckoview.WebResponse
import java.util.Locale

private const val UA = "Mozilla/5.0 (Android 14; Mobile; rv:158.0) Gecko/158.0 Firefox/158.0"

/** "352 kB", "303.52 MB", "103.62 GB": the same units and rounding Chrome shows. */
fun fmtSize(bytes: Long): String {
    val b = bytes.coerceAtLeast(0L).toDouble()
    return when {
        b < 1000 -> "${b.toLong()} B"
        b < 1000 * 1000 -> String.format(Locale.US, "%d kB", Math.round(b / 1000))
        b < 1000.0 * 1000 * 1000 -> String.format(Locale.US, "%.2f MB", b / (1000.0 * 1000))
        else -> String.format(Locale.US, "%.2f GB", b / (1000.0 * 1000 * 1000))
    }
}

/**
 * Hands files to Android's own Download Manager — the same system service Chrome uses —
 * instead of fetching and writing them ourselves. That gets us resumable downloads, a
 * notification while it runs, and a listing in the system Downloads app for free. This class
 * also reads that list back for Liquid Air's own Downloads page.
 */
class Downloads(private val act: MainActivity) {

    /** One row of the Downloads page. */
    data class Item(
        val id: Long,
        val name: String,
        val url: String,
        val localUri: String?,
        val mime: String,
        val status: Int,
        val total: Long,
        val sofar: Long,
        val time: Long
    ) {
        val running get() = status == DownloadManager.STATUS_RUNNING ||
            status == DownloadManager.STATUS_PENDING || status == DownloadManager.STATUS_PAUSED
        val done get() = status == DownloadManager.STATUS_SUCCESSFUL
        val failed get() = status == DownloadManager.STATUS_FAILED
        val host get() = Urls.hostOf(url)
    }

    private val main = Handler(Looper.getMainLooper())
    private val thumbs = LruCache<Long, Bitmap>(40)
    private val dm get() = act.getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager

    /** Called when any download finishes, so an open Downloads page can refresh. */
    var onFinished: (() -> Unit)? = null

    // ---- starting downloads ---------------------------------------------------------------

    /** A response from the engine (a file the page wants to download). */
    fun save(response: WebResponse) {
        var disposition: String? = null
        var type: String? = null
        for ((k, v) in response.headers) {
            if (k.equals("content-disposition", true)) disposition = v
            if (k.equals("content-type", true)) type = v
        }
        begin(response.uri, fileName(disposition, response.uri), type)
    }

    /** A link the user typed on the Downloads page, or chose from a long-press menu. */
    fun fetch(url: String) {
        if (!Urls.isWeb(url)) {
            act.toast("Paste a full link that starts with https://")
            return
        }
        begin(url, fileName(null, url), null)
    }

    /** Warns first about programs and insecure links, like Chrome's "this file can harm your device". */
    private fun begin(url: String, name: String, mime: String?) {
        if (act.prefs.warnDownloads) {
            val warnings = ArrayList<String>()
            if (Urls.isRiskyFile(name, mime)) {
                warnings.add("This type of file can harm your device if you open it.")
            }
            if (url.startsWith("http://", true) && !isImage(name, mime)) {
                warnings.add("It is coming over an insecure connection, so it could have been changed on the way.")
            }
            if (warnings.isNotEmpty()) {
                AlertDialog.Builder(act)
                    .setTitle("Download $name?")
                    .setMessage(warnings.joinToString("\n\n") + "\n\n" + Urls.hostOf(url))
                    .setPositiveButton("Download anyway") { _, _ -> enqueue(url, name, mime) }
                    .setNegativeButton("Cancel", null)
                    .show()
                return
            }
        }
        enqueue(url, name, mime)
    }

    private fun enqueue(url: String, name: String, mime: String?) {
        try {
            val req = DownloadManager.Request(Uri.parse(url))
            req.addRequestHeader("User-Agent", UA)
            req.setTitle(name)
            req.setMimeType(mime?.substringBefore(';')?.trim()?.ifEmpty { null })
            req.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
            req.setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, name)
            req.setAllowedOverMetered(true)
            req.setAllowedOverRoaming(true)
            dm.enqueue(req)
            act.toast("Downloading $name")
        } catch (e: Exception) {
            act.toast("Couldn't start that download.")
        }
    }

    // ---- the list --------------------------------------------------------------------------

    /** Everything Liquid Air has downloaded, newest first, minus what was removed from the list. */
    fun list(): List<Item> {
        val hidden = act.prefs.hiddenDownloads
        val out = ArrayList<Item>()
        try {
            dm.query(DownloadManager.Query())?.use { c ->
                val iId = c.getColumnIndex(DownloadManager.COLUMN_ID)
                val iTitle = c.getColumnIndex(DownloadManager.COLUMN_TITLE)
                val iUri = c.getColumnIndex(DownloadManager.COLUMN_URI)
                val iLocal = c.getColumnIndex(DownloadManager.COLUMN_LOCAL_URI)
                val iType = c.getColumnIndex(DownloadManager.COLUMN_MEDIA_TYPE)
                val iStatus = c.getColumnIndex(DownloadManager.COLUMN_STATUS)
                val iTotal = c.getColumnIndex(DownloadManager.COLUMN_TOTAL_SIZE_BYTES)
                val iSoFar = c.getColumnIndex(DownloadManager.COLUMN_BYTES_DOWNLOADED_SO_FAR)
                val iTime = c.getColumnIndex(DownloadManager.COLUMN_LAST_MODIFIED_TIMESTAMP)
                while (c.moveToNext()) {
                    val id = c.getLong(iId)
                    if (hidden.contains(id)) continue
                    val local = if (iLocal >= 0) c.getString(iLocal) else null
                    val title = (if (iTitle >= 0) c.getString(iTitle) else null).orEmpty()
                    val shown = local?.let { Uri.parse(it).lastPathSegment }?.takeIf { it.isNotBlank() } ?: title
                    out.add(
                        Item(
                            id, shown.ifBlank { "download" },
                            (if (iUri >= 0) c.getString(iUri) else null).orEmpty(),
                            local,
                            (if (iType >= 0) c.getString(iType) else null).orEmpty(),
                            c.getInt(iStatus), c.getLong(iTotal), c.getLong(iSoFar), c.getLong(iTime)
                        )
                    )
                }
            }
        } catch (e: Exception) {
            // Treat an unreadable list as empty.
        }
        out.sortByDescending { it.time }
        return out
    }

    /** What the finished downloads add up to, and how big the storage they live on is. */
    fun usage(items: List<Item>): Pair<Long, Long> {
        val used = items.filter { it.done }.sumOf { if (it.total > 0) it.total else it.sofar }
        val total = try {
            StatFs(Environment.getExternalStorageDirectory().path).totalBytes
        } catch (e: Exception) {
            0L
        }
        return Pair(used, total)
    }

    // ---- kinds ----------------------------------------------------------------------------

    private fun ext(name: String) = name.substringAfterLast('.', "").lowercase(Locale.US)

    fun isImage(name: String, mime: String?): Boolean =
        (mime ?: "").startsWith("image/") ||
            ext(name) in setOf("png", "jpg", "jpeg", "gif", "webp", "bmp", "heic", "heif", "avif")

    /** 1 = image, 2 = web page, 3 = anything else. */
    fun kind(item: Item): Int {
        val m = item.mime.lowercase(Locale.US)
        return when {
            isImage(item.name, m) -> 1
            m.startsWith("text/html") || m == "application/xhtml+xml" || m == "multipart/related" ||
                ext(item.name) in setOf("html", "htm", "mhtml", "mht", "xhtml") -> 2
            else -> 3
        }
    }

    // ---- previews --------------------------------------------------------------------------

    /** A small picture of a downloaded image, made off the main thread and kept in a small cache. */
    fun thumbnail(item: Item, sizePx: Int, done: (Bitmap?) -> Unit) {
        thumbs.get(item.id)?.let {
            done(it)
            return
        }
        Thread {
            var bmp: Bitmap? = null
            try {
                val uri = dm.getUriForDownloadedFile(item.id)
                if (uri != null) {
                    val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
                    act.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
                    var sample = 1
                    while (bounds.outWidth / (sample * 2) >= sizePx && bounds.outHeight / (sample * 2) >= sizePx) sample *= 2
                    val opts = BitmapFactory.Options().apply { inSampleSize = sample }
                    bmp = act.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, opts) }
                }
            } catch (e: Exception) {
                // No preview: the tile keeps its plain background.
            }
            val result = bmp
            main.post {
                if (result != null) thumbs.put(item.id, result)
                done(result)
            }
        }.start()
    }

    // ---- actions ---------------------------------------------------------------------------

    private fun mimeOf(item: Item): String {
        val m = item.mime.substringBefore(';').trim()
        if (m.isNotEmpty() && m != "application/octet-stream") return m
        return MimeTypeMap.getSingleton().getMimeTypeFromExtension(ext(item.name)) ?: "*/*"
    }

    fun open(item: Item) {
        if (!item.done) return
        try {
            val uri = dm.getUriForDownloadedFile(item.id)
            if (uri == null) {
                act.toast("That file is gone.")
                return
            }
            val i = Intent(Intent.ACTION_VIEW)
            i.setDataAndType(uri, mimeOf(item))
            i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
            act.startActivity(i)
        } catch (e: Exception) {
            act.toast("No app can open this file.")
        }
    }

    fun share(item: Item) {
        if (!item.done) return
        try {
            val uri = dm.getUriForDownloadedFile(item.id) ?: return
            val send = Intent(Intent.ACTION_SEND)
            send.type = mimeOf(item)
            send.putExtra(Intent.EXTRA_STREAM, uri)
            send.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            act.startActivity(Intent.createChooser(send, "Share " + item.name))
        } catch (e: Exception) {
            act.toast("Couldn't share this file.")
        }
    }

    fun copyLink(item: Item) {
        val cm = act.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        cm.setPrimaryClip(ClipData.newPlainText("link", item.url))
        act.toast("Link copied")
    }

    /** Takes it off the list; the file stays on the device. */
    fun removeFromList(item: Item) {
        act.prefs.hiddenDownloads = act.prefs.hiddenDownloads + item.id
    }

    /** Takes every finished download off the list; the files stay on the device. */
    fun clearList() {
        val ids = list().filter { !it.running }.map { it.id }
        act.prefs.hiddenDownloads = act.prefs.hiddenDownloads + ids
    }

    /** Cancels a running download, or deletes the finished file. */
    fun delete(item: Item) {
        try {
            dm.remove(item.id)
            thumbs.remove(item.id)
        } catch (e: Exception) {
            act.toast("Couldn't delete that file.")
        }
    }

    fun retry(item: Item) {
        delete(item)
        if (Urls.isWeb(item.url)) enqueue(item.url, item.name, item.mime)
    }

    /** Opens the system Downloads app/list, same place Chrome's downloads land. */
    fun openSystemDownloads() {
        try {
            act.startActivity(Intent(DownloadManager.ACTION_VIEW_DOWNLOADS))
        } catch (e: Exception) {
            act.toast("No Downloads app found.")
        }
    }

    // ---- "download complete" ---------------------------------------------------------------

    private val receiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            val id = intent?.getLongExtra(DownloadManager.EXTRA_DOWNLOAD_ID, -1L) ?: -1L
            if (id < 0) return
            val item = list().firstOrNull { it.id == id }
            if (item != null && item.done) act.toast("Download complete: " + item.name)
            else if (item != null && item.failed) act.toast("Download failed: " + item.name)
            onFinished?.invoke()
        }
    }
    private var registered = false

    fun register() {
        if (registered) return
        val filter = IntentFilter(DownloadManager.ACTION_DOWNLOAD_COMPLETE)
        if (Build.VERSION.SDK_INT >= 33) act.registerReceiver(receiver, filter, Context.RECEIVER_EXPORTED)
        else act.registerReceiver(receiver, filter)
        registered = true
    }

    fun unregister() {
        if (!registered) return
        try {
            act.unregisterReceiver(receiver)
        } catch (e: Exception) {
        }
        registered = false
    }

    // ---- file names ------------------------------------------------------------------------

    private fun fileName(disposition: String?, url: String): String {
        if (disposition != null) {
            val m = Regex("filename\\*?=(?:UTF-8'')?\"?([^\";]+)\"?", RegexOption.IGNORE_CASE).find(disposition)
            if (m != null) return clean(Uri.decode(m.groupValues[1]))
        }
        val last = url.substringBefore('?').substringBefore('#').trimEnd('/').substringAfterLast('/')
        return clean(Uri.decode(last)).ifEmpty { "download" }
    }

    /** No folders, no odd characters, no leading dots (so a name can never climb out of Downloads). */
    private fun clean(s: String): String =
        s.replace(Regex("[\\\\/:*?\"<>|\\u0000-\\u001f]"), "_").trim().trimStart('.').take(120)
}
