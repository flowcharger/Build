package com.liquidair.browser

import android.app.DownloadManager
import android.content.Context
import android.net.Uri
import android.os.Environment
import org.mozilla.geckoview.WebResponse

private const val UA = "Mozilla/5.0 (Android 14; Mobile; rv:158.0) Gecko/158.0 Firefox/158.0"

/**
 * Hands files to Android's own Download Manager — the same system service Chrome uses —
 * instead of fetching and writing them ourselves. That gets us resumable downloads, a
 * notification while it runs, and a listing in the system Downloads app for free.
 */
class Downloads(private val act: MainActivity) {

    /** A response from the engine (a file the page wants to download). */
    fun save(response: WebResponse) {
        var disposition: String? = null
        var type: String? = null
        for ((k, v) in response.headers) {
            if (k.equals("content-disposition", true)) disposition = v
            if (k.equals("content-type", true)) type = v
        }
        enqueue(response.uri, fileName(disposition, response.uri), type)
    }

    /** A link the user typed on the Downloads page, or chose from a long-press menu. */
    fun fetch(url: String) {
        if (!Urls.isWeb(url)) {
            act.toast("Paste a full link that starts with https://")
            return
        }
        enqueue(url, fileName(null, url), null)
    }

    private fun enqueue(url: String, name: String, mime: String?) {
        try {
            val req = DownloadManager.Request(Uri.parse(url))
            req.addRequestHeader("User-Agent", UA)
            req.setTitle(name)
            req.setMimeType(mime?.substringBefore(';')?.trim()?.ifEmpty { null })
            req.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
            req.setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, name)
            req.setAllowedOverMetered(true)
            req.setAllowedOverRoaming(true)
            val dm = act.getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager
            dm.enqueue(req)
            act.toast("Downloading $name")
        } catch (e: Exception) {
            act.toast("Couldn't start that download.")
        }
    }

    /** Opens the system Downloads app/list, same place Chrome's downloads land. */
    fun openSystemDownloads() {
        try {
            act.startActivity(android.content.Intent(DownloadManager.ACTION_VIEW_DOWNLOADS))
        } catch (e: Exception) {
            act.toast("No Downloads app found.")
        }
    }

    private fun fileName(disposition: String?, url: String): String {
        if (disposition != null) {
            val m = Regex("filename\\*?=(?:UTF-8'')?\"?([^\";]+)\"?", RegexOption.IGNORE_CASE).find(disposition)
            if (m != null) return clean(Uri.decode(m.groupValues[1]))
        }
        val last = url.substringBefore('?').substringBefore('#').trimEnd('/').substringAfterLast('/')
        return clean(Uri.decode(last)).ifEmpty { "download" }
    }

    private fun clean(s: String) = s.replace(Regex("[\\\\/:*?\"<>|]"), "_").trim()
}
