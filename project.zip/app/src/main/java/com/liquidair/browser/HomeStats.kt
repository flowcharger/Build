package com.liquidair.browser

import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.View
import android.widget.LinearLayout
import android.widget.TextView
import java.util.Locale
import java.util.concurrent.atomic.AtomicInteger

/** The dark, see-through look the start page cards share (they sit on the wallpaper, so they stay dark in every theme). */
object Glass {
    val CARD = 0xCC2E3140.toInt()
    const val TEXT = 0xFFFFFFFF.toInt()
    const val MUTED = 0xFFB9BDCB.toInt()
}

/** Running totals of what the blocker stopped, shown at the top of the start page. */
object Stats {
    private val pending = AtomicInteger(0)

    fun add(n: Int) {
        pending.addAndGet(n)
    }

    /** Moves what was counted since the last call into the saved total. */
    fun flush(prefs: Prefs) {
        val n = pending.getAndSet(0)
        if (n > 0) prefs.totalBlocked = prefs.totalBlocked + n
    }

    fun total(prefs: Prefs): Long = prefs.totalBlocked + pending.get()

    /** About 25 KB of ad and tracker data per stopped request. */
    fun dataText(blocked: Long): Pair<String, String> {
        val kb = blocked * 25
        return when {
            kb >= 1024L * 1024 -> String.format(Locale.US, "%.1f", kb / 1048576.0) to "GB"
            kb >= 1024 -> String.format(Locale.US, "%d", kb / 1024) to "MB"
            else -> kb.toString() to "KB"
        }
    }

    /** About 60 ms of loading time per stopped request. */
    fun timeText(blocked: Long): Pair<String, String> {
        val sec = blocked * 60 / 1000
        return when {
            sec >= 3600 -> String.format(Locale.US, "%.1f", sec / 3600.0) to "h"
            sec >= 60 -> (sec / 60).toString() to "m"
            else -> sec.toString() to "s"
        }
    }

    fun countText(n: Long): Pair<String, String> {
        return when {
            n >= 1_000_000 -> String.format(Locale.US, "%.1f", n / 1_000_000.0) to "M"
            n >= 1000 -> (n / 1000).toString() to "K"
            else -> n.toString() to ""
        }
    }
}

/** The "Privacy stats" card: trackers and ads blocked, data saved and time saved (estimates). */
fun buildStats(act: MainActivity): View {
    val card = LinearLayout(act)
    card.orientation = LinearLayout.VERTICAL
    card.background = solid(act, Glass.CARD, 18f)
    card.pad(14, 10, 8, 14)

    val top = LinearLayout(act)
    top.gravity = Gravity.CENTER_VERTICAL
    val shield = icon(act, R.drawable.ic_shield, 14)
    shield.setColorFilter(Glass.TEXT)
    top.addView(shield, LinearLayout.LayoutParams(act.dp(14), act.dp(14)).apply { rightMargin = act.dp(6) })
    top.addView(text(act, "Privacy Stats", 12.5f, Glass.TEXT, true), LinearLayout.LayoutParams(0, -2, 1f))
    val hide = iconButton(act, R.drawable.ic_eye_off, 32, 32, 16, "Hide privacy stats")
    hide.iconView()?.setColorFilter(Glass.MUTED)
    hide.setOnClickListener {
        act.prefs.statsOn = false
        var p = card.parent
        while (p != null && p !is CappedFrame) p = p.parent
        (p as? View)?.visibility = View.GONE
    }
    top.addView(hide, LinearLayout.LayoutParams(act.dp(32), act.dp(32)))
    card.addView(top)

    val row = LinearLayout(act)
    row.gravity = Gravity.CENTER_VERTICAL
    card.addView(row, LinearLayout.LayoutParams(-1, -2).apply { topMargin = act.dp(4); rightMargin = act.dp(6) })

    fun cell(label: String, color: Int): TextView {
        val c = LinearLayout(act)
        c.orientation = LinearLayout.VERTICAL
        c.gravity = Gravity.CENTER_HORIZONTAL
        val n = text(act, "0", 28f, color, false)
        c.addView(n)
        val l = text(act, label, 11.5f, Glass.TEXT)
        l.gravity = Gravity.CENTER
        c.addView(l)
        row.addView(c, LinearLayout.LayoutParams(0, -2, 1f))
        return n
    }
    val a = cell("Trackers & Ads\nBlocked", 0xFFF28B5C.toInt())
    val b = cell("Est. Data\nSaved", 0xFFA8A3FF.toInt())
    val t = cell("Est. Time\nSaved", 0xFF9CC4FF.toInt())

    fun fill() {
        Stats.flush(act.prefs)
        val total = act.prefs.totalBlocked
        fun set(v: TextView, p: Pair<String, String>) {
            val s = android.text.SpannableString(p.first + p.second)
            s.setSpan(android.text.style.RelativeSizeSpan(0.55f), p.first.length, s.length, 0)
            v.text = s
        }
        set(a, Stats.countText(total))
        set(b, Stats.dataText(total))
        set(t, Stats.timeText(total))
    }
    fill()
    card.addOnAttachStateChangeListener(object : View.OnAttachStateChangeListener {
        override fun onViewAttachedToWindow(v: View) { fill() }
        override fun onViewDetachedFromWindow(v: View) {}
    })
    return card
}

/** The row of most-visited sites under the stats (from your history, or bookmarks if there is none yet). */
fun buildTopSites(act: MainActivity): View {
    val scroll = android.widget.HorizontalScrollView(act)
    scroll.isHorizontalScrollBarEnabled = false
    val row = LinearLayout(act)
    row.pad(2, 6, 2, 6)
    scroll.addView(row)

    fun fill() {
        row.removeAllViews()
        val counts = LinkedHashMap<String, Int>()
        val first = HashMap<String, Saved>()
        for (h in act.browser.history) {
            val host = Urls.hostOf(h.url).removePrefix("www.")
            if (host.isEmpty() || !Urls.isWeb(h.url)) continue
            counts[host] = (counts[host] ?: 0) + 1
            if (!first.containsKey(host)) first[host] = h
        }
        var hosts = counts.entries.sortedByDescending { it.value }.map { it.key }
        if (hosts.isEmpty()) {
            for (b in act.browser.bookmarks) {
                val host = Urls.hostOf(b.url).removePrefix("www.")
                if (host.isNotEmpty() && !first.containsKey(host)) first[host] = b
            }
            hosts = first.keys.toList()
        }
        for (host in hosts.take(12)) {
            val site = first[host] ?: continue
            val tile = LinearLayout(act)
            tile.orientation = LinearLayout.VERTICAL
            tile.gravity = Gravity.CENTER_HORIZONTAL
            tile.pad(4, 2, 4, 2)
            val disc = TextView(act)
            disc.text = host.take(1).uppercase(Locale.US)
            disc.setTextColor(Glass.TEXT)
            disc.textSize = 20f
            disc.typeface = android.graphics.Typeface.DEFAULT_BOLD
            disc.gravity = Gravity.CENTER
            disc.background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(Glass.CARD)
            }
            tile.addView(disc, LinearLayout.LayoutParams(act.dp(52), act.dp(52)))
            val label = text(act, host.substringBefore('.').replaceFirstChar { it.uppercase() }, 12f, Glass.TEXT)
            label.maxLines = 1
            label.gravity = Gravity.CENTER
            label.setShadowLayer(6f, 0f, 1f, 0x99000000.toInt())
            tile.addView(label, LinearLayout.LayoutParams(act.dp(64), -2).apply { topMargin = act.dp(5) })
            tile.setOnClickListener { act.openLink(site.url) }
            row.addView(tile, LinearLayout.LayoutParams(act.dp(72), -2))
        }
    }
    fill()
    scroll.addOnAttachStateChangeListener(object : View.OnAttachStateChangeListener {
        override fun onViewAttachedToWindow(v: View) { fill() }
        override fun onViewDetachedFromWindow(v: View) {}
    })
    return scroll
}
