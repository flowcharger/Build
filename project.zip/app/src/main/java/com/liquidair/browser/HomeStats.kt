package com.liquidair.browser

import android.view.Gravity
import android.view.View
import android.widget.LinearLayout
import android.widget.TextView
import java.util.Locale
import java.util.concurrent.atomic.AtomicInteger

/** Running totals of what the blocker stopped, shown at the top of the start page. */
object Stats {
    private val pending = AtomicInteger(0)

    fun add(n: Int) {
        pending.addAndGet(n)
    }

    /** Moves what was counted since the last call into the saved total. */
    fun flush(prefs: Prefs) {
        val n = pending.getAndSet(0)
        if (n > 0) prefs.totalBlocked = prefs.totalBlocked + n
    }

    fun total(prefs: Prefs): Long = prefs.totalBlocked + pending.get()

    /** About 25 KB of ad and tracker data per stopped request. */
    fun dataText(blocked: Long): Pair<String, String> {
        val kb = blocked * 25
        return when {
            kb >= 1024L * 1024 -> String.format(Locale.US, "%.1f", kb / 1048576.0) to "GB"
            kb >= 1024 -> String.format(Locale.US, "%d", kb / 1024) to "MB"
            else -> kb.toString() to "KB"
        }
    }

    /** About 60 ms of loading time per stopped request. */
    fun timeText(blocked: Long): Pair<String, String> {
        val sec = blocked * 60 / 1000
        return when {
            sec >= 3600 -> String.format(Locale.US, "%.1f", sec / 3600.0) to "h"
            sec >= 60 -> (sec / 60).toString() to "m"
            else -> sec.toString() to "s"
        }
    }

    fun countText(n: Long): Pair<String, String> {
        return when {
            n >= 1_000_000 -> String.format(Locale.US, "%.1f", n / 1_000_000.0) to "M"
            n >= 1000 -> (n / 1000).toString() to "K"
            else -> n.toString() to ""
        }
    }
}

/** The "Privacy stats" card: trackers and ads blocked, data saved and time saved (estimates). */
fun buildStats(act: MainActivity): View {
    val card = LinearLayout(act)
    card.orientation = LinearLayout.VERTICAL
    card.background = solid(act, C.CARD, 18f)
    card.pad(16, 12, 16, 14)

    val title = text(act, "Privacy stats", 12.5f, C.MUTED, true)
    card.addView(title)

    val row = LinearLayout(act)
    row.gravity = Gravity.CENTER_VERTICAL
    card.addView(row, LinearLayout.LayoutParams(-1, -2).apply { topMargin = act.dp(8) })

    val numbers = ArrayList<TextView>()
    fun cell(label: String): TextView {
        val c = LinearLayout(act)
        c.orientation = LinearLayout.VERTICAL
        c.gravity = Gravity.CENTER_HORIZONTAL
        val n = text(act, "0", 26f, C.LINK, true)
        c.addView(n)
        val l = text(act, label, 12f, C.MUTED)
        l.gravity = Gravity.CENTER
        c.addView(l)
        row.addView(c, LinearLayout.LayoutParams(0, -2, 1f))
        numbers.add(n)
        return n
    }
    val a = cell("Trackers & ads\nblocked")
    val b = cell("Est. data\nsaved")
    val t = cell("Est. time\nsaved")

    fun fill() {
        Stats.flush(act.prefs)
        val total = act.prefs.totalBlocked
        fun set(v: TextView, p: Pair<String, String>) {
            val s = android.text.SpannableString(p.first + p.second)
            s.setSpan(android.text.style.RelativeSizeSpan(0.55f), p.first.length, s.length, 0)
            v.text = s
        }
        set(a, Stats.countText(total))
        set(b, Stats.dataText(total))
        set(t, Stats.timeText(total))
    }
    fill()
    card.addOnAttachStateChangeListener(object : View.OnAttachStateChangeListener {
        override fun onViewAttachedToWindow(v: View) { fill() }
        override fun onViewDetachedFromWindow(v: View) {}
    })
    return card
}
