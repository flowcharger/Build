package com.liquidair.browser

import android.content.Context
import android.content.SharedPreferences
import org.json.JSONObject
import org.mozilla.geckoview.GeckoResult
import org.mozilla.geckoview.WebExtension
import java.util.concurrent.ConcurrentHashMap

/**
 * What the user chose for one website: ads on/off, JavaScript on/off, and what to do when the site
 * asks for location, camera or microphone. Anything not chosen follows the global Settings.
 */
object Sites {
    const val ASK = 0
    const val ALLOW = 1
    const val BLOCK = 2

    private var sp: SharedPreferences? = null

    fun init(context: Context) {
        if (sp == null) sp = context.applicationContext.getSharedPreferences("liquid_air_sites", Context.MODE_PRIVATE)
    }

    private fun key(kind: String, host: String) = "$kind:${host.removePrefix("www.")}"

    private fun getInt(kind: String, host: String, def: Int): Int =
        if (host.isEmpty()) def else sp?.getInt(key(kind, host), def) ?: def

    private fun putInt(kind: String, host: String, v: Int, def: Int) {
        if (host.isEmpty()) return
        val e = sp?.edit() ?: return
        if (v == def) e.remove(key(kind, host)) else e.putInt(key(kind, host), v)
        e.apply()
    }

    fun ads(host: String): Boolean = getInt("ads", host, 1) == 1
    fun setAds(host: String, on: Boolean) = putInt("ads", host, if (on) 1 else 0, 1)

    fun js(host: String): Boolean = getInt("js", host, 1) == 1
    fun setJs(host: String, on: Boolean) = putInt("js", host, if (on) 1 else 0, 1)

    /** ASK, ALLOW or BLOCK for location. */
    fun location(host: String): Int = getInt("loc", host, ASK)
    fun setLocation(host: String, v: Int) = putInt("loc", host, v, ASK)

    /** ASK, ALLOW or BLOCK for the camera. (Older versions kept one choice for both; it still counts.) */
    fun camera(host: String): Int = getInt("cam", host, getInt("media", host, ASK))
    fun setCamera(host: String, v: Int) = putInt("cam", host, v, ASK)

    /** ASK, ALLOW or BLOCK for the microphone. */
    fun mic(host: String): Int = getInt("mic", host, getInt("media", host, ASK))
    fun setMic(host: String, v: Int) = putInt("mic", host, v, ASK)

    /** True when this site has any choice that differs from the default. */
    fun customised(host: String): Boolean =
        !ads(host) || !js(host) || location(host) != ASK || camera(host) != ASK || mic(host) != ASK

    fun reset(host: String) {
        if (host.isEmpty()) return
        val e = sp?.edit() ?: return
        for (k in listOf("ads", "js", "loc", "cam", "mic", "media")) e.remove(key(k, host))
        e.apply()
    }
}

/**
 * The line between the built-in blocker extension and the app: the extension asks which switches
 * a site has and tells us how many requests it cancelled.
 */
object SiteBridge : WebExtension.MessageDelegate {
    const val APP = "liquidair"

    /** The global ad-blocker switch from Settings. */
    @Volatile
    var adBlockOn: Boolean = true

    /** The ad blocker strength from Settings (0 Light .. 3 Aggressive). */
    @Volatile
    var adLevel: Int = 1

    /** The "Background play" switch from Settings. */
    @Volatile
    var bgPlay: Boolean = true

    /** Called (on a background thread) whenever the blocker reports new counts. */
    @Volatile
    var onCount: (() -> Unit)? = null

    /** Requests the extension cancelled, per page host, since that page started loading. */
    private val blocked = ConcurrentHashMap<String, Int>()

    fun blockedFor(host: String): Int = blocked[host.removePrefix("www.")] ?: 0

    fun reset(host: String) {
        blocked.remove(host.removePrefix("www."))
    }

    override fun onMessage(
        nativeApp: String,
        message: Any,
        sender: WebExtension.MessageSender
    ): GeckoResult<Any>? {
        val msg = message as? JSONObject ?: return null
        when (msg.optString("t")) {
            "policy" -> {
                val host = msg.optString("host")
                val reply = JSONObject()
                reply.put("ads", adBlockOn && Sites.ads(host))
                reply.put("js", Sites.js(host))
                // Fragile sites (video, sign-in, banking) only ever get the mildest blocking.
                reply.put("level", if (Urls.fragile(host)) 0 else adLevel)
                return GeckoResult.fromValue(reply as Any)
            }
            "bg" -> {
                return GeckoResult.fromValue(JSONObject().put("on", bgPlay) as Any)
            }
            "blocked" -> {
                val counts = msg.optJSONObject("counts")
                if (counts != null) {
                    val names = counts.keys()
                    while (names.hasNext()) {
                        val raw: String = names.next()
                        val h = raw.removePrefix("www.")
                        blocked[h] = (blocked[h] ?: 0) + counts.optInt(raw, 0)
                        Stats.add(counts.optInt(raw, 0))
                    }
                }
                onCount?.invoke()
                return GeckoResult.fromValue(JSONObject().put("ok", true) as Any)
            }
        }
        return null
    }
}
