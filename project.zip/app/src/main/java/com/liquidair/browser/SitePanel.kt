package com.liquidair.browser

import android.content.res.ColorStateList
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.ColorFilter
import android.graphics.ColorMatrix
import android.graphics.ColorMatrixColorFilter
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PixelFormat
import android.graphics.PixelCopy
import android.graphics.Rect
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.PopupWindow
import android.widget.ScrollView
import android.widget.Switch
import android.widget.TextView

/**
 * The wrench next to the address bar. It opens a Shields-style panel under the icon: whether the
 * connection is secure, how many ads and trackers were stopped on this page, and the controls for
 * this site (shields, scripts, cookies, location, camera). The card is frosted glass.
 */
class SitePanel(private val act: MainActivity) {

    private var popup: PopupWindow? = null
    private var advanced = false

    fun toggle(tab: Tab, anchor: View) {
        if (popup != null) {
            close()
            return
        }
        if (tab.home || !Urls.isWeb(tab.url)) {
            act.toast("Open a website to see its status")
            return
        }
        show(tab, anchor)
    }

    fun close() {
        popup?.dismiss()
        popup = null
    }

    private fun dp(v: Int) = act.dp(v)

    private fun show(tab: Tab, anchor: View) {
        val host = Urls.hostOf(tab.url)
        val column = LinearLayout(act)
        column.orientation = LinearLayout.VERTICAL

        val scroller = ScrollView(act)
        scroller.isVerticalScrollBarEnabled = false
        scroller.background = GradientDrawable().apply {
            cornerRadius = act.dpf(24f)
            // Frosted glass: a milky translucent fill with a bright hairline edge.
            setColor(if (C.dark) 0xCC1A1F1D.toInt() else 0xBFFFFFFF.toInt())
            setStroke(dp(1), if (C.dark) 0x40FFFFFF else 0xE6FFFFFF.toInt())
        }
        scroller.clipToOutline = true
        scroller.addView(column, ViewGroup.LayoutParams(-1, -2))

        val metrics = act.resources.displayMetrics
        val panelW = minOf(dp(380), metrics.widthPixels - dp(16))
        val maxH = metrics.heightPixels - dp(150)

        val pop = PopupWindow(scroller, panelW, ViewGroup.LayoutParams.WRAP_CONTENT, true)
        pop.elevation = act.dpf(14f)
        pop.setBackgroundDrawable(null)
        pop.isOutsideTouchable = true
        pop.setOnDismissListener { popup = null }

        fun render() {
            column.removeAllViews()
            fill(column, tab, host) { render() }
            column.measure(
                View.MeasureSpec.makeMeasureSpec(panelW, View.MeasureSpec.EXACTLY),
                View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED)
            )
            if (pop.isShowing) pop.update(panelW, minOf(column.measuredHeight, maxH))
        }
        column.removeAllViews()
        fill(column, tab, host) { render() }
        column.measure(
            View.MeasureSpec.makeMeasureSpec(panelW, View.MeasureSpec.EXACTLY),
            View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED)
        )
        pop.height = minOf(column.measuredHeight, maxH)

        popup = pop
        pop.showAsDropDown(anchor, -dp(6), dp(14))
        scroller.pivotX = 0f
        scroller.pivotY = 0f
        scroller.arrive(0f, -5f, .98f, 160)
        scroller.post { frost(scroller, panelW, maxH) }
    }

    /**
     * Liquid glass: copies what is on screen behind the card, blurs it, and paints it as the card's
     * background under a light tint. Until the copy is ready (or if the phone can't make one) the
     * card keeps its plain translucent fill.
     */
    private fun frost(card: View, panelW: Int, maxH: Int) {
        if (popup == null) return
        try {
            val at = IntArray(2)
            val origin = IntArray(2)
            card.getLocationOnScreen(at)
            act.window.decorView.getLocationOnScreen(origin)
            val winW = act.window.decorView.width
            val winH = act.window.decorView.height
            val left = (at[0] - origin[0]).coerceAtLeast(0)
            val top = (at[1] - origin[1]).coerceAtLeast(0)
            val r = Rect(left, top, minOf(left + panelW, winW), minOf(top + maxH, winH))
            if (r.width() < 16 || r.height() < 16) return
            val bmp = Bitmap.createBitmap(maxOf(1, r.width() / 4), maxOf(1, r.height() / 4), Bitmap.Config.ARGB_8888)
            PixelCopy.request(act.window, r, bmp, PixelCopy.OnPixelCopyFinishedListener { result ->
                if (result == PixelCopy.SUCCESS && popup != null) {
                    Backdrop.blur(bmp, 5, 3)
                    card.background = FrostDrawable(
                        bmp, r.height(), act.dpf(24f),
                        if (C.dark) 0x80101412.toInt() else 0x8CFFFFFF.toInt(),
                        if (C.dark) 0x40FFFFFF else 0xE6FFFFFF.toInt(),
                        act.dpf(1f)
                    )
                }
            }, Handler(Looper.getMainLooper()))
        } catch (e: Exception) {
            // Keep the translucent fill.
        }
    }

    // ---- contents -------------------------------------------------------

    private var open: String? = null

    private fun fill(col: LinearLayout, tab: Tab, host: String, redraw: () -> Unit) {
        val prefs = act.prefs
        val secure = tab.url.startsWith("https://", true)
        val shieldsUp = prefs.adBlock && Sites.ads(host)
        col.pad(4, 4, 4, 6)

        // ---- header: the site and a close button ----
        val header = LinearLayout(act)
        header.gravity = Gravity.CENTER_VERTICAL
        header.pad(16, 6, 4, 6)
        header.addView(
            oneLine(text(act, host.removePrefix("www.").ifEmpty { tab.url }, 18f, C.INK, true)),
            LinearLayout.LayoutParams(0, -2, 1f)
        )
        val x = iconButton(act, R.drawable.ic_close, 44, 44, 20, "Close")
        x.setOnClickListener { close() }
        header.addView(x, LinearLayout.LayoutParams(dp(44), dp(44)))
        col.addView(header)

        // ---- connection ----
        col.addView(divider())
        col.addView(
            row(
                R.drawable.ic_lock,
                if (secure) "Connection is secure" else "Connection is not secure",
                if (secure) null else "Others on the network may see what you send",
                "conn", null, redraw
            )
        )
        if (open == "conn") {
            col.addView(detail(switchRow("Upgrade connections to HTTPS", "All sites", prefs.httpsOnly) { on ->
                prefs.httpsOnly = on
                Engine.apply(prefs)
            }))
        }

        // ---- ads and trackers (the Shields switch) ----
        col.addView(divider())
        val total = tab.blocked + SiteBridge.blockedFor(host)
        col.addView(
            row(
                R.drawable.ic_shield,
                "Ads and trackers blocked",
                if (shieldsUp) "$total blocked on this page" else "Shields are down for this site",
                null,
                switchView(shieldsUp) { on ->
                    if (on && !prefs.adBlock) {
                        prefs.adBlock = true
                        Engine.apply(prefs)
                    }
                    Sites.setAds(host, on)
                    tab.session.settings.useTrackingProtection = prefs.adBlock && on
                    reload(tab)
                    redraw()
                },
                redraw
            )
        )

        // ---- JavaScript ----
        col.addView(divider())
        col.addView(
            row(
                R.drawable.ic_code,
                "JavaScript",
                if (Sites.js(host)) "Allowed" else "Blocked on this site",
                null,
                switchView(Sites.js(host)) { on ->
                    Sites.setJs(host, on)
                    reload(tab)
                    redraw()
                },
                redraw
            )
        )

        // ---- cookies ----
        col.addView(divider())
        val cookieNames = arrayOf("Allow all cookies", "Block cross-site cookies", "Block third-party cookies", "Block all cookies")
        val mode = prefs.cookieMode.coerceIn(0, cookieNames.size - 1)
        col.addView(row(R.drawable.ic_cookie, "Cookies and site data", cookieNames[mode], "cookies", null, redraw))
        if (open == "cookies") {
            val list = LinearLayout(act)
            list.orientation = LinearLayout.VERTICAL
            for (i in cookieNames.indices) {
                list.addView(optionRow(cookieNames[i], i == mode) {
                    prefs.cookieMode = i
                    Engine.apply(prefs)
                    redraw()
                })
            }
            list.addView(switchRow("Block fingerprinting", "All sites", prefs.fingerprint) { on ->
                prefs.fingerprint = on
                Engine.apply(prefs)
            })
            col.addView(detail(list))
        }

        // ---- permissions ----
        col.addView(divider())
        val perm = arrayOf("Ask", "Allow", "Block")
        val loc = Sites.location(host)
        val cam = Sites.media(host)
        val summary = if (loc == Sites.ASK && cam == Sites.ASK) "Ask before using location, camera or microphone"
        else "Location: ${perm[loc.coerceIn(0, 2)]}  ·  Camera: ${perm[cam.coerceIn(0, 2)]}"
        col.addView(row(R.drawable.ic_tune, "Permissions", summary, "perms", null, redraw))
        if (open == "perms") {
            val list = LinearLayout(act)
            list.orientation = LinearLayout.VERTICAL
            list.addView(choiceRow("Location", null, perm, loc) { Sites.setLocation(host, it); redraw() })
            list.addView(choiceRow("Camera and microphone", null, perm, cam) { Sites.setMedia(host, it); redraw() })
            col.addView(detail(list))
        }

        // ---- footer ----
        col.addView(divider())
        val foot = LinearLayout(act)
        foot.gravity = Gravity.CENTER_VERTICAL
        foot.pad(16, 4, 12, 2)
        if (Sites.customised(host)) {
            val reset = text(act, "Reset for this site", 14.5f, C.SKY_C, true)
            reset.pad(0, 10, 16, 10)
            reset.setOnClickListener {
                Sites.reset(host)
                tab.session.settings.useTrackingProtection = prefs.adBlock
                reload(tab)
                redraw()
            }
            foot.addView(reset)
        }
        val more = text(act, "Privacy settings", 14.5f, C.SKY_C, true)
        more.pad(0, 10, 0, 10)
        more.setOnClickListener {
            close()
            act.openSettings("privacy")
        }
        foot.addView(more)
        col.addView(foot)
    }

    private fun divider(): View {
        val v = View(act)
        v.setBackgroundColor(if (C.dark) 0x26FFFFFF else 0x1F000000)
        v.layoutParams = LinearLayout.LayoutParams(-1, maxOf(1, dp(1) / 2)).apply { leftMargin = dp(54) }
        return v
    }

    /** One line of the list: icon, title and a short status, with an optional control or chevron. */
    private fun row(res: Int, title: String, sub: String?, key: String?, trailing: View?, redraw: () -> Unit): LinearLayout {
        val r = LinearLayout(act)
        r.gravity = Gravity.CENTER_VERTICAL
        r.minimumHeight = dp(62)
        r.pad(16, 8, 14, 8)
        r.background = withRipple(null)
        r.addView(icon(act, res, 22), LinearLayout.LayoutParams(dp(22), dp(22)).apply { rightMargin = dp(18) })
        r.addView(labels(title, sub), LinearLayout.LayoutParams(0, -2, 1f))
        val end: View? = trailing ?: if (key != null) text(act, if (open == key) "⌃" else "⌄", 18f, C.MUTED) else null
        if (end != null) r.addView(end)
        if (key != null) {
            r.setOnClickListener {
                open = if (open == key) null else key
                redraw()
            }
        }
        return r
    }

    /** The controls that unfold under a row, lined up with its text. */
    private fun detail(inner: View): LinearLayout {
        val d = LinearLayout(act)
        d.orientation = LinearLayout.VERTICAL
        d.pad(56, 0, 14, 8)
        d.addView(inner, LinearLayout.LayoutParams(-1, -2))
        return d
    }

    private fun optionRow(label: String, on: Boolean, pick: () -> Unit): LinearLayout {
        val r = LinearLayout(act)
        r.gravity = Gravity.CENTER_VERTICAL
        r.minimumHeight = dp(44)
        r.background = withRipple(null)
        r.addView(text(act, label, 15f, C.INK, on), LinearLayout.LayoutParams(0, -2, 1f))
        if (on) r.addView(icon(act, R.drawable.ic_check, 18), LinearLayout.LayoutParams(dp(18), dp(18)))
        r.setOnClickListener { pick() }
        return r
    }

    /** Ads and script switches apply to the next load, so the page reloads. */
    private fun reload(tab: Tab) {
        try {
            if (!tab.home && tab.session.isOpen) tab.session.reload()
        } catch (e: Exception) {
            // The page picks the change up the next time it opens.
        }
    }

    // ---- small pieces ---------------------------------------------------

    private fun sectionLabel(s: String): TextView {
        val t = text(act, s, 13f, C.MUTED, true)
        t.pad(2, 14, 0, 4)
        return t
    }

    private fun tile(big: String, small: String): LinearLayout {
        val t = LinearLayout(act)
        t.orientation = LinearLayout.VERTICAL
        t.background = solid(act, if (C.dark) 0x26FFFFFF else 0x80FFFFFF.toInt(), 16f)
        t.pad(14, 11, 14, 11)
        t.addView(oneLine(text(act, big, 24f, C.INK, true)))
        t.addView(oneLine(text(act, small, 12.5f, C.MUTED)))
        return t
    }

    private fun switchView(on: Boolean, change: (Boolean) -> Unit): Switch {
        val sw = Switch(act)
        sw.isChecked = on
        val states = arrayOf(intArrayOf(android.R.attr.state_checked), intArrayOf())
        sw.trackTintList = ColorStateList(states, intArrayOf(C.SKY_C, 0x66808080))
        sw.thumbTintList = ColorStateList(states, intArrayOf(Color.WHITE, 0xFFF2F2F2.toInt()))
        sw.setOnCheckedChangeListener { _, checked -> change(checked) }
        return sw
    }

    private fun labels(title: String, sub: String?): LinearLayout {
        val l = LinearLayout(act)
        l.orientation = LinearLayout.VERTICAL
        l.addView(text(act, title, 15.5f, C.INK))
        if (sub != null) l.addView(text(act, sub, 12.5f, C.MUTED))
        return l
    }

    private fun switchRow(title: String, sub: String?, on: Boolean, change: (Boolean) -> Unit): LinearLayout {
        val row = LinearLayout(act)
        row.gravity = Gravity.CENTER_VERTICAL
        row.minimumHeight = dp(50)
        row.addView(labels(title, sub), LinearLayout.LayoutParams(0, -2, 1f))
        row.addView(switchView(on, change))
        return row
    }

    /** A row whose value cycles through [options] when tapped. */
    private fun choiceRow(
        title: String,
        sub: String?,
        options: Array<String>,
        start: Int,
        change: (Int) -> Unit
    ): LinearLayout {
        var value = start.coerceIn(0, options.size - 1)
        val row = LinearLayout(act)
        row.gravity = Gravity.CENTER_VERTICAL
        row.minimumHeight = dp(50)
        row.background = withRipple(null)
        row.addView(labels(title, sub), LinearLayout.LayoutParams(0, -2, 1f))
        val chip = text(act, options[value], 14f, C.INK, true)
        chip.gravity = Gravity.CENTER
        chip.background = solid(act, if (C.dark) 0x26FFFFFF else 0x80FFFFFF.toInt(), 16f)
        chip.pad(14, 0, 14, 0)
        row.addView(chip, LinearLayout.LayoutParams(-2, dp(34)))
        row.setOnClickListener {
            value = (value + 1) % options.size
            chip.text = options[value]
            change(value)
        }
        return row
    }
}

/** The blurred picture of what is behind the card, a light tint, a soft top glow and a bright edge. */
private class FrostDrawable(
    private val bm: Bitmap,
    private val regionH: Int,
    private val radius: Float,
    private val tint: Int,
    private val edge: Int,
    private val edgeW: Float
) : Drawable() {
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
    private val pic = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG).apply {
        colorFilter = ColorMatrixColorFilter(ColorMatrix().apply { setSaturation(1.4f) })
    }

    override fun draw(canvas: Canvas) {
        val b = bounds
        if (b.isEmpty) return
        val rect = RectF(b)
        val path = Path()
        path.addRoundRect(rect, radius, radius, Path.Direction.CW)
        canvas.save()
        canvas.clipPath(path)
        val srcH = (bm.height * (b.height().toFloat() / regionH)).toInt().coerceIn(1, bm.height)
        canvas.drawBitmap(bm, Rect(0, 0, bm.width, srcH), rect, pic)
        paint.style = Paint.Style.FILL
        paint.shader = null
        paint.color = tint
        canvas.drawRect(rect, paint)
        paint.shader = LinearGradient(0f, rect.top, 0f, rect.top + rect.height() * 0.5f, 0x40FFFFFF, 0x00FFFFFF, Shader.TileMode.CLAMP)
        canvas.drawRect(rect, paint)
        paint.shader = null
        canvas.restore()
        paint.style = Paint.Style.STROKE
        paint.strokeWidth = edgeW
        paint.color = edge
        val half = edgeW / 2
        canvas.drawRoundRect(RectF(rect.left + half, rect.top + half, rect.right - half, rect.bottom - half), radius, radius, paint)
    }

    override fun setAlpha(alpha: Int) {}
    override fun setColorFilter(colorFilter: ColorFilter?) {}
    @Suppress("OVERRIDE_DEPRECATION")
    override fun getOpacity(): Int = PixelFormat.TRANSLUCENT
}
