package com.liquidair.browser

import android.content.res.ColorStateList
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.ColorFilter
import android.graphics.ColorMatrix
import android.graphics.ColorMatrixColorFilter
import android.graphics.LinearGradient
import android.graphics.Outline
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PixelFormat
import android.graphics.Rect
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.animation.OvershootInterpolator
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.PopupWindow
import android.widget.ScrollView
import android.widget.Switch
import android.widget.TextView

/**
 * The gear next to the address bar. It opens a panel right under the icon: whether the connection
 * is secure, how many ads and trackers were stopped on this page, and the controls for this site
 * (shields, scripts, cookies, location, camera, microphone). It is a plain Chrome-style card.
 */
class SitePanel(private val act: MainActivity) {

    private var popup: PopupWindow? = null
    private var anchorBtn: View? = null
    private var open: String? = null

    private val subColor get() = C.MUTED
    private val linkColor get() = C.LINK

    fun toggle(tab: Tab, anchor: View) {
        if (popup != null) {
            close()
            return
        }
        if (tab.home || !Urls.isWeb(tab.url)) {
            act.toast("Open a website to see its status")
            return
        }
        show(tab, anchor)
    }

    fun close() {
        popup?.dismiss()
        popup = null
        twist(false)
    }

    private fun dp(v: Int) = act.dp(v)

    /** The gear turns a little while the panel is open. */
    private fun twist(on: Boolean) {
        val img = (anchorBtn as? FrameLayout)?.getChildAt(0) ?: return
        img.animate().rotation(if (on) 60f else 0f).setDuration(280)
            .setInterpolator(OvershootInterpolator(2.2f)).start()
    }

    private fun show(tab: Tab, anchor: View) {
        val host = Urls.hostOf(tab.url)
        open = null
        anchorBtn = anchor
        val column = LinearLayout(act)
        column.orientation = LinearLayout.VERTICAL

        val metrics = act.resources.displayMetrics
        val panelW = minOf(dp(364), metrics.widthPixels - dp(16))
        val maxH = metrics.heightPixels - dp(150)

        val scroller = ScrollView(act)
        scroller.isVerticalScrollBarEnabled = false
        scroller.background = GradientDrawable().apply {
            cornerRadius = act.dpf(14f)
            setColor(C.WHITE)
            setStroke(act.dp(1), C.LINE)
        }
        scroller.clipToOutline = true
        scroller.elevation = act.dpf(8f)
        scroller.addView(column, ViewGroup.LayoutParams(-1, -2))

        // A little transparent margin lets the card's shadow show.
        val m = dp(10)
        val frame = FrameLayout(act)
        frame.clipChildren = false
        frame.clipToPadding = false
        frame.setPadding(m, m, m, m)
        frame.addView(scroller, FrameLayout.LayoutParams(-1, -1))

        val pop = PopupWindow(frame, panelW + 2 * m, ViewGroup.LayoutParams.WRAP_CONTENT, true)
        pop.setBackgroundDrawable(null)
        pop.isOutsideTouchable = true
        pop.setOnDismissListener {
            popup = null
            twist(false)
        }

        fun render() {
            column.removeAllViews()
            fill(column, tab, host) { render() }
            column.measure(
                View.MeasureSpec.makeMeasureSpec(panelW, View.MeasureSpec.EXACTLY),
                View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED)
            )
            if (pop.isShowing) pop.update(panelW + 2 * m, minOf(column.measuredHeight, maxH) + 2 * m)
        }
        fill(column, tab, host) { render() }
        column.measure(
            View.MeasureSpec.makeMeasureSpec(panelW, View.MeasureSpec.EXACTLY),
            View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED)
        )
        pop.height = minOf(column.measuredHeight, maxH) + 2 * m

        popup = pop
        pop.showAsDropDown(anchor, -dp(6) - m, dp(8) - m)
        twist(true)
        scroller.pivotX = 0f
        scroller.pivotY = 0f
        scroller.arrive(0f, -5f, .98f, 160)
    }

    // ---- contents -------------------------------------------------------

    private fun fill(col: LinearLayout, tab: Tab, host: String, redraw: () -> Unit) {
        val prefs = act.prefs
        val secure = tab.url.startsWith("https://", true)
        val shieldsUp = prefs.adBlock && Sites.ads(host)
        col.pad(4, 4, 4, 6)

        // ---- header: the site and a close button ----
        val header = LinearLayout(act)
        header.gravity = Gravity.CENTER_VERTICAL
        header.pad(16, 6, 4, 6)
        header.addView(
            oneLine(text(act, host.removePrefix("www.").ifEmpty { tab.url }, 18f, C.INK, true)),
            LinearLayout.LayoutParams(0, -2, 1f)
        )
        val x = iconButton(act, R.drawable.ic_close, 44, 44, 20, "Close")
        x.setOnClickListener { close() }
        header.addView(x, LinearLayout.LayoutParams(dp(44), dp(44)))
        col.addView(header)

        // ---- connection ----
        col.addView(divider())
        col.addView(
            row(
                R.drawable.ic_lock,
                if (secure) "Connection is secure" else "Connection is not secure",
                if (secure) null else "Others on the network may see what you send",
                "conn", null, redraw
            )
        )
        if (open == "conn") {
            col.addView(detail(switchRow("Upgrade connections to HTTPS", "All sites", prefs.httpsOnly) { on ->
                prefs.httpsOnly = on
                Engine.apply(prefs)
            }))
        }

        // ---- ads and trackers (the Shields switch) ----
        col.addView(divider())
        val total = tab.blocked + SiteBridge.blockedFor(host)
        col.addView(
            row(
                R.drawable.ic_shield,
                "Ads and trackers blocked",
                if (shieldsUp) "$total blocked on this page" else "Shields are down for this site",
                null,
                switchView(shieldsUp) { on ->
                    if (on && !prefs.adBlock) {
                        prefs.adBlock = true
                        Engine.apply(prefs)
                    }
                    Sites.setAds(host, on)
                    tab.session.settings.useTrackingProtection = prefs.adBlock && on
                    reload(tab)
                    redraw()
                },
                redraw
            )
        )

        // ---- JavaScript ----
        col.addView(divider())
        col.addView(
            row(
                R.drawable.ic_code,
                "JavaScript",
                if (Sites.js(host)) "Allowed" else "Blocked on this site",
                null,
                switchView(Sites.js(host)) { on ->
                    Sites.setJs(host, on)
                    reload(tab)
                    redraw()
                },
                redraw
            )
        )

        // ---- cookies ----
        col.addView(divider())
        val cookieNames = arrayOf("Allow all cookies", "Block cross-site cookies", "Block third-party cookies", "Block all cookies")
        val mode = prefs.cookieMode.coerceIn(0, cookieNames.size - 1)
        col.addView(row(R.drawable.ic_cookie, "Cookies and site data", cookieNames[mode], "cookies", null, redraw))
        if (open == "cookies") {
            val list = LinearLayout(act)
            list.orientation = LinearLayout.VERTICAL
            for (i in cookieNames.indices) {
                list.addView(optionRow(cookieNames[i], i == mode) {
                    prefs.cookieMode = i
                    Engine.apply(prefs)
                    redraw()
                })
            }
            list.addView(switchRow("Block fingerprinting", "All sites", prefs.fingerprint) { on ->
                prefs.fingerprint = on
                Engine.apply(prefs)
            })
            col.addView(detail(list))
        }

        // ---- permissions: location, camera and microphone each on their own ----
        col.addView(divider())
        val words = arrayOf("Ask", "Allow", "Block")
        val loc = Sites.location(host).coerceIn(0, 2)
        val cam = Sites.camera(host).coerceIn(0, 2)
        val mic = Sites.mic(host).coerceIn(0, 2)
        val parts = ArrayList<String>()
        if (loc != Sites.ASK) parts.add("Location " + words[loc].lowercase())
        if (cam != Sites.ASK) parts.add("Camera " + words[cam].lowercase())
        if (mic != Sites.ASK) parts.add("Microphone " + words[mic].lowercase())
        val summary = if (parts.isEmpty()) "Ask before using location, camera or microphone" else parts.joinToString("  ·  ")
        col.addView(row(R.drawable.ic_tune, "Permissions", summary, "perms", null, redraw))
        if (open == "perms") {
            val list = LinearLayout(act)
            list.orientation = LinearLayout.VERTICAL
            list.addView(segRow("Location", null, words, loc) { Sites.setLocation(host, it); redraw() })
            list.addView(segRow("Camera", null, words, cam) { Sites.setCamera(host, it); redraw() })
            list.addView(segRow("Microphone", null, words, mic) { Sites.setMic(host, it); redraw() })
            col.addView(detail(list))
        }

        // ---- footer ----
        col.addView(divider())
        val foot = LinearLayout(act)
        foot.gravity = Gravity.CENTER_VERTICAL
        foot.pad(16, 4, 12, 2)
        if (Sites.customised(host)) {
            val reset = text(act, "Reset for this site", 14.5f, linkColor, true)
            reset.pad(0, 10, 16, 10)
            reset.setOnClickListener {
                Sites.reset(host)
                tab.session.settings.useTrackingProtection = prefs.adBlock
                reload(tab)
                redraw()
            }
            foot.addView(reset)
        }
        val more = text(act, "Privacy settings", 14.5f, linkColor, true)
        more.pad(0, 10, 0, 10)
        more.setOnClickListener {
            close()
            act.openSettings("privacy")
        }
        foot.addView(more)
        col.addView(foot)
    }

    private fun divider(): View {
        val v = View(act)
        v.setBackgroundColor(if (C.dark) 0x33FFFFFF else 0x26000000)
        v.layoutParams = LinearLayout.LayoutParams(-1, maxOf(1, dp(1) / 2)).apply { leftMargin = dp(54) }
        return v
    }

    /** One line of the list: icon, title and a short status, with an optional control or chevron. */
    private fun row(res: Int, title: String, sub: String?, key: String?, trailing: View?, redraw: () -> Unit): LinearLayout {
        val r = LinearLayout(act)
        r.gravity = Gravity.CENTER_VERTICAL
        r.minimumHeight = dp(62)
        r.pad(16, 8, 14, 8)
        r.background = withRipple(null)
        r.addView(icon(act, res, 22), LinearLayout.LayoutParams(dp(22), dp(22)).apply { rightMargin = dp(18) })
        r.addView(labels(title, sub), LinearLayout.LayoutParams(0, -2, 1f))
        val end: View? = trailing ?: if (key != null) text(act, if (open == key) "⌃" else "⌄", 18f, subColor) else null
        if (end != null) r.addView(end)
        if (key != null) {
            r.setOnClickListener {
                open = if (open == key) null else key
                redraw()
            }
        }
        return r
    }

    /** The controls that unfold under a row, lined up with its text. */
    private fun detail(inner: View): LinearLayout {
        val d = LinearLayout(act)
        d.orientation = LinearLayout.VERTICAL
        d.pad(56, 0, 14, 8)
        d.addView(inner, LinearLayout.LayoutParams(-1, -2))
        return d
    }

    private fun optionRow(label: String, on: Boolean, pick: () -> Unit): LinearLayout {
        val r = LinearLayout(act)
        r.gravity = Gravity.CENTER_VERTICAL
        r.minimumHeight = dp(44)
        r.background = withRipple(null)
        r.addView(text(act, label, 15f, C.INK, on), LinearLayout.LayoutParams(0, -2, 1f))
        if (on) r.addView(icon(act, R.drawable.ic_check, 18), LinearLayout.LayoutParams(dp(18), dp(18)))
        r.setOnClickListener { pick() }
        return r
    }

    /** Ads and script switches apply to the next load, so the page reloads. */
    private fun reload(tab: Tab) {
        try {
            if (!tab.home && tab.session.isOpen) tab.session.reload()
        } catch (e: Exception) {
            // The page picks the change up the next time it opens.
        }
    }

    // ---- small pieces ---------------------------------------------------

    private fun switchView(on: Boolean, change: (Boolean) -> Unit): Switch {
        val sw = Switch(act)
        sw.isChecked = on
        val states = arrayOf(intArrayOf(android.R.attr.state_checked), intArrayOf())
        sw.trackTintList = ColorStateList(states, intArrayOf(C.SKY_C, 0x66808080))
        sw.thumbTintList = ColorStateList(states, intArrayOf(Color.WHITE, 0xFFF2F2F2.toInt()))
        sw.setOnCheckedChangeListener { _, checked -> change(checked) }
        return sw
    }

    private fun labels(title: String, sub: String?): LinearLayout {
        val l = LinearLayout(act)
        l.orientation = LinearLayout.VERTICAL
        l.addView(text(act, title, 15.5f, C.INK))
        if (sub != null) l.addView(text(act, sub, 12.5f, subColor))
        return l
    }

    private fun switchRow(title: String, sub: String?, on: Boolean, change: (Boolean) -> Unit): LinearLayout {
        val row = LinearLayout(act)
        row.gravity = Gravity.CENTER_VERTICAL
        row.minimumHeight = dp(50)
        row.addView(labels(title, sub), LinearLayout.LayoutParams(0, -2, 1f))
        row.addView(switchView(on, change))
        return row
    }

    /** A name on the left and a three-way button (Ask / Allow / Block) on the right. */
    private fun segRow(title: String, sub: String?, options: Array<String>, start: Int, change: (Int) -> Unit): LinearLayout {
        var value = start.coerceIn(0, options.size - 1)
        val row = LinearLayout(act)
        row.gravity = Gravity.CENTER_VERTICAL
        row.minimumHeight = dp(54)
        row.addView(labels(title, sub), LinearLayout.LayoutParams(0, -2, 1f))
        val track = LinearLayout(act)
        track.background = solid(act, if (C.dark) 0x33FFFFFF else 0x1F000000, 16f)
        track.pad(3, 3, 3, 3)
        val chips = ArrayList<TextView>()
        fun paint() {
            for (i in chips.indices) {
                val sel = i == value
                chips[i].background = if (sel) solid(act, C.SKY_C, 13f) else null
                chips[i].setTextColor(if (sel) Color.WHITE else C.INK)
            }
        }
        for (i in options.indices) {
            val t = text(act, options[i], 13.5f, C.INK, true)
            t.gravity = Gravity.CENTER
            t.pad(11, 0, 11, 0)
            t.setOnClickListener {
                value = i
                paint()
                change(i)
            }
            chips.add(t)
            track.addView(t, LinearLayout.LayoutParams(-2, dp(30)))
        }
        paint()
        row.addView(track, LinearLayout.LayoutParams(-2, -2))
        return row
    }
}
