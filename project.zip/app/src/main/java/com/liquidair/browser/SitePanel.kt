package com.liquidair.browser

import android.app.Dialog
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.Window
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Switch
import android.widget.TextView

/**
 * The wrench next to the address bar: how this site is doing (connection, how many ads and
 * trackers were stopped) and what it is allowed to do (ads, JavaScript, location, camera).
 */
class SitePanel(private val act: MainActivity) {

    fun show(tab: Tab) {
        if (tab.home || !Urls.isWeb(tab.url)) {
            act.toast("Open a website to see its status")
            return
        }
        val host = Urls.hostOf(tab.url)
        val secure = tab.url.startsWith("https://", true)

        val dialog = Dialog(act)
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE)

        val col = LinearLayout(act)
        col.orientation = LinearLayout.VERTICAL
        col.background = solid(act, C.WHITE, 26f)
        col.pad(20, 18, 20, 18)

        // ---- header ----
        col.addView(text(act, host.ifEmpty { tab.url }, 20f, C.INK, true).also { oneLine(it) })
        val status = text(
            act,
            if (secure) "Connection is secure" else "Connection is not secure",
            14f,
            if (secure) 0xFF2E7D4F.toInt() else 0xFFC0392B.toInt()
        )
        col.addView(status, LinearLayout.LayoutParams(-2, -2).apply { topMargin = dp(2) })

        // ---- ad blocker report ----
        val total = tab.blocked + SiteBridge.blockedFor(host)
        val card = LinearLayout(act)
        card.orientation = LinearLayout.VERTICAL
        card.background = solid(act, C.SOFT, 18f)
        card.pad(16, 14, 16, 14)
        val adsOn = act.prefs.adBlock && Sites.ads(host)
        card.addView(text(act, if (adsOn) total.toString() else "Off", 34f, C.INK, true))
        card.addView(
            text(
                act,
                when {
                    !act.prefs.adBlock -> "The ad blocker is off in Settings"
                    !Sites.ads(host) -> "Ads are allowed on this site"
                    total == 1 -> "ad or tracker blocked on this page"
                    else -> "ads and trackers blocked on this page"
                },
                14f,
                C.MUTED
            )
        )
        col.addView(card, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(14); bottomMargin = dp(8) })

        // ---- switches ----
        col.addView(switchRow("Block ads and trackers", "On this site", Sites.ads(host)) { on ->
            Sites.setAds(host, on)
            tab.session.settings.useTrackingProtection = act.prefs.adBlock && on
            applied(tab)
        })
        col.addView(switchRow("JavaScript", "Turn off to stop scripts on this site", Sites.js(host)) { on ->
            Sites.setJs(host, on)
            applied(tab)
        })

        // ---- permissions ----
        col.addView(sectionLabel("Permissions"))
        col.addView(choiceRow("Location", Sites.location(host)) { Sites.setLocation(host, it) })
        col.addView(choiceRow("Camera and microphone", Sites.media(host)) { Sites.setMedia(host, it) })

        val reset = text(act, "Reset this site", 15f, C.SKY_C, true)
        reset.gravity = Gravity.CENTER
        reset.background = withRipple(null)
        reset.setOnClickListener {
            Sites.reset(host)
            tab.session.settings.useTrackingProtection = act.prefs.adBlock
            dialog.dismiss()
            act.toast("Site settings reset")
            applied(tab)
        }
        col.addView(reset, LinearLayout.LayoutParams(-1, dp(46)).apply { topMargin = dp(8) })

        val scroll = ScrollView(act)
        scroll.addView(col, ViewGroup.LayoutParams(-1, -2))
        dialog.setContentView(scroll)
        val w = dialog.window
        if (w != null) {
            w.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
            w.setGravity(Gravity.BOTTOM)
            w.setLayout(-1, -2)
        }
        dialog.show()
    }

    /** Switches and permissions apply to the next load, so the page reloads. */
    private fun applied(tab: Tab) {
        try {
            if (!tab.home && tab.session.isOpen) tab.session.reload()
        } catch (e: Exception) {
            // The page reloads next time it opens.
        }
    }

    private fun sectionLabel(s: String): TextView {
        val t = text(act, s, 13f, C.MUTED, true)
        t.pad(2, 14, 0, 4)
        return t
    }

    private fun switchRow(title: String, sub: String, on: Boolean, change: (Boolean) -> Unit): LinearLayout {
        val row = LinearLayout(act)
        row.gravity = Gravity.CENTER_VERTICAL
        val labels = LinearLayout(act)
        labels.orientation = LinearLayout.VERTICAL
        labels.addView(text(act, title, 16f, C.INK))
        labels.addView(text(act, sub, 13f, C.MUTED))
        row.addView(labels, LinearLayout.LayoutParams(0, -2, 1f))
        val sw = Switch(act)
        sw.isChecked = on
        sw.setOnCheckedChangeListener { _, checked -> change(checked) }
        row.addView(sw)
        row.pad(2, 8, 2, 8)
        return row
    }

    /** A row whose value cycles Ask, Allow, Block when tapped. */
    private fun choiceRow(title: String, start: Int, change: (Int) -> Unit): LinearLayout {
        val names = arrayOf("Ask", "Allow", "Block")
        var value = start
        val row = LinearLayout(act)
        row.gravity = Gravity.CENTER_VERTICAL
        row.background = withRipple(null)
        row.pad(2, 0, 2, 0)
        row.addView(text(act, title, 16f, C.INK), LinearLayout.LayoutParams(0, -2, 1f))
        val chip = text(act, names[value], 14f, C.INK, true)
        chip.gravity = Gravity.CENTER
        chip.background = solid(act, C.SOFT, 16f)
        chip.pad(16, 0, 16, 0)
        row.addView(chip, LinearLayout.LayoutParams(-2, dp(34)))
        row.setOnClickListener {
            value = (value + 1) % 3
            chip.text = names[value]
            change(value)
        }
        row.minimumHeight = dp(48)
        return row
    }

    private fun dp(v: Int) = act.dp(v)
}
