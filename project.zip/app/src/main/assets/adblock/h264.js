// Video compatibility for YouTube and YouTube Music: tell the page that VP9 and AV1 video are not
// supported, so it asks for H.264, which almost every phone and tablet decodes in hardware. Some
// devices show black, blurred or zoomed-in video when the page picks VP9/AV1. Nothing else about
// the page is changed.
(function () {
  "use strict";
  try {
    var w = window.wrappedJSObject;
    var bad = /vp0?9|av01|av1/i;
    if (w.MediaSource && w.MediaSource.isTypeSupported) {
      var orig = w.MediaSource.isTypeSupported;
      w.MediaSource.isTypeSupported = exportFunction(function (t) {
        if (bad.test(String(t))) return false;
        return orig.call(w.MediaSource, t);
      }, w);
    }
    var proto = w.HTMLMediaElement && w.HTMLMediaElement.prototype;
    if (proto && proto.canPlayType) {
      var can = proto.canPlayType;
      proto.canPlayType = exportFunction(function (t) {
        if (bad.test(String(t))) return "";
        return can.call(this, t);
      }, w);
    }
  } catch (e) {
    // The page keeps its own behaviour.
  }
})();
