// YouTube ads, the way Brave handles them:
//  1. The ad data is removed from YouTube's own answers before the player sees it, so most ads are
//     never scheduled at all.
//  2. Ad boxes, banners and promoted rows are hidden.
//  3. If an ad still starts, it is muted, hidden, run at top speed, jumped to its end, and Skip is
//     pressed when it shows. The video you opened keeps its own sound and speed.
// Turned off for a site with the Shields switch in the toolbar's site panel.
(function () {
  "use strict";
  var enabled = true;
  var saved = null;
  var style = null;

  var HIDE = [
    "#masthead-ad", "#player-ads", ".video-ads", ".ytp-ad-overlay-container", ".ytp-ad-overlay-slot",
    "ytd-ad-slot-renderer", "ytd-in-feed-ad-layout-renderer", "ytd-display-ad-renderer",
    "ytd-promoted-sparkles-web-renderer", "ytd-promoted-video-renderer", "ytd-banner-promo-renderer",
    "ytd-statement-banner-renderer", "ytd-companion-slot-renderer", "ytd-action-companion-ad-renderer",
    "ytd-player-legacy-desktop-watch-ads-renderer", "ytm-promoted-sparkles-web-renderer",
    "ytm-companion-ad-renderer", "ytm-promoted-video-renderer", "ytm-ad-slot-renderer"
  ].join(",") + "{display:none!important}" +
    // While an ad is still running it is invisible and silent, so nothing of it shows.
    ".html5-video-player.ad-showing .html5-main-video{visibility:hidden!important}" +
    ".html5-video-player.ad-showing .ytp-ad-module,.html5-video-player.ad-showing .ytp-ad-player-overlay," +
    ".html5-video-player.ad-showing .ytp-ad-player-overlay-layout{opacity:0!important}";

  function syncStyle() {
    if (enabled && !style) {
      style = document.createElement("style");
      style.textContent = HIDE;
      (document.head || document.documentElement).appendChild(style);
    } else if (!enabled && style) {
      style.remove();
      style = null;
    }
  }

  browser.runtime.sendMessage({ t: "yt" }).then(
    function (on) { enabled = on !== false; syncStyle(); },
    function () {}
  );
  syncStyle();

  // 1. Remove the ad schedule from the answers YouTube sends to its own page.
  try {
    var w = window.wrappedJSObject;
    var KEYS = ["adPlacements", "playerAds", "adSlots"];
    var prune = function (o) {
      try {
        if (!enabled || !o || typeof o !== "object") return;
        for (var i = 0; i < KEYS.length; i++) {
          if (KEYS[i] in o) delete o[KEYS[i]];
        }
        if (o.playerResponse && typeof o.playerResponse === "object") prune(o.playerResponse);
      } catch (e) {}
    };
    var origParse = w.JSON.parse;
    w.JSON.parse = exportFunction(function (text, reviver) {
      var res = origParse.call(w.JSON, text, reviver);
      prune(res);
      return res;
    }, w);
    var proto = w.Response.prototype;
    var origJson = proto.json;
    proto.json = exportFunction(function () {
      var p = origJson.call(this);
      return p.then(exportFunction(function (v) {
        prune(v);
        return v;
      }, w));
    }, w);
  } catch (e) {
    // The page keeps its own behaviour; the steps below still work.
  }

  // 3. If an ad does play: mute it, run it to its end, press Skip.
  var SKIP = [
    ".ytp-skip-ad-button", ".ytp-ad-skip-button", ".ytp-ad-skip-button-modern",
    ".ytp-ad-skip-button-container button", ".ytp-ad-skip-button-slot button"
  ].join(",");
  var CLOSE = ".ytp-ad-overlay-close-button, .ytp-ad-overlay-close-container";

  function tick() {
    if (!enabled) return;
    var p = document.querySelector(".html5-video-player");
    if (!p) return;
    var v = p.querySelector("video.html5-main-video") || p.querySelector("video");
    var ad = p.classList.contains("ad-showing") || p.classList.contains("ad-interrupting");
    if (ad && v) {
      if (!saved) saved = { muted: v.muted, rate: v.playbackRate };
      try { v.muted = true; } catch (e) {}
      try { v.playbackRate = 16; } catch (e) {}
      try {
        if (isFinite(v.duration) && v.duration > 0 && v.currentTime < v.duration - 0.25) {
          v.currentTime = v.duration - 0.1;
        }
      } catch (e) {}
      var skip = p.querySelector(SKIP);
      if (skip) skip.click();
    } else if (saved && v) {
      try { v.muted = saved.muted; } catch (e) {}
      try { v.playbackRate = saved.rate; } catch (e) {}
      saved = null;
    }
    var close = p.querySelector(CLOSE);
    if (close) close.click();
  }

  setInterval(tick, 200);
})();
