// YouTube ads: while an ad is playing, mute it, run it at top speed, jump to its end and press
// "Skip" when the button shows. The video you opened keeps its own sound and speed. Turned off for
// a site with the Shields switch in the toolbar's site panel.
(function () {
  "use strict";
  var enabled = true;
  var saved = null;

  browser.runtime.sendMessage({ t: "yt" }).then(
    function (on) { enabled = on !== false; },
    function () {}
  );

  var SKIP = [
    ".ytp-skip-ad-button",
    ".ytp-ad-skip-button",
    ".ytp-ad-skip-button-modern",
    ".ytp-ad-skip-button-container button",
    ".ytp-ad-skip-button-slot button"
  ].join(",");
  var CLOSE = ".ytp-ad-overlay-close-button, .ytp-ad-overlay-close-container";

  function tick() {
    if (!enabled) return;
    var p = document.querySelector(".html5-video-player");
    if (!p) return;
    var v = p.querySelector("video.html5-main-video") || p.querySelector("video");
    var ad = p.classList.contains("ad-showing") || p.classList.contains("ad-interrupting");
    if (ad && v) {
      if (!saved) saved = { muted: v.muted, rate: v.playbackRate };
      try { v.muted = true; } catch (e) {}
      try { v.playbackRate = 16; } catch (e) {}
      try {
        if (isFinite(v.duration) && v.duration > 0 && v.currentTime < v.duration - 0.25) {
          v.currentTime = v.duration - 0.1;
        }
      } catch (e) {}
      var skip = p.querySelector(SKIP);
      if (skip) skip.click();
    } else if (saved && v) {
      try { v.muted = saved.muted; } catch (e) {}
      try { v.playbackRate = saved.rate; } catch (e) {}
      saved = null;
    }
    var close = p.querySelector(CLOSE);
    if (close) close.click();
  }

  setInterval(tick, 200);
})();
