// Background play: media sites pause themselves when the page is hidden (screen off, app in the
// background). On the sites listed in manifest.json this tells the page it is still visible, as
// long as "Background play" is on in Settings. Nothing else about the page is changed.
(function () {
  "use strict";

  function keepAlive() {
    try {
      var w = window.wrappedJSObject;
      var d = w.document;
      var define = function (name, value) {
        Object.defineProperty(d, name, {
          configurable: true,
          get: exportFunction(function () { return value; }, w)
        });
      };
      define("hidden", false);
      define("webkitHidden", false);
      define("visibilityState", "visible");
      define("webkitVisibilityState", "visible");
      d.hasFocus = exportFunction(function () { return true; }, w);
      var swallow = exportFunction(function (e) { e.stopImmediatePropagation(); }, w);
      d.addEventListener("visibilitychange", swallow, true);
      w.addEventListener("visibilitychange", swallow, true);
    } catch (e) {
      // The page keeps its own behaviour.
    }
  }

  browser.runtime.sendMessage({ t: "bg" }).then(
    function (on) { if (on !== false) keepAlive(); },
    function () { keepAlive(); }
  );
})();
