// Cosmetic filtering, the way Brave does it: after the network blocker has cancelled an ad's
// requests, this hides the empty slot that would be left behind so the page doesn't show that an
// ad was ever there. It only touches well-known ad containers and elements whose third-party
// request was refused. Off for a site when Shields are down.
(function () {
  "use strict";
  if (/captcha|challenge/i.test(location.hostname)) return;

  var SELECTORS = [
    "ins.adsbygoogle", ".adsbygoogle", "[id^='google_ads_iframe']", "[id^='google_ads_']",
    "[id^='div-gpt-ad']", "[id^='gpt-ad-']", "[data-google-query-id]", "[data-ad-slot]",
    "iframe[src*='doubleclick.net']", "iframe[src*='googlesyndication.com']",
    "iframe[src*='/pagead/']", "iframe[src*='amazon-adsystem.com']", "iframe[src*='adnxs.com']",
    "iframe[src*='taboola.com']", "iframe[src*='outbrain.com']",
    ".taboola", "[id^='taboola-']", ".trc_rbox_container", ".OUTBRAIN", "[id^='outbrain-']",
    ".ad-banner", ".adbanner", ".ad-slot", ".ad-unit", ".ad-wrapper", ".adwrapper",
    ".ad-container", ".advertisement", ".advert", ".banner-ad", ".sponsored-ad",
    "#ad-banner", "#ad-container", "#advertisement",
    "[aria-label='Advertisement' i]", "[aria-label='Advertisements' i]",
    "#tads", "#tadsb", "#bottomads", "[data-text-ad]"
  ];
  var CSS = SELECTORS.join(",") + "{display:none!important}";
  var SEL = SELECTORS.join(",");
  var style = null;

  function site(h) {
    var p = h.split(".");
    return p.slice(-2).join(".");
  }
  var mine = site(location.hostname);

  // True when everything inside `p` is already hidden and it holds no visible text.
  function allGone(p) {
    try {
      if (p.innerText && p.innerText.trim().length) return false;
      for (var c = p.firstElementChild; c; c = c.nextElementSibling) {
        var t = c.tagName;
        if (t === "SCRIPT" || t === "STYLE" || t === "NOSCRIPT") continue;
        if (getComputedStyle(c).display !== "none") return false;
      }
      return true;
    } catch (e) {
      return false;
    }
  }

  // Hides `el`, then any wrapper around it that has nothing else left in it.
  function collapse(el) {
    try {
      el.style.setProperty("display", "none", "important");
      var p = el.parentElement;
      for (var i = 0; i < 3 && p && p !== document.body && p !== document.documentElement; i++) {
        if (!allGone(p)) break;
        p.style.setProperty("display", "none", "important");
        p = p.parentElement;
      }
    } catch (e) {}
  }

  function sweep() {
    try {
      var found = document.querySelectorAll(SEL);
      for (var i = 0; i < found.length; i++) {
        var p = found[i].parentElement;
        for (var j = 0; j < 3 && p && p !== document.body && p !== document.documentElement; j++) {
          if (!allGone(p)) break;
          p.style.setProperty("display", "none", "important");
          p = p.parentElement;
        }
      }
    } catch (e) {}
  }

  function start() {
    if (style) return;
    style = document.createElement("style");
    style.textContent = CSS;
    (document.head || document.documentElement).appendChild(style);

    // A picture or frame from another site that failed to load was an ad request we cancelled.
    document.addEventListener("error", function (e) {
      var el = e.target;
      if (!el || (el.tagName !== "IMG" && el.tagName !== "IFRAME")) return;
      try {
        var u = new URL(el.currentSrc || el.src);
        if (u.protocol.indexOf("http") !== 0 || site(u.hostname) === mine) return;
        collapse(el);
      } catch (x) {}
    }, true);

    document.addEventListener("DOMContentLoaded", sweep);
    window.addEventListener("load", function () {
      setTimeout(sweep, 800);
      setTimeout(sweep, 3000);
    });
  }

  browser.runtime.sendMessage({ t: "cos" }).then(
    function (on) { if (on !== false) start(); },
    function () {}
  );
})();
