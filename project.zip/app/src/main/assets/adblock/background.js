"use strict";

// Liquid Air network blocker.
//
// It cancels *requests* (scripts, frames, pixels, beacons, XHR/fetch, WebSockets) to known
// ad and tracker hosts. A few well-known ad scripts are not cancelled but swapped for a harmless
// stand-in (res/*.js), so page code that waits for them keeps working instead of breaking.
// cosmetic.js then hides the empty ad slots that leaves behind.
//
// Aggression levels (chosen in Settings, sent by the app with every page):
//   0 Light       hosts that only ever serve ads/trackers
//   1 Standard    + third-party-only hosts                          (default)
//   2 Strong      + third-party requests whose address looks like an ad request
//   3 Aggressive  + a wider set of address patterns, pop-ups and anti-adblock walls
// Pages the app marks as fragile (video, sign-in, banking...) are always treated as level 0.
//
//   hosts.txt    - hosts that only ever serve ads/trackers: blocked everywhere
//   hosts3p.txt  - hosts blocked only when a *different* site is asking for them
//
// Both lists are derived from EasyList / EasyPrivacy (CC BY-SA 3.0+ / GPLv3+) plus a short
// hand-picked set. A host also blocks all of its subdomains.

// Video sites, captcha and bot-check pages: the blocker stays out of the way entirely.
const EXCEPT = new Set([
  "youtube.com", "youtu.be", "youtube-nocookie.com", "googlevideo.com", "ytimg.com",
  "ggpht.com", "gstatic.com", "googleusercontent.com", "accounts.google.com",
  "cloudflare.com", "cloudflareinsights.com", "hcaptcha.com", "recaptcha.net",
  "arkoselabs.com", "funcaptcha.com", "turnstile.com", "challenges.cloudflare.com"
]);

let ALL = new Set();
let THIRD = new Set();

// Third-party requests that look like ads. Strong uses the first list, Aggressive both.
const PATTERN_STRONG = [
  /\/pagead\//i, /\/adserver\//i, /\/ad[-_]?(?:frame|iframe|server|view|click|request)\b/i,
  /[?&](?:ad_?unit|adunit|adslot|ad_?id)=/i, /\/banners?\/ads?\b/i, /\/(?:prebid|amazon-?a9)[^/]*\.js/i,
  /\/ads?\.(?:js|php|html|json)\b/i, /\/ads\/(?:show|serve|banner|js)/i
];
const PATTERN_AGGRESSIVE = [
  /\/ads?\/[^?#]*\.(?:js|gif|png|jpg|html)/i, /\/advert(?:s|ising|isement)?\//i, /\/sponsor(?:ed|s)?\//i,
  /\/(?:popunder|popup|pop-under|clickunder)\b/i, /[?&](?:affid|aff_id|affiliate_?id|clickid|zoneid)=/i,
  /\/(?:ad|ads|adv)[-_.]?[a-z0-9]{0,12}\.(?:js)\b/i, /\/(?:track|tracking|beacon|pixel)\.(?:gif|php|js)\b/i
];

// Well-known scripts that are swapped, not cancelled. [pattern, stand-in file]
const SWAP = [
  [/^https?:\/\/(?:pagead2\.)?googlesyndication\.com\/pagead\/(?:js\/)?adsbygoogle\.js/i, "res/adsbygoogle.js"],
  [/^https?:\/\/(?:www\.|securepubads\.g\.)?(?:googletagservices\.com|doubleclick\.net)\/tag\/js\/gpt\.js/i, "res/gpt.js"],
  [/^https?:\/\/(?:www\.|ssl\.)?google-analytics\.com\/(?:analytics|ga)\.js/i, "res/noop.js"]
];

function hostOf(url) {
  try {
    return new URL(url).hostname.toLowerCase();
  } catch (e) {
    return "";
  }
}

// True when `host` or any parent domain of it is in `set`.
function inSet(set, host) {
  let h = host;
  for (;;) {
    if (set.has(h)) return true;
    const i = h.indexOf(".");
    if (i < 0) return false;
    h = h.slice(i + 1);
  }
}

function excepted(host) {
  return host.includes("captcha") || host.includes("challenge") || inSet(EXCEPT, host);
}

async function loadList(name) {
  const res = await fetch(browser.runtime.getURL(name));
  const text = await res.text();
  const set = new Set();
  for (const line of text.split("\n")) {
    const h = line.trim();
    if (h) set.add(h);
  }
  return set;
}

// Requests wait for this, so nothing slips through while the lists are still loading.
const ready = Promise.all([loadList("hosts.txt"), loadList("hosts3p.txt")])
  .then(([all, third]) => {
    ALL = all;
    THIRD = third;
  })
  .catch(() => {
    // If a list can't be read the blocker simply does nothing; pages still load.
  });

// ---- per-site choices and counters, shared with the app -----------------------------------
//
// The app owns the per-site switches (Ads, JavaScript) and the aggression level. The blocker asks
// it once per page load, and reports how many requests it cancelled so the toolbar's site panel
// can show it.
const APP = "liquidair";
const policy = new Map(); // top-level host -> { ads, js, level }
const counts = new Map(); // top-level host -> requests cancelled since the last report

function ask(msg) {
  return Promise.race([
    browser.runtime.sendNativeMessage(APP, msg),
    new Promise((resolve) => setTimeout(() => resolve(null), 600))
  ]).catch(() => null);
}

async function refresh(host) {
  const r = await ask({ t: "policy", host });
  const level = r && typeof r.level === "number" ? r.level : 1;
  const p = { ads: !r || r.ads !== false, js: !r || r.js !== false, level: level };
  policy.set(host, p);
  return p;
}

// The page a request belongs to: the top-most frame when the engine tells us, else the document.
function topHost(d) {
  if (d.frameAncestors && d.frameAncestors.length) {
    return hostOf(d.frameAncestors[d.frameAncestors.length - 1].url);
  }
  return hostOf(d.documentUrl || d.originUrl || "");
}

function count(host) {
  if (host) counts.set(host, (counts.get(host) || 0) + 1);
}

setInterval(() => {
  if (!counts.size) return;
  const out = {};
  for (const [h, n] of counts) out[h] = n;
  counts.clear();
  ask({ t: "blocked", counts: out });
}, 1500);

function looksLikeAd(url, level) {
  if (level >= 2) for (const re of PATTERN_STRONG) if (re.test(url)) return true;
  if (level >= 3) for (const re of PATTERN_AGGRESSIVE) if (re.test(url)) return true;
  return false;
}

browser.webRequest.onBeforeRequest.addListener(
  async (d) => {
    // Page navigations are handled by the app itself, so a wrong guess here can never
    // leave a user unable to open a site. We only learn this site's choices here.
    if (d.type === "main_frame") {
      const h = hostOf(d.url);
      if (h) await refresh(h);
      return {};
    }
    await ready;

    const host = hostOf(d.url);
    if (!host || excepted(host)) return {};

    const from = hostOf(d.documentUrl || d.originUrl || "");
    if (from && excepted(from)) return {};

    const top = topHost(d);
    const p = policy.get(top);
    if (p && p.ads === false) return {};
    const level = p ? p.level : 1;

    if (d.type === "script") {
      for (const [re, file] of SWAP) {
        if (re.test(d.url)) {
          count(top);
          return { redirectUrl: browser.runtime.getURL(file) };
        }
      }
    }

    if (
      inSet(ALL, host) ||
      (level >= 1 && d.thirdParty && inSet(THIRD, host)) ||
      (level >= 2 && d.thirdParty && looksLikeAd(d.url, level))
    ) {
      count(top);
      return { cancel: true };
    }
    return {};
  },
  { urls: ["http://*/*", "https://*/*", "ws://*/*", "wss://*/*"] },
  ["blocking"]
);

// "Block JavaScript on this site": the page is served with a policy that allows no scripts.
browser.webRequest.onHeadersReceived.addListener(
  (d) => {
    const top = d.type === "main_frame" ? hostOf(d.url) : topHost(d);
    const p = policy.get(top);
    if (!p || p.js !== false) return {};
    const headers = (d.responseHeaders || []).slice();
    headers.push({ name: "Content-Security-Policy", value: "script-src 'none'" });
    return { responseHeaders: headers };
  },
  { urls: ["http://*/*", "https://*/*"], types: ["main_frame", "sub_frame"] },
  ["blocking", "responseHeaders"]
);

browser.runtime.onMessage.addListener((msg, sender) => {
  // Content scripts on media sites ask whether "Background play" is on.
  if (msg && msg.t === "bg") {
    return ask({ t: "bg" }).then((r) => !r || r.on !== false);
  }
  // The page-cleaning scripts ask for this page's shield state and aggression level.
  if (msg && msg.t === "cfg") {
    const h = hostOf((sender && sender.tab && sender.tab.url) || "");
    return refresh(h).then((p) => ({ ads: p.ads, level: p.level }));
  }
  return undefined;
});
