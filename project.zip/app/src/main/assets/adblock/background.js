"use strict";

// Liquid Air network blocker.
//
// It cancels *requests* (scripts, frames, pixels, beacons, XHR/fetch, WebSockets) to known
// ad and tracker hosts. It never touches a page's own HTML, CSS or images, so a site held
// together with inline styles lays out exactly as it otherwise would.
//
//   hosts.txt    - hosts that only ever serve ads/trackers: blocked everywhere
//   hosts3p.txt  - hosts blocked only when a *different* site is asking for them
//
// Both lists are derived from EasyList / EasyPrivacy (CC BY-SA 3.0+ / GPLv3+) plus a short
// hand-picked set. A host also blocks all of its subdomains.

// Video sites, captcha and bot-check pages: the blocker stays out of the way entirely.
const EXCEPT = new Set([
  "youtube.com", "youtu.be", "youtube-nocookie.com", "googlevideo.com", "ytimg.com",
  "cloudflare.com", "cloudflareinsights.com", "hcaptcha.com", "recaptcha.net",
  "arkoselabs.com", "funcaptcha.com", "turnstile.com"
]);

let ALL = new Set();
let THIRD = new Set();

function hostOf(url) {
  try {
    return new URL(url).hostname.toLowerCase();
  } catch (e) {
    return "";
  }
}

// True when `host` or any parent domain of it is in `set`.
function inSet(set, host) {
  let h = host;
  for (;;) {
    if (set.has(h)) return true;
    const i = h.indexOf(".");
    if (i < 0) return false;
    h = h.slice(i + 1);
  }
}

function excepted(host) {
  return host.includes("captcha") || host.includes("challenge") || inSet(EXCEPT, host);
}

async function loadList(name) {
  const res = await fetch(browser.runtime.getURL(name));
  const text = await res.text();
  const set = new Set();
  for (const line of text.split("\n")) {
    const h = line.trim();
    if (h) set.add(h);
  }
  return set;
}

// Requests wait for this, so nothing slips through while the lists are still loading.
const ready = Promise.all([loadList("hosts.txt"), loadList("hosts3p.txt")])
  .then(([all, third]) => {
    ALL = all;
    THIRD = third;
  })
  .catch(() => {
    // If a list can't be read the blocker simply does nothing; pages still load.
  });

// ---- per-site choices and counters, shared with the app -----------------------------------
//
// The app owns the per-site switches (Ads, JavaScript). The blocker asks it once per page load,
// and reports how many requests it cancelled so the toolbar's site panel can show it.
const APP = "liquidair";
const policy = new Map(); // top-level host -> { ads, js }
const counts = new Map(); // top-level host -> requests cancelled since the last report

function ask(msg) {
  return Promise.race([
    browser.runtime.sendNativeMessage(APP, msg),
    new Promise((resolve) => setTimeout(() => resolve(null), 600))
  ]).catch(() => null);
}

async function refresh(host) {
  const r = await ask({ t: "policy", host });
  const p = { ads: !r || r.ads !== false, js: !r || r.js !== false };
  policy.set(host, p);
  return p;
}

// The page a request belongs to: the top-most frame when the engine tells us, else the document.
function topHost(d) {
  if (d.frameAncestors && d.frameAncestors.length) {
    return hostOf(d.frameAncestors[d.frameAncestors.length - 1].url);
  }
  return hostOf(d.documentUrl || d.originUrl || "");
}

function count(host) {
  if (host) counts.set(host, (counts.get(host) || 0) + 1);
}

setInterval(() => {
  if (!counts.size) return;
  const out = {};
  for (const [h, n] of counts) out[h] = n;
  counts.clear();
  ask({ t: "blocked", counts: out });
}, 1500);

browser.webRequest.onBeforeRequest.addListener(
  async (d) => {
    // Page navigations are handled by the app itself, so a wrong guess here can never
    // leave a user unable to open a site. We only learn this site's choices here.
    if (d.type === "main_frame") {
      const h = hostOf(d.url);
      if (h) await refresh(h);
      return {};
    }
    await ready;

    const host = hostOf(d.url);
    if (!host || excepted(host)) return {};

    const from = hostOf(d.documentUrl || d.originUrl || "");
    if (from && excepted(from)) return {};

    const top = topHost(d);
    const p = policy.get(top);
    if (p && p.ads === false) return {};

    if (inSet(ALL, host) || (d.thirdParty && inSet(THIRD, host))) {
      count(top);
      return { cancel: true };
    }
    return {};
  },
  { urls: ["http://*/*", "https://*/*", "ws://*/*", "wss://*/*"] },
  ["blocking"]
);

// "Block JavaScript on this site": the page is served with a policy that allows no scripts.
browser.webRequest.onHeadersReceived.addListener(
  (d) => {
    const top = d.type === "main_frame" ? hostOf(d.url) : topHost(d);
    const p = policy.get(top);
    if (!p || p.js !== false) return {};
    const headers = (d.responseHeaders || []).slice();
    headers.push({ name: "Content-Security-Policy", value: "script-src 'none'" });
    return { responseHeaders: headers };
  },
  { urls: ["http://*/*", "https://*/*"], types: ["main_frame", "sub_frame"] },
  ["blocking", "responseHeaders"]
);
