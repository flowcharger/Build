/* Runs on Google result pages only. Colours are left to the page, so they follow the
   system light/dark setting. It only swaps the Google logo for "Liquid Air", names
   the tab, and keeps the Google Images preview on screen. */
(function () {
  try {
    if (!/^(www\.)?google\.(com?\.)?[a-z]{2,3}$/.test(location.hostname) || location.pathname !== "/search") {
      return;
    }
    var css =
      "body .la-logo{display:inline-block!important;color:CanvasText!important;" +
      "font:700 26px Arial,Helvetica,sans-serif!important;letter-spacing:.01em!important;" +
      "padding:0 10px!important;text-decoration:none!important}" +
      "body .la-banner{display:block!important;text-align:center!important;padding:10px 0 6px!important}";

    function style() {
      var node = document.getElementById("la-style");
      if (!node) {
        node = document.createElement("style");
        node.id = "la-style";
        (document.head || document.documentElement).appendChild(node);
      }
      if (node.textContent !== css) node.textContent = css;
    }

    function title() {
      var query = "";
      try { query = new URLSearchParams(location.search).get("q") || ""; } catch (e) {}
      var wanted = (query ? query + " – " : "") + "Liquid Air";
      if (document.title !== wanted) document.title = wanted;
    }

    function logo() {
      var selectors = [
        "a#logo", "#logo", "a[aria-label='Google']", "[aria-label='Google']",
        "a[title='Go to Google Home']", "a[href^='/webhp']", "a[href*='/webhp?']",
        "svg[aria-label='Google']", "img[alt='Google']", "img[src*='googlelogo']", ".logo"
      ];
      var i, j, list, el, target, tag, box, span;
      for (i = 0; i < selectors.length; i++) {
        list = document.querySelectorAll(selectors[i]);
        for (j = 0; j < list.length; j++) {
          el = list[j];
          if (el.classList && el.classList.contains("la-logo")) continue;
          tag = String(el.tagName).toLowerCase();
          target = tag === "img" || tag === "svg" || tag === "picture" ? el.closest("a") || el : el;
          if (target.getAttribute("data-la")) continue;
          box = target.getBoundingClientRect();
          if (box.width === 0 && box.height === 0) continue;
          if (box.top > 200 || box.width > 360 || box.height > 130) continue;
          target.setAttribute("data-la", "1");
          span = document.createElement("span");
          span.className = "la-logo";
          span.textContent = "Liquid Air";
          if (target === el && tag !== "a" && tag !== "div" && tag !== "span") {
            target.parentNode.replaceChild(span, target);
          } else {
            while (target.firstChild) target.removeChild(target.firstChild);
            target.appendChild(span);
          }
        }
      }
    }

    function banner() {
      if (!document.body || document.querySelector(".la-logo")) return;
      var bar = document.createElement("div");
      bar.className = "la-logo la-banner";
      bar.textContent = "Liquid Air";
      document.body.insertBefore(bar, document.body.firstChild);
    }

    /* Google Images: keep the picture preview in view instead of at the top of the page. */
    function imagesFix() {
      if (!/[?&](tbm=isch|udm=2)(&|$)/.test(location.search) || window.__laImgFix) return;
      window.__laImgFix = true;
      var before = [];
      var clickedArea = 0;
      function big(img) { var r = img.getBoundingClientRect(); return r.width >= 200 && r.height >= 150; }
      function check() {
        var imgs = document.querySelectorAll("img"), i, r, img, box, p, pr, best = null, bestArea = 0, a;
        for (i = 0; i < imgs.length; i++) {
          img = imgs[i];
          if (before.indexOf(img) > -1 || !big(img)) continue;
          r = img.getBoundingClientRect();
          if (r.bottom >= 0) continue;
          a = r.width * r.height;
          if (clickedArea && a < clickedArea * 1.3) continue;
          if (a > bestArea) { best = img; bestArea = a; }
        }
        if (!best) return;
        box = best;
        p = best.parentElement;
        while (p && p !== document.body && p !== document.documentElement) {
          pr = p.getBoundingClientRect();
          if (pr.width > window.innerWidth * 1.02 || pr.height > window.innerHeight * 1.4) break;
          box = p;
          p = p.parentElement;
        }
        if (box === best || box.__laPinned) return;
        pr = box.getBoundingClientRect();
        box.__laPinned = true;
        var saved = box.getAttribute("style");
        var shade = document.createElement("div");
        shade.setAttribute("style", "position:fixed;top:0;left:0;right:0;bottom:0;width:100vw;height:100vh;background:rgba(0,0,0,.5);z-index:2147482999;");
        document.body.appendChild(shade);
        var w = Math.min(window.innerWidth * 0.96, Math.max(pr.width, 300));
        var props = {
          "position": "fixed", "top": "50%", "left": "50%", "right": "auto", "bottom": "auto",
          "transform": "translate(-50%, -50%)", "width": w + "px", "max-width": "96vw",
          "max-height": "90vh", "overflow": "auto", "z-index": "2147483000",
          "background-color": "Canvas", "border-radius": "16px", "box-shadow": "0 8px 30px rgba(0,0,0,.35)"
        };
        for (var k in props) box.style.setProperty(k, props[k], "important");
        shade.addEventListener("click", function () {
          if (shade.parentNode) shade.parentNode.removeChild(shade);
          if (saved === null) box.removeAttribute("style"); else box.setAttribute("style", saved);
          box.__laPinned = false;
        });
      }
      document.addEventListener("click", function (e) {
        var imgs = document.querySelectorAll("img"), i, hit = null;
        before = [];
        for (i = 0; i < imgs.length; i++) { if (big(imgs[i])) before.push(imgs[i]); }
        try {
          hit = e.target && e.target.querySelector ? (e.target.tagName === "IMG" ? e.target : e.target.querySelector("img")) : null;
        } catch (error) {}
        if (hit) { var r = hit.getBoundingClientRect(); clickedArea = r.width * r.height; } else clickedArea = 0;
        var n = 0;
        var timer = setInterval(function () { check(); n++; if (n >= 12) clearInterval(timer); }, 250);
      }, true);
    }

    function apply() { style(); title(); logo(); }
    apply();
    imagesFix();
    var runs = 0;
    var timer = setInterval(function () {
      runs++;
      apply();
      if (runs === 3) banner();
      if (runs >= 10) clearInterval(timer);
    }, 700);
    if (window.MutationObserver) {
      var waiting = false;
      new MutationObserver(function () {
        if (waiting) return;
        waiting = true;
        setTimeout(function () { waiting = false; apply(); }, 800);
      }).observe(document.documentElement, { childList: true, subtree: true });
    }
  } catch (error) {}
})();
