package com.liquidair.browser

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.ColorFilter
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PixelFormat
import android.graphics.RadialGradient
import android.graphics.Rect
import android.graphics.Shader
import android.graphics.Typeface
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.RippleDrawable
import android.content.res.ColorStateList
import android.text.TextUtils
import android.util.TypedValue
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import kotlin.math.max

/** Colours used everywhere in the interface. */
object C {
    const val INK = 0xFF1B1F1D.toInt()
    const val MUTED = 0xFF67716B.toInt()
    const val LINE = 0x1A18221C
    const val WHITE = 0xFFFFFFFF.toInt()
    const val SOFT = 0xFFF2F4F2.toInt()
    const val MINT = 0xFFCFEEDD.toInt()
    const val GLASS = 0x59FFFFFF
    const val GLASS_EDGE = 0xA8FFFFFF.toInt()
    const val SKY_A = 0xFF5FC4FF.toInt()
    const val SKY_B = 0xFFC4ECFF.toInt()
    const val SKY_C = 0xFF3D9CF5.toInt()
}

fun Context.dp(v: Int): Int = (v * resources.displayMetrics.density + 0.5f).toInt()
fun Context.dpf(v: Float): Float = v * resources.displayMetrics.density

/** The frosted "liquid glass" look: a see-through white fill with a bright edge. */
fun glass(ctx: Context, radiusDp: Float, fill: Int = C.GLASS, edge: Int = C.GLASS_EDGE): GradientDrawable {
    return GradientDrawable().apply {
        cornerRadius = ctx.dpf(radiusDp)
        setColor(fill)
        setStroke(max(1, ctx.dp(1)), edge)
    }
}

fun solid(ctx: Context, color: Int, radiusDp: Float): GradientDrawable {
    return GradientDrawable().apply {
        cornerRadius = ctx.dpf(radiusDp)
        setColor(color)
    }
}

/** Adds a soft touch ripple on top of any background. */
fun withRipple(bg: Drawable?, mask: Drawable? = null): Drawable {
    return RippleDrawable(ColorStateList.valueOf(0x22000000), bg, mask ?: if (bg == null) ColorDrawable(Color.WHITE) else null)
}

fun lp(w: Int, h: Int): LinearLayout.LayoutParams = LinearLayout.LayoutParams(w, h)

fun icon(ctx: Context, res: Int, sizeDp: Int): ImageView {
    return ImageView(ctx).apply {
        setImageResource(res)
        scaleType = ImageView.ScaleType.FIT_CENTER
        layoutParams = ViewGroup.LayoutParams(ctx.dp(sizeDp), ctx.dp(sizeDp))
    }
}

/** A square touch target holding an icon. */
fun iconButton(ctx: Context, res: Int, boxW: Int, boxH: Int, iconDp: Int, desc: String): FrameLayout {
    val box = FrameLayout(ctx)
    box.layoutParams = LinearLayout.LayoutParams(ctx.dp(boxW), ctx.dp(boxH))
    val img = icon(ctx, res, iconDp)
    img.layoutParams = FrameLayout.LayoutParams(ctx.dp(iconDp), ctx.dp(iconDp), Gravity.CENTER)
    box.addView(img)
    box.contentDescription = desc
    box.isClickable = true
    box.background = withRipple(null)
    return box
}

fun FrameLayout.iconView(): ImageView = getChildAt(0) as ImageView

fun text(ctx: Context, s: String, sp: Float, color: Int = C.INK, bold: Boolean = false): TextView {
    return TextView(ctx).apply {
        text = s
        setTextSize(TypedValue.COMPLEX_UNIT_SP, sp)
        setTextColor(color)
        if (bold) typeface = Typeface.DEFAULT_BOLD
        includeFontPadding = false
    }
}

fun oneLine(tv: TextView): TextView {
    tv.maxLines = 1
    tv.ellipsize = TextUtils.TruncateAt.END
    return tv
}

fun View.pad(l: Int, t: Int, r: Int, b: Int) {
    setPadding(context.dp(l), context.dp(t), context.dp(r), context.dp(b))
}

/** Sky-blue gradient ring: draws a gradient, the card sits inside with a small margin. */
fun skyRing(ctx: Context, radiusDp: Float): GradientDrawable {
    return GradientDrawable(
        GradientDrawable.Orientation.TL_BR,
        intArrayOf(C.SKY_A, C.SKY_B, C.SKY_C)
    ).apply { cornerRadius = ctx.dpf(radiusDp) }
}

/** Smooth value animation helper. */
fun animate(durationMs: Long, from: Float, to: Float, onValue: (Float) -> Unit): ValueAnimator {
    return ValueAnimator.ofFloat(from, to).apply {
        duration = durationMs
        addUpdateListener { onValue(it.animatedValue as Float) }
        start()
    }
}

/**
 * The Liquid Air picture: pale sky, a low sun and layered green hills. Drawn with
 * paths, so it costs almost nothing and stays sharp on any screen.
 */
class ArtDrawable(private val ctx: Context) : Drawable() {
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val hills = arrayOf(
        "M0 560 C170 470 330 520 520 450 C720 380 860 470 1040 420 C1240 365 1420 440 1600 380 L1600 1000 L0 1000Z" to intArrayOf(0xFFCFDCC9.toInt(), 0xFFDFE8D9.toInt()),
        "M0 640 C190 560 360 620 560 560 C760 500 900 590 1100 540 C1290 495 1450 560 1600 520 L1600 1000 L0 1000Z" to intArrayOf(0xFFB5CCB0.toInt(), 0xFFC9DAC3.toInt()),
        "M0 730 C160 660 330 720 540 670 C740 622 900 700 1090 660 C1290 618 1440 690 1600 650 L1600 1000 L0 1000Z" to intArrayOf(0xFF98B996.toInt(), 0xFFB0C9AC.toInt()),
        "M0 810 C200 750 380 800 600 765 C820 730 960 800 1180 770 C1360 745 1490 790 1600 760 L1600 1000 L0 1000Z" to intArrayOf(0xFF7EA282.toInt(), 0xFF97B698.toInt()),
        "M0 900 C230 850 430 890 680 865 C900 842 1060 895 1280 872 C1430 856 1530 880 1600 866 L1600 1000 L0 1000Z" to intArrayOf(0xFF628A6C.toInt(), 0xFF7A9F80.toInt())
    ).map { (d, colors) -> parse(d) to colors }

    private val ridges = arrayOf(
        "M40 748 C200 690 330 735 540 690",
        "M690 668 C820 650 930 700 1090 676",
        "M60 826 C240 780 390 818 600 788",
        "M760 760 C900 752 1000 800 1180 788"
    ).map { parse(it) }

    /** Reads the simple absolute M/C/L/Z path strings used above. */
    private fun parse(d: String): Path {
        val path = Path()
        val tokens = Regex("[MCLZ]|-?\\d+(?:\\.\\d+)?").findAll(d).map { it.value }.toList()
        var i = 0
        fun num(): Float = tokens[i++].toFloat()
        while (i < tokens.size) {
            when (tokens[i++]) {
                "M" -> path.moveTo(num(), num())
                "L" -> path.lineTo(num(), num())
                "C" -> {
                    val a = num(); val b = num(); val c = num(); val e = num(); val f = num(); val g = num()
                    path.cubicTo(a, b, c, e, f, g)
                }
                "Z" -> path.close()
            }
        }
        return path
    }

    override fun draw(canvas: Canvas) {
        val b: Rect = bounds
        val w = b.width().toFloat()
        val h = b.height().toFloat()
        if (w <= 0f || h <= 0f) return

        // Sky.
        paint.shader = LinearGradient(0f, 0f, 0f, h, intArrayOf(0xFFF6F3EA.toInt(), 0xFFEEF1E6.toInt(), 0xFFE3EBDD.toInt()), floatArrayOf(0f, .55f, 1f), Shader.TileMode.CLAMP)
        canvas.drawRect(0f, 0f, w, h, paint)
        paint.shader = null

        // "xMidYMid slice": scale to cover, centred.
        val scale = max(w / 1600f, h / 1000f)
        val dx = (w - 1600f * scale) / 2f
        val dy = (h - 1000f * scale) / 2f
        canvas.save()
        canvas.translate(dx, dy)
        canvas.scale(scale, scale)

        paint.shader = RadialGradient(1130f, 330f, 260f, intArrayOf(0xF2FFFBE9.toInt(), 0x8CFBF1D3.toInt(), 0x00FBF1D3), floatArrayOf(0f, .6f, 1f), Shader.TileMode.CLAMP)
        canvas.drawCircle(1130f, 330f, 260f, paint)
        paint.shader = null
        paint.color = 0xE6FFFAF0.toInt()
        canvas.drawCircle(1130f, 330f, 62f, paint)

        paint.color = 0x99FFFFFF.toInt()
        canvas.drawOval(160f, 224f, 500f, 276f, paint)
        canvas.drawOval(320f, 202f, 540f, 250f, paint)
        canvas.drawOval(620f, 150f, 900f, 190f, paint)
        canvas.drawOval(1290f, 190f, 1550f, 230f, paint)

        for ((path, colors) in hills) {
            val top = pathTop(path)
            paint.shader = LinearGradient(0f, top, 0f, 1000f, colors[0], colors[1], Shader.TileMode.CLAMP)
            canvas.drawPath(path, paint)
        }
        paint.shader = null
        paint.style = Paint.Style.STROKE
        paint.strokeWidth = 3f
        paint.strokeCap = Paint.Cap.ROUND
        paint.color = 0x59FFFFFF
        for (r in ridges) canvas.drawPath(r, paint)
        paint.style = Paint.Style.FILL
        canvas.restore()
    }

    private fun pathTop(p: Path): Float {
        val r = android.graphics.RectF()
        p.computeBounds(r, true)
        return r.top
    }

    override fun setAlpha(alpha: Int) {}
    override fun setColorFilter(colorFilter: ColorFilter?) {}
    @Suppress("OVERRIDE_DEPRECATION")
    override fun getOpacity(): Int = PixelFormat.OPAQUE
}
