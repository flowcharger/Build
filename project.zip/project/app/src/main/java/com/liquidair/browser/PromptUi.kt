package com.liquidair.browser

import android.app.AlertDialog
import android.net.Uri
import android.text.InputType
import android.widget.EditText
import org.mozilla.geckoview.GeckoResult
import org.mozilla.geckoview.GeckoSession

private typealias Resp = GeckoSession.PromptDelegate.PromptResponse

/** Web page dialogs: alert(), confirm(), prompt(), drop-down lists and file pickers. */
class PromptUi(private val act: MainActivity) {

    /** Makes sure a prompt is answered exactly once. */
    private class Once(val result: GeckoResult<Resp>) {
        var done = false
        fun finish(r: Resp) {
            if (!done) {
                done = true
                result.complete(r)
            }
        }
    }

    fun alert(p: GeckoSession.PromptDelegate.AlertPrompt): GeckoResult<Resp> {
        val o = Once(GeckoResult())
        AlertDialog.Builder(act)
            .setTitle(p.title)
            .setMessage(p.message)
            .setPositiveButton("OK") { _, _ -> o.finish(p.dismiss()) }
            .setOnCancelListener { o.finish(p.dismiss()) }
            .show()
        return o.result
    }

    fun button(p: GeckoSession.PromptDelegate.ButtonPrompt): GeckoResult<Resp> {
        val o = Once(GeckoResult())
        AlertDialog.Builder(act)
            .setTitle(p.title)
            .setMessage(p.message)
            .setPositiveButton("OK") { _, _ -> o.finish(p.confirm(GeckoSession.PromptDelegate.ButtonPrompt.Type.POSITIVE)) }
            .setNegativeButton("Cancel") { _, _ -> o.finish(p.confirm(GeckoSession.PromptDelegate.ButtonPrompt.Type.NEGATIVE)) }
            .setOnCancelListener { o.finish(p.dismiss()) }
            .show()
        return o.result
    }

    fun text(p: GeckoSession.PromptDelegate.TextPrompt): GeckoResult<Resp> {
        val o = Once(GeckoResult())
        val input = EditText(act)
        input.inputType = InputType.TYPE_CLASS_TEXT
        input.setText(p.defaultValue ?: "")
        AlertDialog.Builder(act)
            .setTitle(p.title)
            .setMessage(p.message)
            .setView(input)
            .setPositiveButton("OK") { _, _ -> o.finish(p.confirm(input.text.toString())) }
            .setNegativeButton("Cancel") { _, _ -> o.finish(p.dismiss()) }
            .setOnCancelListener { o.finish(p.dismiss()) }
            .show()
        return o.result
    }

    /** Drop-down menus (<select>) and lists. */
    fun choice(p: GeckoSession.PromptDelegate.ChoicePrompt): GeckoResult<Resp> {
        val o = Once(GeckoResult())
        val flat = ArrayList<GeckoSession.PromptDelegate.ChoicePrompt.Choice>()
        fun walk(list: Array<GeckoSession.PromptDelegate.ChoicePrompt.Choice>?) {
            if (list == null) return
            for (c in list) {
                if (c.separator) continue
                val kids = c.items
                if (kids != null && kids.isNotEmpty()) walk(kids) else flat.add(c)
            }
        }
        walk(p.choices)
        val labels = flat.map { it.label }.toTypedArray<CharSequence>()
        val builder = AlertDialog.Builder(act).setTitle(p.title ?: p.message)
        if (p.type == GeckoSession.PromptDelegate.ChoicePrompt.Type.MULTIPLE) {
            val checked = BooleanArray(flat.size) { flat[it].selected }
            builder.setMultiChoiceItems(labels, checked) { _, which, on -> checked[which] = on }
                .setPositiveButton("OK") { _, _ ->
                    val ids = ArrayList<String>()
                    for (i in flat.indices) if (checked[i]) ids.add(flat[i].id)
                    o.finish(p.confirm(ids.toTypedArray()))
                }
                .setNegativeButton("Cancel") { _, _ -> o.finish(p.dismiss()) }
        } else {
            builder.setItems(labels) { _, which -> o.finish(p.confirm(flat[which].id)) }
        }
        builder.setOnCancelListener { o.finish(p.dismiss()) }.show()
        return o.result
    }

    fun file(p: GeckoSession.PromptDelegate.FilePrompt): GeckoResult<Resp> {
        val o = Once(GeckoResult())
        if (p.type == GeckoSession.PromptDelegate.FilePrompt.Type.FOLDER) {
            o.finish(p.dismiss())
            return o.result
        }
        val multiple = p.type == GeckoSession.PromptDelegate.FilePrompt.Type.MULTIPLE
        act.pickFiles(p.mimeTypes?.toList().orEmpty(), multiple) { uris: List<Uri> ->
            if (uris.isEmpty()) {
                o.finish(p.dismiss())
            } else if (multiple) {
                o.finish(p.confirm(act, uris.toTypedArray()))
            } else {
                o.finish(p.confirm(act, uris[0]))
            }
        }
        return o.result
    }
}
