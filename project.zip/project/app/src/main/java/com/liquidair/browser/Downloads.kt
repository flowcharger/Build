package com.liquidair.browser

import android.content.ContentValues
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import org.mozilla.geckoview.WebResponse
import java.io.File
import java.io.FileOutputStream
import java.io.InputStream
import java.io.OutputStream
import java.net.HttpURLConnection
import java.net.URL

class DownloadItem(val name: String, val url: String) {
    var status: String = "Downloading…"
    var uri: Uri? = null
}

/** Saves files the engine hands over (and links the user pastes) into Downloads. */
class Downloads(private val act: MainActivity) {
    val items = ArrayList<DownloadItem>()

    /** A response from the engine (a file the page wants to download). */
    fun save(response: WebResponse) {
        var disposition: String? = null
        var type: String? = null
        for ((k, v) in response.headers) {
            if (k.equals("content-disposition", true)) disposition = v
            if (k.equals("content-type", true)) type = v
        }
        val name = fileName(disposition, response.uri)
        val item = DownloadItem(name, response.uri)
        items.add(0, item)
        act.onDownloadsChanged()
        val body = response.body
        if (body == null) {
            finish(item, null, "Failed")
            return
        }
        Thread { write(item, body, type) }.start()
    }

    /** A link the user typed on the Downloads page. */
    fun fetch(url: String) {
        if (!Urls.isWeb(url)) {
            act.toast("Paste a full link that starts with https://")
            return
        }
        val item = DownloadItem(fileName(null, url), url)
        items.add(0, item)
        act.onDownloadsChanged()
        Thread {
            try {
                val c = URL(url).openConnection() as HttpURLConnection
                c.connectTimeout = 15000
                c.readTimeout = 30000
                c.instanceFollowRedirects = true
                if (c.responseCode in 200..299) {
                    write(item, c.inputStream, c.contentType)
                } else {
                    finish(item, null, "Failed (${c.responseCode})")
                }
            } catch (e: Exception) {
                finish(item, null, "Failed")
            }
        }.start()
    }

    private fun write(item: DownloadItem, input: InputStream, mime: String?) {
        try {
            var out: OutputStream
            var uri: Uri? = null
            var pendingValues: ContentValues? = null
            if (Build.VERSION.SDK_INT >= 29) {
                val values = ContentValues().apply {
                    put(MediaStore.Downloads.DISPLAY_NAME, item.name)
                    put(MediaStore.Downloads.MIME_TYPE, mime?.substringBefore(';') ?: "application/octet-stream")
                    put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS)
                    put(MediaStore.Downloads.IS_PENDING, 1)
                }
                uri = act.contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values)
                    ?: throw IllegalStateException("no uri")
                out = act.contentResolver.openOutputStream(uri) ?: throw IllegalStateException("no stream")
                pendingValues = ContentValues().apply { put(MediaStore.Downloads.IS_PENDING, 0) }
            } else {
                val dir = act.getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS) ?: act.filesDir
                val file = File(dir, item.name)
                out = FileOutputStream(file)
                uri = null
            }
            input.use { src -> out.use { dst -> src.copyTo(dst) } }
            if (uri != null && pendingValues != null) {
                act.contentResolver.update(uri, pendingValues, null, null)
            }
            finish(item, uri, "Done")
        } catch (e: Exception) {
            finish(item, null, "Failed")
        }
    }

    private fun finish(item: DownloadItem, uri: Uri?, status: String) {
        act.runOnUiThread {
            item.uri = uri
            item.status = status
            act.onDownloadsChanged()
            if (status == "Done") act.toast("Downloaded ${item.name}")
        }
    }

    private fun fileName(disposition: String?, url: String): String {
        if (disposition != null) {
            val m = Regex("filename\\*?=(?:UTF-8'')?\"?([^\";]+)\"?", RegexOption.IGNORE_CASE).find(disposition)
            if (m != null) return clean(Uri.decode(m.groupValues[1]))
        }
        val last = url.substringBefore('?').substringBefore('#').trimEnd('/').substringAfterLast('/')
        return clean(Uri.decode(last)).ifEmpty { "download" }
    }

    private fun clean(s: String) = s.replace(Regex("[\\\\/:*?\"<>|]"), "_").trim()
}
