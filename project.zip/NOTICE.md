# Third-party notices

Air includes or builds on the following. Each keeps its own licence.

- **GeckoView** (the page engine) — Mozilla Public License 2.0, https://www.mozilla.org/MPL/2.0/
- **Ad and tracker host lists** (`app/src/main/assets/adblock/hosts.txt`, `hosts3p.txt`) —
  derived from EasyList and EasyPrivacy, licensed CC BY-SA 3.0 or later / GPLv3 or later
  (https://easylist.to/). These lists remain under that licence; changes were made (merged,
  reduced to host names). Anyone redistributing them must keep that licence and give credit.
- **Add-ons market** — add-on listings and downloads come from addons.mozilla.org; each add-on
  has its own licence.
- **News feeds** — headlines and pictures belong to their publishers and are shown only with a
  link to the original.
- **Wikipedia** summaries on the start page are CC BY-SA 4.0 (https://en.wikipedia.org/).
