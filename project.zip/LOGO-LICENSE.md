# Complexity logo licence

The Complexity logo (a white "-C-" on black) and the name "Complexity" are
Copyright (c) 2026 the Complexity authors. **All rights reserved.**

The logo is not covered by the MIT licence that applies to the source code.

You may:
- show the logo unchanged to refer to the Complexity browser (for example in a review or article);
- keep it in unmodified copies of the app.

You may not, without written permission:
- use it as the logo or icon of a different app, product or company;
- change it and present the result as the Complexity logo;
- use it in a way that suggests you are, or are endorsed by, the Complexity project.

If you build and distribute your own version of this source code, replace the logo and the name
with your own.

To ask for permission, contact the project owner.
