package com.liquidair.browser

import android.app.AlertDialog
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.text.Editable
import android.text.InputType
import android.text.TextWatcher
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.ViewOutlineProvider
import android.widget.CheckBox
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.PopupWindow
import android.widget.ScrollView
import android.widget.Switch
import android.widget.TextView
import java.util.Locale

/**
 * Settings, laid out like Chrome and Brave: a list of sections down the left side and the
 * chosen section on the right. On a narrow phone the sections become a row of chips on top.
 */
class SettingsPage(private val act: MainActivity) {

    private class Section(val key: String, val label: String, val icon: Int)

    private val sections = listOf(
        Section("general", "General", R.drawable.ic_tune),
        Section("themes", "Themes", R.drawable.ic_palette),
        Section("privacy", "Privacy and security", R.drawable.ic_shield),
        Section("passwords", "Passwords", R.drawable.ic_key),
        Section("downloads", "Downloads", R.drawable.ic_download),
        Section("data", "Import and export", R.drawable.ic_swap),
        Section("about", "About", R.drawable.ic_info)
    )

    private var wide = true
    private var navHost: LinearLayout? = null
    private var body: LinearLayout? = null
    private var scroll: ScrollView? = null
    private var shownSection = ""
    private var passwordQuery = ""

    private val prefs get() = act.prefs

    private fun dp(v: Int) = act.dp(v)

    // ---- frame: sections on the left, content on the right ---------------------------------

    fun build(): View {
        wide = act.resources.configuration.screenWidthDp >= 600
        val root = LinearLayout(act)
        root.orientation = if (wide) LinearLayout.HORIZONTAL else LinearLayout.VERTICAL

        val nav = LinearLayout(act)
        navHost = nav
        if (wide) {
            nav.orientation = LinearLayout.VERTICAL
            nav.pad(12, 8, 12, 16)
            val navScroll = ScrollView(act)
            navScroll.addView(nav, FrameLayout.LayoutParams(-1, -2))
            root.addView(navScroll, LinearLayout.LayoutParams(dp(264), -1))
            val divider = View(act)
            divider.setBackgroundColor(C.LINE)
            root.addView(divider, LinearLayout.LayoutParams(maxOf(1, dp(1)), -1))
        } else {
            nav.orientation = LinearLayout.HORIZONTAL
            nav.pad(12, 4, 12, 8)
            val hs = HorizontalScrollView(act)
            hs.isHorizontalScrollBarEnabled = false
            hs.addView(nav, FrameLayout.LayoutParams(-2, -2))
            root.addView(hs, LinearLayout.LayoutParams(-1, -2))
        }

        val sv = ScrollView(act)
        scroll = sv
        val frame = CappedFrame(act, dp(760))
        sv.addView(frame, FrameLayout.LayoutParams(-1, -2).apply { gravity = Gravity.CENTER_HORIZONTAL })
        val col = LinearLayout(act)
        col.orientation = LinearLayout.VERTICAL
        val side = if (wide) 24 else 16
        col.pad(side, 4, side, 40)
        frame.addView(col, FrameLayout.LayoutParams(-1, -2))
        body = col
        root.addView(
            sv,
            if (wide) LinearLayout.LayoutParams(0, -1, 1f) else LinearLayout.LayoutParams(-1, 0, 1f)
        )
        shownSection = ""
        render()
        return root
    }

    private fun render() {
        drawNav()
        val col = body ?: return
        val sameSection = shownSection == act.settingsSection
        val y = if (sameSection) scroll?.scrollY ?: 0 else 0
        shownSection = act.settingsSection
        col.removeAllViews()
        when (act.settingsSection) {
            "themes" -> themes(col)
            "privacy" -> privacy(col)
            "passwords" -> passwords(col)
            "downloads" -> downloadsSection(col)
            "data" -> data(col)
            "about" -> about(col)
            else -> general(col)
        }
        val sv = scroll
        if (sv != null) sv.post { sv.scrollTo(0, y) }
    }

    private fun drawNav() {
        val nav = navHost ?: return
        nav.removeAllViews()
        for (s in sections) {
            val on = act.settingsSection == s.key || (s.key == "general" && sections.none { it.key == act.settingsSection })
            val item = LinearLayout(act)
            item.gravity = Gravity.CENTER_VERTICAL
            if (wide) {
                item.pad(16, 0, 16, 0)
                item.background = if (on) solid(act, C.MINT, 26f) else withRipple(null, solid(act, Color.WHITE, 26f))
                item.addView(icon(act, s.icon, 22), LinearLayout.LayoutParams(dp(22), dp(22)).apply { rightMargin = dp(16) })
                item.addView(text(act, s.label, 15.5f, C.INK, on))
                nav.addView(item, lp(-1, dp(50)).apply { bottomMargin = dp(4) })
            } else {
                item.pad(14, 0, 16, 0)
                item.background = if (on) solid(act, C.MINT, 20f) else solid(act, C.SOFT, 20f)
                item.addView(icon(act, s.icon, 18), LinearLayout.LayoutParams(dp(18), dp(18)).apply { rightMargin = dp(8) })
                item.addView(text(act, s.label, 14f, C.INK, on))
                nav.addView(item, LinearLayout.LayoutParams(-2, dp(40)).apply { rightMargin = dp(8) })
            }
            item.setOnClickListener {
                if (act.settingsSection != s.key) {
                    act.settingsSection = s.key
                    render()
                }
            }
        }
    }

    // ---- building blocks -------------------------------------------------------------------

    private fun heading(col: LinearLayout, s: String) {
        val h = text(act, s, 14f, C.MUTED, true)
        h.pad(6, 22, 6, 8)
        col.addView(h, lp(-1, -2))
    }

    private fun note(col: LinearLayout, s: String) {
        val t = text(act, s, 13f, C.MUTED)
        t.pad(6, 10, 6, 0)
        col.addView(t, lp(-1, -2))
    }

    private fun card(col: LinearLayout): Card {
        val v = LinearLayout(act)
        v.orientation = LinearLayout.VERTICAL
        v.background = solid(act, C.SOFT, 20f)
        v.clipToOutline = true
        v.outlineProvider = ViewOutlineProvider.BACKGROUND
        col.addView(v, lp(-1, -2))
        return Card(v)
    }

    /** A rounded box of rows with thin lines between them. */
    private inner class Card(val view: LinearLayout) {
        private var count = 0

        fun clear() {
            view.removeAllViews()
            count = 0
        }

        fun add(v: View) {
            if (count++ > 0) {
                val d = View(act)
                d.setBackgroundColor(C.LINE)
                view.addView(d, lp(-1, maxOf(1, dp(1))).apply { leftMargin = dp(16) })
            }
            view.addView(v, lp(-1, -2))
        }

        fun row(
            title: String,
            sub: String? = null,
            trailing: View? = null,
            danger: Boolean = false,
            onClick: (() -> Unit)? = null
        ): View {
            val r = LinearLayout(act)
            r.gravity = Gravity.CENTER_VERTICAL
            r.pad(16, 12, 12, 12)
            r.minimumHeight = dp(58)
            if (onClick != null) {
                r.background = withRipple(null)
                r.setOnClickListener { onClick() }
            }
            val col = LinearLayout(act)
            col.orientation = LinearLayout.VERTICAL
            col.addView(text(act, title, 15.5f, if (danger) 0xFFD93025.toInt() else C.INK, false))
            if (!sub.isNullOrEmpty()) {
                col.addView(text(act, sub, 13f, C.MUTED), lp(-2, -2).apply { topMargin = dp(3) })
            }
            r.addView(col, LinearLayout.LayoutParams(0, -2, 1f))
            if (trailing != null) r.addView(trailing)
            add(r)
            return r
        }

        fun toggle(title: String, sub: String?, value: Boolean, onChange: (Boolean) -> Unit) {
            val sw = Switch(act)
            sw.isChecked = value
            sw.setOnCheckedChangeListener { _, v -> onChange(v) }
            row(title, sub, sw) { sw.toggle() }
        }

        fun radio(title: String, sub: String?, selected: Boolean, onClick: () -> Unit) {
            row(title, sub, radioMark(selected)) { onClick() }
        }

        fun choice(title: String, names: Array<String>, selected: Int, onPick: (Int) -> Unit) {
            var anchor: View? = null
            val r = row(title, names[selected.coerceIn(0, names.size - 1)], text(act, "›", 22f, C.MUTED)) {
                anchor?.let { showChoice(it, names, selected, onPick) }
            }
            anchor = r
        }
    }

    private fun radioMark(on: Boolean): View {
        val ring = FrameLayout(act)
        val bg = GradientDrawable()
        bg.shape = GradientDrawable.OVAL
        bg.setColor(Color.TRANSPARENT)
        bg.setStroke(dp(2), if (on) C.INK else C.MUTED)
        ring.background = bg
        if (on) {
            val dot = View(act)
            val d = GradientDrawable()
            d.shape = GradientDrawable.OVAL
            d.setColor(C.INK)
            dot.background = d
            ring.addView(dot, FrameLayout.LayoutParams(dp(10), dp(10), Gravity.CENTER))
        }
        ring.layoutParams = LinearLayout.LayoutParams(dp(22), dp(22))
        return ring
    }

    /** A small pop-up list, same look as the main menu. */
    private fun showChoice(anchor: View, names: Array<String>, selected: Int, onPick: (Int) -> Unit) {
        val panel = LinearLayout(act)
        panel.orientation = LinearLayout.VERTICAL
        panel.background = solid(act, C.WHITE, 18f)
        panel.pad(6, 6, 6, 6)
        val holder = arrayOfNulls<PopupWindow>(1)
        for (i in names.indices) {
            val row = LinearLayout(act)
            row.gravity = Gravity.CENTER_VERTICAL
            row.pad(14, 0, 14, 0)
            row.background = withRipple(null)
            row.addView(text(act, names[i], 15f, C.INK, selected == i), LinearLayout.LayoutParams(0, -2, 1f))
            if (selected == i) row.addView(text(act, "✓", 17f, C.INK, true))
            row.setOnClickListener {
                holder[0]?.dismiss()
                if (selected != i) onPick(i)
            }
            panel.addView(row, lp(-1, dp(46)))
        }
        val popup = PopupWindow(panel, dp(230), ViewGroup.LayoutParams.WRAP_CONTENT, true)
        popup.elevation = act.dpf(14f)
        popup.setBackgroundDrawable(null)
        popup.isOutsideTouchable = true
        holder[0] = popup
        popup.showAsDropDown(anchor, maxOf(0, anchor.width - dp(246)), -dp(16))
    }

    // ---- General ---------------------------------------------------------------------------

    private fun general(col: LinearLayout) {
        val engines = arrayOf("Google", "Brave Search", "DuckDuckGo")
        heading(col, "Search")
        card(col).apply {
            choice("Search engine", engines, prefs.searchEngine) { i ->
                prefs.searchEngine = i
                act.toast("Search engine: " + engines[i])
                render()
            }
            toggle("SafeSearch", "Applies to Google searches. Other search engines use their own setting.", prefs.safeSearch) {
                prefs.safeSearch = it
                act.toast(if (it) "SafeSearch on" else "SafeSearch off")
            }
        }
        heading(col, "Start page overview")
        card(col).apply {
            radio("Wikipedia overview", "Shows a short summary and pictures from Wikipedia under your search.", prefs.overview == 0) {
                prefs.overview = 0
                act.toast("Start page: Wikipedia overview")
                render()
            }
            radio("AI overview", "Adds an Ask Perplexity button. It opens perplexity.ai in a tab, using your own account and limits.", prefs.overview == 1) {
                prefs.overview = 1
                act.toast("Start page: AI overview")
                render()
            }
            radio("Off", "Just the search bar.", prefs.overview == 2) {
                prefs.overview = 2
                act.toast("Start page overview off")
                render()
            }
        }
        heading(col, "On startup and pages")
        card(col).apply {
            toggle("Restore tabs", "Open the pages you had open last time. Private tabs are never saved.", prefs.restoreTabs) {
                prefs.restoreTabs = it
                if (!it) prefs.session = ""
                act.toast(if (it) "Tabs will be restored" else "Tabs will not be restored")
            }
            toggle("Request desktop site", "Open new tabs the way a computer would see them.", prefs.desktop) {
                prefs.desktop = it
                act.toast(if (it) "New tabs open as desktop sites" else "New tabs open as mobile sites")
            }
        }
        heading(col, "Media and battery")
        card(col).apply {
            toggle("Background play", "Keep sound playing when the screen is off.", prefs.bgPlay) {
                prefs.bgPlay = it
                SiteBridge.bgPlay = it
                act.toast(if (it) "Background play on" else "Background play off")
            }
            row("Battery settings", "Let Android keep Liquid Air running in the background", text(act, "›", 22f, C.MUTED)) {
                act.openBatterySettings()
            }
        }
    }

    // ---- Themes ----------------------------------------------------------------------------

    private fun themes(col: LinearLayout) {
        heading(col, "Style")
        card(col).apply {
            val styles = listOf(
                Triple(0, "Liquid Glass", "Frosted glass pieces over the Liquid Air picture."),
                Triple(1, "Chrome + Perplexity", "Clean flat bars like Chrome, with Perplexity's soft paper colours and teal.")
            )
            for ((i, title, sub) in styles) {
                radio(title, sub, prefs.style == i) {
                    if (prefs.style != i) {
                        prefs.style = i
                        act.toast("Style: $title")
                        act.reTheme()
                    }
                }
            }
        }
        heading(col, "Theme")
        val box = LinearLayout(act)
        box.background = solid(act, C.SOFT, 20f)
        box.pad(10, 14, 10, 12)
        val names = arrayOf("System default", "Light", "Dark")
        for (i in names.indices) {
            box.addView(themeTile(i, names[i]), LinearLayout.LayoutParams(0, -2, 1f).apply {
                leftMargin = dp(6); rightMargin = dp(6)
            })
        }
        col.addView(box, lp(-1, -2))
        note(col, "System default follows your phone's light or dark setting. Web pages follow the theme too.")

        heading(col, "Page zoom")
        card(col).apply {
            val value = text(act, prefs.zoom.toString() + "%", 15f, C.INK, true)
            value.gravity = Gravity.CENTER
            fun step(label: String, by: Int): TextView {
                val b = text(act, label, 20f, C.INK, true)
                b.gravity = Gravity.CENTER
                b.background = solid(act, C.WHITE, 20f)
                b.setOnClickListener {
                    prefs.zoom = prefs.zoom + by
                    Engine.apply(prefs)
                    value.text = prefs.zoom.toString() + "%"
                }
                return b
            }
            val controls = LinearLayout(act)
            controls.gravity = Gravity.CENTER_VERTICAL
            controls.addView(step("−", -10), LinearLayout.LayoutParams(dp(40), dp(40)))
            controls.addView(value, LinearLayout.LayoutParams(dp(60), -2))
            controls.addView(step("+", 10), LinearLayout.LayoutParams(dp(40), dp(40)))
            row("Text and page size", "Makes pages larger or smaller", controls)
        }
    }

    /** A little picture of a window in the theme, with a blue ring around the chosen one. */
    private fun themeTile(index: Int, name: String): View {
        val on = prefs.theme == index
        val tile = LinearLayout(act)
        tile.orientation = LinearLayout.VERTICAL
        tile.gravity = Gravity.CENTER_HORIZONTAL

        val ringBox = FrameLayout(act)
        ringBox.background = if (on) skyRing(act, 18f) else null
        ringBox.pad(3, 3, 3, 3)
        val preview = FrameLayout(act)
        preview.background = solid(act, C.WHITE, 15f)
        preview.clipToOutline = true
        preview.outlineProvider = ViewOutlineProvider.BACKGROUND
        when (index) {
            1 -> preview.addView(miniWindow(0xFFF4F2E9.toInt(), 0xFFFFFFFF.toInt()), FrameLayout.LayoutParams(-1, -1))
            2 -> preview.addView(miniWindow(0xFF101412.toInt(), 0xFF343B38.toInt()), FrameLayout.LayoutParams(-1, -1))
            else -> {
                val halves = LinearLayout(act)
                halves.addView(miniWindow(0xFFF4F2E9.toInt(), 0xFFFFFFFF.toInt()), LinearLayout.LayoutParams(0, -1, 1f))
                halves.addView(miniWindow(0xFF101412.toInt(), 0xFF343B38.toInt()), LinearLayout.LayoutParams(0, -1, 1f))
                preview.addView(halves, FrameLayout.LayoutParams(-1, -1))
            }
        }
        ringBox.addView(preview, FrameLayout.LayoutParams(-1, -1))
        tile.addView(ringBox, lp(-1, dp(84)))

        val label = LinearLayout(act)
        label.gravity = Gravity.CENTER_VERTICAL
        label.addView(radioMark(on), LinearLayout.LayoutParams(dp(20), dp(20)).apply { rightMargin = dp(8) })
        label.addView(text(act, name, 14f, C.INK, on))
        tile.addView(label, lp(-2, -2).apply { topMargin = dp(10) })

        tile.setOnClickListener {
            if (prefs.theme != index) {
                prefs.theme = index
                act.toast("Theme: $name")
                act.reTheme()
            }
        }
        return tile
    }

    private fun miniWindow(bg: Int, bar: Int): View {
        val f = FrameLayout(act)
        f.setBackgroundColor(bg)
        val b = View(act)
        b.background = solid(act, bar, 6f)
        f.addView(b, FrameLayout.LayoutParams(-1, dp(14)).apply {
            topMargin = dp(10); leftMargin = dp(8); rightMargin = dp(8)
        })
        val line = View(act)
        line.background = solid(act, bar, 3f)
        f.addView(line, FrameLayout.LayoutParams(-1, dp(6)).apply {
            topMargin = dp(36); leftMargin = dp(8); rightMargin = dp(22)
        })
        return f
    }

    // ---- Privacy and security --------------------------------------------------------------

    private fun privacy(col: LinearLayout) {
        heading(col, "Cookies and site data")
        card(col).apply {
            val modes = listOf(
                Triple(0, "Allow all cookies", "Sites can remember you everywhere. Least private."),
                Triple(1, "Block cross-site tracking cookies (recommended)", "Stops cookies that follow you from site to site."),
                Triple(2, "Block all third-party cookies", "Cookies only work on the site you are on. Some sign-in buttons may stop working."),
                Triple(3, "Block all cookies", "Sites can't remember you at all. Most sites will not let you sign in.")
            )
            for ((mode, title, sub) in modes) {
                radio(title, sub, prefs.cookieMode == mode) {
                    prefs.cookieMode = mode
                    Engine.apply(prefs)
                    act.toast("Cookie setting saved")
                    render()
                }
            }
            toggle("Clear cookies and site data on exit", "Forgets them the next time Liquid Air starts.", prefs.clearOnExit) {
                prefs.clearOnExit = it
            }
            row("Clear browsing data", "History, cookies and cached files", text(act, "›", 22f, C.MUTED)) {
                showClearDialog()
            }
        }

        heading(col, "Ad and tracker blocker")
        card(col).apply {
            val n = String.format(Locale.US, "%,d", Urls.adHostCount())
            toggle(
                "Block ads and trackers",
                "Stops requests to $n known ad and tracker servers before they load, and blocks fingerprinting. " +
                    "It never changes a page's own layout. Off on YouTube and captcha pages.",
                prefs.adBlock
            ) {
                prefs.adBlock = it
                Engine.apply(prefs)
                act.toast(if (it) "Blocker on" else "Blocker off")
            }
        }

        heading(col, "Safe browsing and hacker protection")
        card(col).apply {
            toggle("Warn about dangerous sites", "Blocks phishing and malware pages before they open.", prefs.safeBrowsing) {
                prefs.safeBrowsing = it
                Engine.apply(prefs)
            }
            toggle("HTTPS-only mode", "Only opens sites over a secure connection. Sites without one will not load.", prefs.httpsOnly) {
                prefs.httpsOnly = it
                Engine.apply(prefs)
            }
            toggle("Block pop-ups and sneaky redirects", "Stops pages from opening windows you didn't ask for.", prefs.blockPopups) {
                prefs.blockPopups = it
            }
            toggle("Stop pages opening other apps", "A page can only open another app after you tap something.", prefs.blockExternal) {
                prefs.blockExternal = it
            }
            toggle("Remove tracking from links", "Strips utm_, fbclid, gclid and similar tags from addresses.", prefs.stripTracking) {
                prefs.stripTracking = it
            }
            toggle("Fingerprinting protection", "Makes it harder for sites to identify your device.", prefs.fingerprint) {
                prefs.fingerprint = it
                Engine.apply(prefs)
            }
            toggle("Warn before risky downloads", "Asks first about programs, scripts and files from insecure links.", prefs.warnDownloads) {
                prefs.warnDownloads = it
            }
            toggle("Send Global Privacy Control", "Tells sites not to sell or share your data.", prefs.gpc) {
                prefs.gpc = it
                Engine.apply(prefs)
            }
        }

        heading(col, "Site permissions")
        card(col).apply {
            toggle("Ask before using location", "Turn off to block every site from your location.", prefs.askLocation) {
                prefs.askLocation = it
            }
            toggle("Ask before using camera and microphone", "Turn off to block every site from both.", prefs.askMedia) {
                prefs.askMedia = it
            }
        }

        heading(col, "Private tabs")
        card(col).apply {
            toggle("Hide private tabs", "Keeps private tabs out of screenshots and the recent-apps view.", prefs.secureTabs) {
                prefs.secureTabs = it
                act.browser.active()?.let { t -> act.applyPrivacy(t) }
                act.toast(if (it) "Private tabs are hidden" else "Private tabs can be captured")
            }
        }
    }

    private fun showClearDialog() {
        var range = "all"
        var hist = true
        var cookies = true
        var cache = true
        val box = LinearLayout(act)
        box.orientation = LinearLayout.VERTICAL
        box.pad(20, 8, 20, 0)

        val chips = LinearLayout(act)
        fun drawChips() {
            chips.removeAllViews()
            for ((key, label) in listOf("hour" to "Last hour", "day" to "Today", "all" to "All time")) {
                val on = range == key
                val c = text(act, label, 13f, if (on) C.ON_INK else C.INK, true)
                c.gravity = Gravity.CENTER
                c.background = solid(act, if (on) C.INK else C.SOFT, 18f)
                c.setOnClickListener {
                    range = key
                    drawChips()
                }
                chips.addView(c, LinearLayout.LayoutParams(0, dp(36), 1f).apply { rightMargin = dp(8) })
            }
        }
        drawChips()
        box.addView(chips, lp(-1, -2).apply { bottomMargin = dp(6) })

        fun check(label: String, value: Boolean, set: (Boolean) -> Unit) {
            val cb = CheckBox(act)
            cb.text = label
            cb.isChecked = value
            cb.setOnCheckedChangeListener { _, v -> set(v) }
            box.addView(cb, lp(-1, dp(44)))
        }
        check("Browsing history", hist) { hist = it }
        check("Cookies and site data", cookies) { cookies = it }
        check("Cached images and files", cache) { cache = it }

        AlertDialog.Builder(act)
            .setTitle("Clear browsing data")
            .setView(box)
            .setPositiveButton("Delete data") { _, _ ->
                if (!hist && !cookies && !cache) {
                    act.toast("Choose what to delete.")
                } else {
                    if (hist) {
                        val now = System.currentTimeMillis()
                        val since = when (range) {
                            "hour" -> now - 3600000L
                            "day" -> now - (now % 86400000L)
                            else -> 0L
                        }
                        act.browser.clearHistory(since)
                    }
                    Engine.clearData(cookies, cache)
                    act.toast("Browsing data deleted.")
                }
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    // ---- Passwords -------------------------------------------------------------------------

    private fun passwords(col: LinearLayout) {
        val vault = act.vault
        heading(col, "Passwords")
        card(col).apply {
            toggle("Offer to save passwords", "Passwords are encrypted on this device with a key that never leaves it.", prefs.savePasswords) {
                prefs.savePasswords = it
            }
            row("Add password", "Save a sign-in by hand", text(act, "+", 22f, C.MUTED)) { showAddDialog() }
        }

        val total = vault.count()
        heading(col, "Saved passwords ($total)")
        if (total == 0) {
            note(col, "Sign-ins you save will appear here. You can also import them from Chrome or Brave in Import and export.")
        } else {
            val search = EditText(act)
            search.hint = "Search passwords"
            search.setHintTextColor(C.HINT)
            search.setTextColor(C.INK)
            search.textSize = 15f
            search.isSingleLine = true
            search.setText(passwordQuery)
            search.background = solid(act, C.SOFT, 24f)
            search.pad(20, 0, 20, 0)
            col.addView(search, lp(-1, dp(48)).apply { bottomMargin = dp(10) })
            val list = card(col)
            fillPasswords(list)
            search.addTextChangedListener(object : TextWatcher {
                override fun afterTextChanged(s: Editable?) {
                    passwordQuery = s?.toString()?.trim()?.lowercase(Locale.getDefault()).orEmpty()
                    fillPasswords(list)
                }

                override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
                override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            })
        }

        heading(col, "More")
        card(col).apply {
            val never = prefs.neverSave
            if (never.isNotEmpty()) {
                row("Sites that never save passwords", "${never.size} site(s). Tap to ask again.") {
                    prefs.neverSave = emptySet()
                    act.toast("Liquid Air will ask again")
                    render()
                }
            }
            if (total > 0) {
                row("Delete all passwords", "Removes every saved password from this device", null, true) {
                    AlertDialog.Builder(act)
                        .setTitle("Delete all passwords?")
                        .setMessage("This can't be undone. Export them first if you want a copy.")
                        .setPositiveButton("Delete") { _, _ ->
                            act.requireAuth("Delete all saved passwords") {
                                vault.deleteAll()
                                act.toast("Passwords deleted")
                                render()
                            }
                        }
                        .setNegativeButton("Cancel", null)
                        .show()
                }
            }
        }
    }

    private fun fillPasswords(list: Card) {
        list.clear()
        val q = passwordQuery
        val matches = act.vault.all().filter {
            q.isEmpty() || it.host.lowercase(Locale.getDefault()).contains(q) ||
                it.username.lowercase(Locale.getDefault()).contains(q)
        }
        if (matches.isEmpty()) {
            val t = text(act, "No passwords match.", 14f, C.MUTED)
            t.pad(16, 18, 16, 18)
            list.add(t)
            return
        }
        for (l in matches.take(150)) {
            list.row(l.host, if (l.username.isEmpty()) "(no username)" else l.username, text(act, "›", 22f, C.MUTED)) {
                showLoginDialog(l)
            }
        }
        if (matches.size > 150) {
            val t = text(act, "Showing the first 150. Search to find the others.", 13f, C.MUTED)
            t.pad(16, 14, 16, 14)
            list.add(t)
        }
    }

    private fun showLoginDialog(l: Login) {
        val box = LinearLayout(act)
        box.orientation = LinearLayout.VERTICAL
        box.pad(22, 8, 22, 0)

        fun label(s: String) {
            box.addView(text(act, s, 12f, C.MUTED, true), lp(-2, -2).apply { topMargin = dp(14) })
        }

        fun action(s: String, run: () -> Unit): TextView {
            val a = text(act, s, 14f, C.SKY_C, true)
            a.pad(12, 8, 4, 8)
            a.setOnClickListener { run() }
            return a
        }

        label("Website")
        box.addView(TextView(act).apply { text = l.origin; textSize = 16f })

        label("Username")
        val userRow = LinearLayout(act)
        userRow.gravity = Gravity.CENTER_VERTICAL
        userRow.addView(
            TextView(act).apply { text = if (l.username.isEmpty()) "(none)" else l.username; textSize = 16f },
            LinearLayout.LayoutParams(0, -2, 1f)
        )
        if (l.username.isNotEmpty()) userRow.addView(action("Copy") { copyText(l.username) })
        box.addView(userRow)

        label("Password")
        val dots = "••••••••••"
        val pw = TextView(act)
        pw.text = dots
        pw.textSize = 16f
        var shown = false
        val showBtn = action("Show") {}
        showBtn.setOnClickListener {
            if (shown) {
                shown = false
                pw.text = dots
                showBtn.text = "Show"
            } else {
                act.requireAuth("Show this saved password") {
                    shown = true
                    pw.text = l.password
                    showBtn.text = "Hide"
                }
            }
        }
        val pwRow = LinearLayout(act)
        pwRow.gravity = Gravity.CENTER_VERTICAL
        pwRow.addView(pw, LinearLayout.LayoutParams(0, -2, 1f))
        pwRow.addView(showBtn)
        pwRow.addView(action("Copy") { act.requireAuth("Copy this saved password") { copyText(l.password) } })
        box.addView(pwRow)

        AlertDialog.Builder(act)
            .setTitle(l.host)
            .setView(box)
            .setPositiveButton("Done", null)
            .setNeutralButton("Delete") { _, _ ->
                act.vault.delete(l.id)
                act.toast("Password deleted")
                render()
            }
            .show()
    }

    private fun showAddDialog() {
        val box = LinearLayout(act)
        box.orientation = LinearLayout.VERTICAL
        box.pad(22, 8, 22, 0)
        val site = EditText(act)
        site.hint = "Website, like example.com"
        site.isSingleLine = true
        site.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_URI
        val user = EditText(act)
        user.hint = "Username or email"
        user.isSingleLine = true
        user.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_EMAIL_ADDRESS
        val pass = EditText(act)
        pass.hint = "Password"
        pass.isSingleLine = true
        pass.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
        box.addView(site, lp(-1, -2))
        box.addView(user, lp(-1, -2))
        box.addView(pass, lp(-1, -2))
        AlertDialog.Builder(act)
            .setTitle("Add password")
            .setView(box)
            .setPositiveButton("Save") { _, _ ->
                val raw = site.text.toString().trim()
                val address = if (raw.contains("://")) raw else "https://$raw"
                val saved = raw.isNotEmpty() && act.vault.save(address, user.text.toString().trim(), pass.text.toString())
                act.toast(if (saved) "Password saved" else "Enter a website and a password.")
                if (saved) render()
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun copyText(value: String) {
        val cm = act.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        cm.setPrimaryClip(ClipData.newPlainText("copied", value))
        act.toast("Copied")
    }

    // ---- Downloads -------------------------------------------------------------------------

    private fun downloadsSection(col: LinearLayout) {
        heading(col, "Downloads")
        card(col).apply {
            row("Location", "Downloads folder on this device", text(act, "Downloads", 14f, C.MUTED))
            row("Open downloads", "See, search and open what you have downloaded", text(act, "›", 22f, C.MUTED)) {
                act.openTool("downloads")
            }
            row("Open the Android Downloads app", null, text(act, "›", 22f, C.MUTED)) {
                act.downloads.openSystemDownloads()
            }
            row("Clear download list", "Takes everything off the list. The files stay on your device.") {
                act.downloads.clearList()
                act.toast("Download list cleared")
            }
        }
        heading(col, "Safety")
        card(col).apply {
            row("Download safety checks", "Warnings for programs and insecure links are in Privacy and security", text(act, "›", 22f, C.MUTED)) {
                act.settingsSection = "privacy"
                render()
            }
        }
    }

    // ---- Import and export -----------------------------------------------------------------

    private fun data(col: LinearLayout) {
        heading(col, "Bookmarks")
        card(col).apply {
            row("Import bookmarks", "From a Chrome, Brave, Edge or Firefox .html file", text(act, "›", 22f, C.MUTED)) {
                act.pickDocument { uri -> importBookmarks(uri) }
            }
            row("Export bookmarks", "${act.browser.bookmarks.size} bookmarks, saved as an .html file", text(act, "›", 22f, C.MUTED)) {
                act.createDocument("liquid-air-bookmarks.html", "text/html") { uri ->
                    val ok = writeText(uri, BookmarkIo.toHtml(act.browser.bookmarks.toList()))
                    act.toast(if (ok) "Bookmarks exported" else "Couldn't save the file.")
                }
            }
        }
        heading(col, "Passwords")
        card(col).apply {
            row("Import passwords", "From a .csv file (Chrome, Brave, Edge, Firefox, Bitwarden)", text(act, "›", 22f, C.MUTED)) {
                act.pickDocument { uri -> importPasswords(uri) }
            }
            row("Export passwords", "${act.vault.count()} saved. The file is not encrypted.", text(act, "›", 22f, C.MUTED)) {
                exportPasswords()
            }
        }
        note(col, "These files use the same formats as Chrome and Brave, so you can move your data in or out of Liquid Air. Delete a passwords file as soon as you are done with it.")
    }

    private fun importBookmarks(uri: Uri) {
        val text = readText(uri)
        if (text == null) {
            act.toast("Couldn't read that file.")
            return
        }
        val have = act.browser.bookmarks.map { it.url }.toHashSet()
        val fresh = BookmarkIo.parse(text).filter { have.add(it.url) }
        if (fresh.isEmpty()) {
            act.toast("No new bookmarks found in that file.")
            return
        }
        act.browser.bookmarks.addAll(fresh)
        act.browser.saveBookmarks()
        act.toast("Imported ${fresh.size} bookmarks")
        render()
    }

    private fun importPasswords(uri: Uri) {
        val text = readText(uri)
        if (text == null) {
            act.toast("Couldn't read that file.")
            return
        }
        val added = act.vault.importCsv(text)
        act.toast(if (added > 0) "Imported $added passwords" else "No new passwords found in that file.")
        render()
    }

    private fun exportPasswords() {
        if (act.vault.count() == 0) {
            act.toast("There are no saved passwords to export.")
            return
        }
        AlertDialog.Builder(act)
            .setTitle("Export passwords?")
            .setMessage(
                "The file will hold your passwords as plain text. Anyone who can open it can read them. " +
                    "Keep it somewhere safe and delete it when you are done."
            )
            .setPositiveButton("Continue") { _, _ ->
                act.requireAuth("Export your saved passwords") {
                    act.createDocument("liquid-air-passwords.csv", "text/csv") { uri ->
                        val ok = writeText(uri, act.vault.toCsv())
                        act.toast(if (ok) "Passwords exported" else "Couldn't save the file.")
                    }
                }
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun readText(uri: Uri): String? {
        return try {
            act.contentResolver.openInputStream(uri)?.use { s ->
                val bytes = s.readBytes()
                if (bytes.size > 25000000) null else String(bytes, Charsets.UTF_8)
            }
        } catch (e: Exception) {
            null
        }
    }

    private fun writeText(uri: Uri, text: String): Boolean {
        return try {
            val out = act.contentResolver.openOutputStream(uri, "wt") ?: return false
            out.use { it.write(text.toByteArray(Charsets.UTF_8)) }
            true
        } catch (e: Exception) {
            false
        }
    }

    // ---- About -----------------------------------------------------------------------------

    private fun about(col: LinearLayout) {
        heading(col, "About")
        card(col).apply {
            row("Liquid Air 2.0", "Engine: GeckoView (the Firefox engine)")
            row(
                "Ad and tracker lists",
                "Built from EasyList and EasyPrivacy (CC BY-SA 3.0 / GPLv3) plus a short hand-picked list. " +
                    String.format(Locale.US, "%,d", Urls.adHostCount()) + " servers blocked."
            )
        }
    }
}
