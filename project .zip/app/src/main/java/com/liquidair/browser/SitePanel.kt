package com.liquidair.browser

import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.PopupWindow
import android.widget.ScrollView
import android.widget.Switch
import android.widget.TextView

/**
 * The wrench next to the address bar. It opens a Shields-style panel under the icon: whether the
 * connection is secure, how many ads and trackers were stopped on this page, and the controls for
 * this site (shields, scripts, cookies, location, camera). The card is frosted glass.
 */
class SitePanel(private val act: MainActivity) {

    private var popup: PopupWindow? = null
    private var advanced = false

    fun toggle(tab: Tab, anchor: View) {
        if (popup != null) {
            close()
            return
        }
        if (tab.home || !Urls.isWeb(tab.url)) {
            act.toast("Open a website to see its status")
            return
        }
        show(tab, anchor)
    }

    fun close() {
        popup?.dismiss()
        popup = null
    }

    private fun dp(v: Int) = act.dp(v)

    private fun show(tab: Tab, anchor: View) {
        val host = Urls.hostOf(tab.url)
        val column = LinearLayout(act)
        column.orientation = LinearLayout.VERTICAL

        val scroller = ScrollView(act)
        scroller.isVerticalScrollBarEnabled = false
        scroller.background = GradientDrawable().apply {
            cornerRadius = act.dpf(24f)
            // Frosted glass: a milky translucent fill with a bright hairline edge.
            setColor(if (C.dark) 0xD9262B29.toInt() else 0xCCFFFFFF.toInt())
            setStroke(dp(1), if (C.dark) 0x40FFFFFF else 0xE6FFFFFF.toInt())
        }
        scroller.clipToOutline = true
        scroller.addView(column, ViewGroup.LayoutParams(-1, -2))

        val metrics = act.resources.displayMetrics
        val panelW = minOf(dp(380), metrics.widthPixels - dp(16))
        val maxH = metrics.heightPixels - dp(150)

        val pop = PopupWindow(scroller, panelW, ViewGroup.LayoutParams.WRAP_CONTENT, true)
        pop.elevation = act.dpf(14f)
        pop.setBackgroundDrawable(null)
        pop.isOutsideTouchable = true
        pop.setOnDismissListener { popup = null }

        fun render() {
            column.removeAllViews()
            fill(column, tab, host) { render() }
            column.measure(
                View.MeasureSpec.makeMeasureSpec(panelW, View.MeasureSpec.EXACTLY),
                View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED)
            )
            if (pop.isShowing) pop.update(panelW, minOf(column.measuredHeight, maxH))
        }
        column.removeAllViews()
        fill(column, tab, host) { render() }
        column.measure(
            View.MeasureSpec.makeMeasureSpec(panelW, View.MeasureSpec.EXACTLY),
            View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED)
        )
        pop.height = minOf(column.measuredHeight, maxH)

        popup = pop
        pop.showAsDropDown(anchor, -dp(6), dp(14))
        scroller.pivotX = 0f
        scroller.pivotY = 0f
        scroller.arrive(0f, -5f, .98f, 160)
    }

    // ---- contents -------------------------------------------------------

    private fun fill(col: LinearLayout, tab: Tab, host: String, redraw: () -> Unit) {
        val secure = tab.url.startsWith("https://", true)
        val globalOn = act.prefs.adBlock
        val shieldsUp = globalOn && Sites.ads(host)
        col.pad(18, 16, 18, 14)

        // ---- header: site name, status line, and the master Shields switch ----
        val header = LinearLayout(act)
        header.gravity = Gravity.CENTER_VERTICAL
        val names = LinearLayout(act)
        names.orientation = LinearLayout.VERTICAL
        names.addView(oneLine(text(act, host.removePrefix("www.").ifEmpty { tab.url }, 19f, C.INK, true)))
        names.addView(
            text(
                act,
                if (shieldsUp) "Shields are UP for this site" else "Shields are DOWN for this site",
                13.5f,
                if (shieldsUp) 0xFF2E7D4F.toInt() else C.MUTED
            ),
            LinearLayout.LayoutParams(-2, -2).apply { topMargin = dp(2) }
        )
        header.addView(names, LinearLayout.LayoutParams(0, -2, 1f))
        header.addView(
            switchView(shieldsUp) { on ->
                if (on && !act.prefs.adBlock) {
                    act.prefs.adBlock = true
                    Engine.apply(act.prefs)
                }
                Sites.setAds(host, on)
                tab.session.settings.useTrackingProtection = act.prefs.adBlock && on
                reload(tab)
                redraw()
            }
        )
        col.addView(header)

        // ---- stats ----
        val stats = LinearLayout(act)
        val total = tab.blocked + SiteBridge.blockedFor(host)
        stats.addView(tile(if (shieldsUp) total.toString() else "-", "Trackers & ads blocked"), LinearLayout.LayoutParams(0, -2, 1f))
        stats.addView(
            tile(if (secure) "Secure" else "Not secure", "Connection"),
            LinearLayout.LayoutParams(0, -2, 1f).apply { leftMargin = dp(10) }
        )
        col.addView(stats, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(14) })

        // ---- advanced view ----
        val link = text(act, if (advanced) "Simple view  ▴" else "Advanced view  ▾", 14.5f, C.SKY_C, true)
        link.pad(2, 12, 2, 8)
        link.setOnClickListener {
            advanced = !advanced
            redraw()
        }
        col.addView(link, LinearLayout.LayoutParams(-2, -2).apply { topMargin = dp(6) })
        if (!advanced) return

        val prefs = act.prefs
        col.addView(
            choiceRow("Trackers & ads blocking", null, arrayOf("Standard", "Allow"), if (Sites.ads(host)) 0 else 1) { v ->
                Sites.setAds(host, v == 0)
                tab.session.settings.useTrackingProtection = act.prefs.adBlock && v == 0
                reload(tab)
                redraw()
            }
        )
        col.addView(
            switchRow("Upgrade connections to HTTPS", "All sites", prefs.httpsOnly) { on ->
                prefs.httpsOnly = on
                Engine.apply(prefs)
            }
        )
        col.addView(
            switchRow("Block scripts", null, !Sites.js(host)) { on ->
                Sites.setJs(host, !on)
                reload(tab)
            }
        )
        val cookieNames = arrayOf("Allow all", "Block cross-site", "Block third-party", "Block all")
        col.addView(
            choiceRow("Cookies", "All sites", cookieNames, prefs.cookieMode) { v ->
                prefs.cookieMode = v
                Engine.apply(prefs)
            }
        )
        col.addView(
            switchRow("Block fingerprinting", "All sites", prefs.fingerprint) { on ->
                prefs.fingerprint = on
                Engine.apply(prefs)
            }
        )

        col.addView(sectionLabel("Permissions"))
        val perm = arrayOf("Ask", "Allow", "Block")
        col.addView(choiceRow("Location", null, perm, Sites.location(host)) { Sites.setLocation(host, it) })
        col.addView(choiceRow("Camera and microphone", null, perm, Sites.media(host)) { Sites.setMedia(host, it) })

        val foot = LinearLayout(act)
        foot.gravity = Gravity.CENTER_VERTICAL
        val reset = text(act, "Reset to defaults", 14.5f, C.SKY_C, true)
        reset.pad(2, 12, 12, 8)
        reset.setOnClickListener {
            Sites.reset(host)
            tab.session.settings.useTrackingProtection = act.prefs.adBlock
            reload(tab)
            redraw()
        }
        foot.addView(reset)
        val more = text(act, "Privacy settings", 14.5f, C.SKY_C, true)
        more.pad(12, 12, 2, 8)
        more.setOnClickListener {
            close()
            act.openSettings("privacy")
        }
        foot.addView(more)
        col.addView(foot, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(4) })
    }

    /** Ads and script switches apply to the next load, so the page reloads. */
    private fun reload(tab: Tab) {
        try {
            if (!tab.home && tab.session.isOpen) tab.session.reload()
        } catch (e: Exception) {
            // The page picks the change up the next time it opens.
        }
    }

    // ---- small pieces ---------------------------------------------------

    private fun sectionLabel(s: String): TextView {
        val t = text(act, s, 13f, C.MUTED, true)
        t.pad(2, 14, 0, 4)
        return t
    }

    private fun tile(big: String, small: String): LinearLayout {
        val t = LinearLayout(act)
        t.orientation = LinearLayout.VERTICAL
        t.background = solid(act, if (C.dark) 0x26FFFFFF else 0x80FFFFFF.toInt(), 16f)
        t.pad(14, 11, 14, 11)
        t.addView(oneLine(text(act, big, 24f, C.INK, true)))
        t.addView(oneLine(text(act, small, 12.5f, C.MUTED)))
        return t
    }

    private fun switchView(on: Boolean, change: (Boolean) -> Unit): Switch {
        val sw = Switch(act)
        sw.isChecked = on
        val states = arrayOf(intArrayOf(android.R.attr.state_checked), intArrayOf())
        sw.trackTintList = ColorStateList(states, intArrayOf(C.SKY_C, 0x66808080))
        sw.thumbTintList = ColorStateList(states, intArrayOf(Color.WHITE, 0xFFF2F2F2.toInt()))
        sw.setOnCheckedChangeListener { _, checked -> change(checked) }
        return sw
    }

    private fun labels(title: String, sub: String?): LinearLayout {
        val l = LinearLayout(act)
        l.orientation = LinearLayout.VERTICAL
        l.addView(text(act, title, 15.5f, C.INK))
        if (sub != null) l.addView(text(act, sub, 12.5f, C.MUTED))
        return l
    }

    private fun switchRow(title: String, sub: String?, on: Boolean, change: (Boolean) -> Unit): LinearLayout {
        val row = LinearLayout(act)
        row.gravity = Gravity.CENTER_VERTICAL
        row.minimumHeight = dp(50)
        row.addView(labels(title, sub), LinearLayout.LayoutParams(0, -2, 1f))
        row.addView(switchView(on, change))
        return row
    }

    /** A row whose value cycles through [options] when tapped. */
    private fun choiceRow(
        title: String,
        sub: String?,
        options: Array<String>,
        start: Int,
        change: (Int) -> Unit
    ): LinearLayout {
        var value = start.coerceIn(0, options.size - 1)
        val row = LinearLayout(act)
        row.gravity = Gravity.CENTER_VERTICAL
        row.minimumHeight = dp(50)
        row.background = withRipple(null)
        row.addView(labels(title, sub), LinearLayout.LayoutParams(0, -2, 1f))
        val chip = text(act, options[value], 14f, C.INK, true)
        chip.gravity = Gravity.CENTER
        chip.background = solid(act, if (C.dark) 0x26FFFFFF else 0x80FFFFFF.toInt(), 16f)
        chip.pad(14, 0, 14, 0)
        row.addView(chip, LinearLayout.LayoutParams(-2, dp(34)))
        row.setOnClickListener {
            value = (value + 1) % options.size
            chip.text = options[value]
            change(value)
        }
        return row
    }
}
