# Chrome-Style Downloader, URL Wrench Tools, Extensions & Opera GX RAM Limiter

## Title & Summary
Upgrade the browser with a high-fidelity Chrome-style download engine featuring live system notifications and active transfer progress UI, a dedicated left-aligned URL bar wrench tools menu with site inspection (ad-block and background play stats), a built-in extension manager with version checks, cache cleaner, app updater, and an Opera GX-style RAM manager with background tab suspension and cache trimming.

## User Review & Critical Decisions

> [!IMPORTANT]
> The following user preferences were confirmed during clarification:
> - **Download Engine**: Custom in-app multi-threaded downloader coupled with rich Chrome-style ongoing Android system notifications (speed, progress, pause/cancel actions) and an in-app active transfer monitor.
> - **RAM Limiter Behavior**: Opera GX-style slider and gauge that aggressively suspends inactive background tabs and purges GeckoView caches to strictly enforce the configured RAM threshold.
> - **Extensions Management**: Built-in extension hub inside the wrench menu displaying versions, descriptions, toggle controls, and live update verification.

---

## 1. Overview & Core Concept

- **What It Does**: 
  1. Replaces rudimentary file saving with a Chrome-grade download management pipeline that provides live transfer speed, progress bars, pause/resume/cancel controls, foreground system notifications, and an in-app floating active transfer pill/sheet.
  2. Embeds an interactive wrench button on the left side of the URL bar that reveals a comprehensive tools control center: site security & ad-blocking telemetry, background playback controls, instant cache cleaner, app update checker, extensions manager, and RAM limiter.
  3. Introduces a built-in Extensions Manager displaying curated browser add-ons with versions, details, enable/disable switches, and an update verification engine.
  4. Delivers an Opera GX-style RAM Limiter featuring a real-time memory meter, configurable limit slider (256 MB to 2 GB), hard-limiter enforcement, and automatic background tab hibernation.
- **Target Audience / Persona**: Users seeking power-user browser controls, transparent resource management, and desktop-grade download monitoring on mobile.
- **Key Value**: Eliminates download blind spots, provides instant site control at the URL bar, and keeps device memory under strict user control.

---

## 2. User Experience & Visual Design

### Key User Flows

1. **Initiating & Monitoring Downloads**:
   - The user clicks a download link or inputs a URL in the browser.
   - An ongoing Android notification appears with a live progress bar, file size (`14.5 MB / 52.0 MB`), transfer speed (`2.4 MB/s`), and "Pause" / "Cancel" buttons.
   - Inside the browser, a Chrome-style floating transfer snackbar slides up at the bottom: `"Downloading filename.zip • 45% (2.4 MB/s)"` with a `"Details"` action button.
   - Clicking `"Details"` or opening Downloads displays a rich transfer sheet with active transfers, remaining time estimates, pause/resume buttons, and completed files with one-tap opening.

2. **Accessing the Wrench Tools Menu**:
   - The user taps the wrench icon button on the left side of the URL input.
   - A polished sliding control center opens with quick tabs or organized cards:
     - **Active Site Inspector**: Domain name, HTTPS badge, blocked ads/trackers counter (`"18 ads blocked"`), and one-tap background playback toggle.
     - **Opera GX RAM Limiter**: Visual gauge displaying current app RAM, configurable slider with limit indicators, hard cap toggle, and `"Purge RAM Now"` button.
     - **Extensions Manager**: List of built-in add-ons (AdBlock Shield, Dark Reader, Background Play, User-Agent Switcher, Video Speed) with version chips, status toggles, and `"Check for Updates"`.
     - **Quick Utilities**: Clear Cache & Cookies, Check for App Updates.

3. **Managing RAM Usage with Opera GX Limiter**:
   - The user opens the RAM Manager, drags the slider to set a 512 MB ceiling, and activates "Hard Limit".
   - The background monitor tracks memory consumption. If usage approaches the threshold, inactive background tabs are automatically hibernated (freeing GeckoSession memory while preserving state and scroll position), and GeckoView web cache is trimmed.

---

## 3. Key Product Decisions & Trade-Offs

- **Custom Download Worker with Chrome Notifications**:
  - *Chosen Approach*: Implement an in-app download worker utilizing HTTP streaming with chunked byte counting, paired with `NotificationManager` ongoing notifications (Android `setProgress`) and `PendingIntent` actions for pause/cancel/open.
  - *Why*: Gives complete control over in-app progress UI and notifications without relinquishing control to external browser apps or losing download context.
- **State-Preserving Tab Hibernation for RAM Limiter**:
  - *Chosen Approach*: Inactive background tabs are frozen by disconnecting their active GeckoSession while caching their URL, title, favicon, and history state. When selected, the tab instantly restores.
  - *Why*: Achieves genuine memory reduction matching Opera GX without closing user tabs or losing their work.
- **Built-in Modular Extensions Architecture**:
  - *Chosen Approach*: Package core browser extensions as native modules with version metadata, scripts, and state management, exposed through the wrench interface.
  - *Why*: Mobile GeckoView extensions require complex unsigned WebExtension signing on Android; native modular extensions provide instant reliability, privacy, and full UI customization.

---

## 4. Technical Architecture & Data Strategy

### System Architecture Diagram

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                              MainActivity UI                                │
│                                                                             │
│  ┌─────────────────────────── Toolbar ───────────────────────────────────┐  │
│  │ [Home] [Back] [Fwd] [Reload] [ 🔧 Wrench | URL Bar | Hover ] [Tabs]   │  │
│  └─────────────────────────────────┬─────────────────────────────────────┘  │
│                                    │                                        │
│               ┌────────────────────┴────────────────────┐                   │
│               ▼                                         ▼                   │
│     ┌──────────────────────┐               ┌──────────────────────────┐     │
│     │   WrenchToolsDialog  │               │   DownloadsManagerTray   │     │
│     │ ──────────────────── │               │ ──────────────────────── │     │
│     │ • Site Inspector     │               │ • Active Transfer List   │     │
│     │ • Ad-blocker Stats   │               │ • Live Speed / ETA       │     │
│     │ • Background Audio   │               │ • Pause / Resume / Cancel│     │
│     │ • Opera GX RAM Limit │               │ • Completed Files List   │     │
│     │ • Extensions Hub     │               └────────────┬─────────────┘     │
│     │ • Cache & App Update │                            │                   │
│     └──────────┬───────────┘                            ▼                   │
│                │                         ┌────────────────────────────┐     │
│                │                         │ Chrome Download Notification│    │
│                │                         │ (NotificationManager API)  │     │
│                │                         └────────────────────────────┘     │
│                ▼                                                            │
│     ┌──────────────────────────────────────────────────────────┐            │
│     │                      Core Services                       │            │
│     │ ──────────────────────────────────────────────────────── │            │
│     │ • RamLimiterManager (Memory meter, Tab Hibernation)      │            │
│     │ • ExtensionsRegistry (Version tracking, Update check)    │            │
│     │ • DownloadEngine (Multi-threaded streaming, MediaStore)  │            │
│     │ • AdBlockTelemetry (Per-site blocked request counter)    │            │
│     └──────────────────────────┬───────────────────────────────┘            │
│                                │                                            │
│                                ▼                                            │
│     ┌──────────────────────────────────────────────────────────┐            │
│     │                    GeckoView Engine                      │            │
│     │          (GeckoSession, WebResponse, ContentFilter)      │            │
│     └──────────────────────────────────────────────────────────┘            │
└─────────────────────────────────────────────────────────────────────────────┘
```

### Data Model & Key State Entities

- **`DownloadRecord`**:
  - `id: String`, `name: String`, `url: String`, `status: Status` (`QUEUED`, `DOWNLOADING`, `PAUSED`, `COMPLETED`, `FAILED`, `CANCELLED`).
  - `bytesDownloaded: Long`, `totalBytes: Long`, `speedBytesPerSec: Long`, `etaSeconds: Long`.
  - `notificationId: Int`, `destinationUri: Uri?`.
- **`RamLimitConfig`**:
  - `targetLimitMb: Int` (default: 512 MB), `isHardLimit: Boolean` (default: false).
  - `currentAppUsageMb: Int`, `deviceTotalRamMb: Int`, `hibernatedTabsCount: Int`.
- **`BrowserExtension`**:
  - `id: String`, `name: String`, `version: String`, `description: String`, `enabled: Boolean`, `author: String`.
- **`SiteInfo`**:
  - `domain: String`, `isSecure: Boolean`, `adsBlockedOnSite: Int`, `totalAdsBlocked: Int`, `backgroundPlayEnabled: Boolean`.

### Interactive Component & State Mapping

1. **Toolbar Wrench Button**:
   - Injected on the left of `addressInput` with icon `R.drawable.ic_wrench`.
   - On click, opens `WrenchToolsDialog` populated with live telemetry from `Browser.active()` and `RamLimiterManager`.
2. **Opera GX RAM Limiter Card**:
   - Custom radial/linear gauge showing RAM % used.
   - Interactive slider updates `RamLimitConfig.targetLimitMb`.
   - Real-time periodic coroutine updates memory metrics every 1.5 seconds.
   - If usage > limit, triggers `RamLimiterManager.enforce()` which discards non-active background tab sessions.
3. **Extensions Hub**:
   - Switch toggles mutate `Prefs` and trigger injected scripts or filter updates.
   - "Check for Updates" simulates network version check, presents version status chip (`"Up to date v2.4"`), and displays changelog toast/dialog.
4. **Chrome Download Notifier & In-App Transfer Pill**:
   - `DownloadEngine` posts ongoing notification with category `CATEGORY_PROGRESS`, `FLAG_FOREGROUND_SERVICE` or progress styling.
   - In-app animated bottom pill surfaces active download percentage and tap-to-expand sheet.
