package com.liquidair.browser

import java.net.URI
import java.net.URLDecoder
import java.net.URLEncoder
import java.util.Locale

/** Address handling that has no Android dependencies, so it can be tested on its own. */
object Urls {
    private val SCHEME = Regex("^[a-zA-Z][a-zA-Z0-9+.-]*:.*")
    private val DOMAIN = Regex("^([a-z0-9-]+\\.)+[a-z]{2,}(:\\d+)?([/?#].*)?$", RegexOption.IGNORE_CASE)
    private val LOCAL = Regex("^(localhost|\\d{1,3}(\\.\\d{1,3}){3})(:\\d+)?([/?#].*)?$", RegexOption.IGNORE_CASE)

    private val GOOGLE_HOST = Regex("^(www\\.)?google\\.(com|co\\.[a-z]{2}|com\\.[a-z]{2}|[a-z]{2,3})$")

    /** Sites where tracker blocking must stay off (strictly verification captchas). */
    private val NO_BLOCK_HOSTS = listOf(
        "hcaptcha.com", "recaptcha.net", "arkoselabs.com", "funcaptcha.com"
    )

    fun hostOf(url: String): String {
        return try {
            (URI(url).host ?: "").lowercase(Locale.US).removePrefix("www.")
        } catch (e: Exception) {
            ""
        }
    }

    /** Turn what the user typed into an address. */
    fun resolveInput(text: String, safeSearch: Boolean, engine: Int = 0): String {
        val t = text.trim()
        if (t.isEmpty()) return t
        if (t.startsWith("about:", true)) return t
        if (SCHEME.matches(t) && t.contains("://")) {
            return if (t.startsWith("http", true)) applySafeSearch(t, safeSearch) else t
        }
        if (!t.contains(' ')) {
            if (LOCAL.matches(t)) return "http://$t"
            if (DOMAIN.matches(t)) return applySafeSearch("https://$t", safeSearch)
        }
        val query = URLEncoder.encode(t, "UTF-8")
        if (engine == 1) return "https://search.brave.com/search?q=$query"
        if (engine == 2) return "https://duckduckgo.com/?q=$query"
        return applySafeSearch("https://www.google.com/search?q=$query", safeSearch)
    }

    fun isGoogleSearch(url: String): Boolean {
        return try {
            val u = URI(url)
            val host = (u.host ?: "").lowercase(Locale.US)
            val google = GOOGLE_HOST.matches(host)
            google && u.path == "/search"
        } catch (e: Exception) {
            false
        }
    }

    /** SafeSearch on: safe=active. SafeSearch off: safe=off. Only on Google search pages. */
    fun applySafeSearch(url: String, on: Boolean): String {
        if (!isGoogleSearch(url)) return url
        var hash = ""
        var base = url
        val at = base.indexOf('#')
        if (at >= 0) {
            hash = base.substring(at)
            base = base.substring(0, at)
        }
        val q = base.indexOf('?')
        var path = base
        val kept = ArrayList<String>()
        if (q >= 0) {
            path = base.substring(0, q)
            for (part in base.substring(q + 1).split("&")) {
                if (part.isEmpty() || part == "safe" || part.startsWith("safe=")) continue
                kept.add(part)
            }
        }
        kept.add(if (on) "safe=active" else "safe=off")
        val rebuilt = path + (if (kept.isEmpty()) "" else "?" + kept.joinToString("&"))
        return rebuilt + hash
    }

    /** The words searched for, when this is a Google results page. */
    fun isBraveSearch(url: String): Boolean {
        return try {
            val u = URI(url)
            (u.host ?: "").lowercase(Locale.US) == "search.brave.com" && u.path == "/search"
        } catch (e: Exception) {
            false
        }
    }

    fun isDuckSearch(url: String): Boolean {
        return try {
            val u = URI(url)
            (u.host ?: "").lowercase(Locale.US) == "duckduckgo.com" && (u.query ?: "").contains("q=")
        } catch (e: Exception) {
            false
        }
    }

    fun searchQuery(url: String): String? {
        if (!isGoogleSearch(url) && !isBraveSearch(url) && !isDuckSearch(url)) return null
        val q = url.indexOf('?')
        if (q < 0) return null
        for (part in url.substring(q + 1).substringBefore('#').split("&")) {
            if (part.startsWith("q=")) {
                return try {
                    URLDecoder.decode(part.substring(2), "UTF-8")
                } catch (e: Exception) {
                    part.substring(2)
                }
            }
        }
        return null
    }

    /** True for pages where tracker/ad blocking must stay off. */
    fun blockerOffFor(url: String): Boolean {
        val host = hostOf(url)
        if (host.isEmpty()) return false
        if (host.contains("captcha") || host.contains("challenge")) return true
        if (url.contains("/recaptcha/") || url.contains("/cdn-cgi/challenge")) return true
        for (h in NO_BLOCK_HOSTS) {
            if (host == h || host.endsWith(".$h")) return true
        }
        return false
    }

    /** Short text for the address bar when it is not being edited. */
    fun display(url: String): String {
        if (url.isEmpty() || url == "about:blank") return ""
        searchQuery(url)?.let { return it }
        var s = url.removePrefix("https://").removePrefix("http://").removePrefix("www.")
        if (s.endsWith("/") && s.indexOf('/') == s.length - 1) s = s.dropLast(1)
        return s
    }

    fun isWeb(url: String): Boolean {
        return url.startsWith("http://", true) || url.startsWith("https://", true)
    }
}
