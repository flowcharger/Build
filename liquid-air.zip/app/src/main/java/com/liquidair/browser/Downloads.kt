package com.liquidair.browser

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import androidx.core.app.NotificationCompat
import androidx.core.content.FileProvider
import org.mozilla.geckoview.WebResponse
import java.io.File
import java.io.FileOutputStream
import java.io.InputStream
import java.io.OutputStream
import java.net.HttpURLConnection
import java.net.URL
import java.util.UUID

enum class DownloadStatus {
    DOWNLOADING, PAUSED, DONE, FAILED, CANCELLED
}

class DownloadItem(
    val id: String = UUID.randomUUID().toString(),
    var name: String,
    val url: String,
    val notificationId: Int = (System.currentTimeMillis() % 100000).toInt()
) {
    var statusText: String = "Downloading…"
    var state: DownloadStatus = DownloadStatus.DOWNLOADING
    var bytesDownloaded: Long = 0L
    var totalBytes: Long = -1L
    var speedBytesPerSec: Long = 0L
    var etaSeconds: Long = -1L
    var uri: Uri? = null
    var mime: String? = null
    var localPath: String? = null
    val startTime: Long = System.currentTimeMillis()

    @Volatile
    var isPaused: Boolean = false

    @Volatile
    var isCancelled: Boolean = false

    var workerThread: Thread? = null

    val progressPercent: Int
        get() = if (totalBytes > 0) ((bytesDownloaded * 100) / totalBytes).toInt().coerceIn(0, 100) else 0

    val speedLabel: String
        get() = Downloads.formatSpeed(speedBytesPerSec)

    val sizeLabel: String
        get() = if (totalBytes > 0) {
            "${Downloads.formatSize(bytesDownloaded)} / ${Downloads.formatSize(totalBytes)}"
        } else {
            Downloads.formatSize(bytesDownloaded)
        }

    val etaLabel: String
        get() = if (etaSeconds > 0) Downloads.formatEta(etaSeconds) else ""
}

/**
 * Chrome-style download manager with live transfer rate tracking,
 * system notifications with progress bar, pause/resume/cancel controls,
 * and direct file viewing.
 */
class Downloads(val act: MainActivity) {
    val items = ArrayList<DownloadItem>()
    private val notificationManager =
        act.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager

    companion object {
        const val CHANNEL_ID = "liquid_air_downloads_channel"
        const val CHANNEL_NAME = "Downloads"
        const val ACTION_CANCEL_DOWNLOAD = "com.liquidair.browser.ACTION_CANCEL_DOWNLOAD"
        const val ACTION_PAUSE_RESUME_DOWNLOAD = "com.liquidair.browser.ACTION_PAUSE_RESUME_DOWNLOAD"
        const val EXTRA_DOWNLOAD_ID = "extra_download_id"

        fun formatSize(bytes: Long): String {
            if (bytes <= 0) return "0 B"
            val kb = bytes / 1024.0
            val mb = kb / 1024.0
            val gb = mb / 1024.0
            return when {
                gb >= 1.0 -> String.format(java.util.Locale.US, "%.1f GB", gb)
                mb >= 1.0 -> String.format(java.util.Locale.US, "%.1f MB", mb)
                kb >= 1.0 -> String.format(java.util.Locale.US, "%.0f KB", kb)
                else -> "$bytes B"
            }
        }

        fun formatSpeed(bytesPerSec: Long): String {
            if (bytesPerSec <= 0) return "0 KB/s"
            val kb = bytesPerSec / 1024.0
            val mb = kb / 1024.0
            return when {
                mb >= 1.0 -> String.format(java.util.Locale.US, "%.1f MB/s", mb)
                else -> String.format(java.util.Locale.US, "%.0f KB/s", kb)
            }
        }

        fun formatEta(sec: Long): String {
            if (sec <= 0) return ""
            return when {
                sec >= 3600 -> "${sec / 3600}h ${(sec % 3600) / 60}m left"
                sec >= 60 -> "${sec / 60}m ${sec % 60}s left"
                else -> "${sec}s left"
            }
        }
    }

    private val receiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            val action = intent?.action ?: return
            val id = intent.getStringExtra(EXTRA_DOWNLOAD_ID) ?: return
            val item = items.firstOrNull { it.id == id } ?: return
            when (action) {
                ACTION_CANCEL_DOWNLOAD -> cancel(item)
                ACTION_PAUSE_RESUME_DOWNLOAD -> {
                    if (item.isPaused) resume(item) else pause(item)
                }
            }
        }
    }

    init {
        createNotificationChannel()
        val filter = IntentFilter().apply {
            addAction(ACTION_CANCEL_DOWNLOAD)
            addAction(ACTION_PAUSE_RESUME_DOWNLOAD)
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            act.registerReceiver(receiver, filter, Context.RECEIVER_NOT_EXPORTED)
        } else {
            act.registerReceiver(receiver, filter)
        }
    }

    fun onDestroy() {
        try {
            act.unregisterReceiver(receiver)
        } catch (_: Exception) {}
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                CHANNEL_NAME,
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "Shows progress of active file downloads"
                enableVibration(false)
                setShowBadge(false)
            }
            notificationManager.createNotificationChannel(channel)
        }
    }

    fun activeTransfers(): List<DownloadItem> {
        return items.filter { it.state == DownloadStatus.DOWNLOADING || it.state == DownloadStatus.PAUSED }
    }

    /** Save response handed over by GeckoView. */
    fun save(response: WebResponse) {
        var disposition: String? = null
        var type: String? = null
        for ((k, v) in response.headers) {
            if (k.equals("content-disposition", true)) disposition = v
            if (k.equals("content-type", true)) type = v
        }
        val name = fileName(disposition, response.uri)
        val item = DownloadItem(name = name, url = response.uri)
        item.mime = type
        items.add(0, item)
        act.onDownloadsChanged()

        val body = response.body
        if (body == null) {
            finish(item, null, DownloadStatus.FAILED, "Download failed")
            return
        }

        val thread = Thread {
            writeStream(item, body, type, name, -1L)
        }
        item.workerThread = thread
        thread.start()
    }

    /** Download link pasted by user or triggered by URL. */
    fun fetch(url: String) {
        if (!Urls.isWeb(url)) {
            act.toast("Paste a full link that starts with https:// or http://")
            return
        }
        val item = DownloadItem(name = fileName(null, url), url = url)
        items.add(0, item)
        act.onDownloadsChanged()

        val thread = Thread {
            executeHttpDownload(item)
        }
        item.workerThread = thread
        thread.start()
    }

    private fun executeHttpDownload(item: DownloadItem) {
        var conn: HttpURLConnection? = null
        try {
            val c = URL(item.url).openConnection() as HttpURLConnection
            conn = c
            c.connectTimeout = 15000
            c.readTimeout = 30000
            c.instanceFollowRedirects = true
            c.setRequestProperty("User-Agent", "Mozilla/5.0 (Android 14; Mobile; rv:158.0) Gecko/158.0 Chrome/124.0.0.0")

            if (item.bytesDownloaded > 0) {
                c.setRequestProperty("Range", "bytes=${item.bytesDownloaded}-")
            }

            val code = c.responseCode
            if (code in 200..299) {
                val cd = c.getHeaderField("Content-Disposition")
                val named = if (cd != null) fileName(cd, item.url) else item.name
                val total = if (code == 206) {
                    val cr = c.getHeaderField("Content-Range")
                    val totalFromRange = cr?.substringAfterLast('/')?.toLongOrNull() ?: -1L
                    if (totalFromRange > 0) totalFromRange else (c.contentLengthLong + item.bytesDownloaded)
                } else {
                    c.contentLengthLong
                }
                item.mime = c.contentType
                writeStream(item, c.inputStream, c.contentType, named, total)
            } else {
                finish(item, null, DownloadStatus.FAILED, "Server error ($code)")
            }
        } catch (e: Exception) {
            if (!item.isCancelled && !item.isPaused) {
                finish(item, null, DownloadStatus.FAILED, "Connection error")
            }
        } finally {
            try { conn?.disconnect() } catch (_: Exception) {}
        }
    }

    private fun writeStream(
        item: DownloadItem,
        input: InputStream,
        mime: String?,
        name: String,
        total: Long
    ) {
        try {
            item.name = withExtension(name, mime)
            item.totalBytes = total
            var out: OutputStream
            var uri: Uri? = null
            var pendingValues: ContentValues? = null

            if (Build.VERSION.SDK_INT >= 29) {
                val values = ContentValues().apply {
                    put(MediaStore.Downloads.DISPLAY_NAME, item.name)
                    put(MediaStore.Downloads.MIME_TYPE, mime?.substringBefore(';') ?: "application/octet-stream")
                    put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS)
                    put(MediaStore.Downloads.IS_PENDING, 1)
                }
                uri = act.contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values)
                    ?: throw IllegalStateException("Cannot create MediaStore download entry")
                out = act.contentResolver.openOutputStream(uri, if (item.bytesDownloaded > 0) "wa" else "w")
                    ?: throw IllegalStateException("Cannot open destination stream")
                pendingValues = ContentValues().apply { put(MediaStore.Downloads.IS_PENDING, 0) }
            } else {
                val dir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS)
                    ?: (act.getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS) ?: act.filesDir)
                if (!dir.exists()) dir.mkdirs()
                val file = File(dir, item.name)
                item.localPath = file.absolutePath
                out = FileOutputStream(file, item.bytesDownloaded > 0)
                uri = Uri.fromFile(file)
            }

            input.use { src ->
                out.use { dst ->
                    val buf = ByteArray(64 * 1024)
                    var lastUpdate = System.currentTimeMillis()
                    var bytesSinceUpdate = 0L

                    updateNotification(item)

                    while (!item.isCancelled && !item.isPaused) {
                        val n = src.read(buf)
                        if (n < 0) break
                        dst.write(buf, 0, n)
                        item.bytesDownloaded += n
                        bytesSinceUpdate += n

                        val now = System.currentTimeMillis()
                        val diff = now - lastUpdate
                        if (diff >= 500) {
                            val speed = (bytesSinceUpdate * 1000) / diff
                            item.speedBytesPerSec = speed
                            if (total > 0 && speed > 0) {
                                item.etaSeconds = (total - item.bytesDownloaded).coerceAtLeast(0) / speed
                            }
                            bytesSinceUpdate = 0L
                            lastUpdate = now

                            item.statusText = if (total > 0) {
                                "${item.progressPercent}% • ${formatSpeed(speed)}"
                            } else {
                                "${formatSize(item.bytesDownloaded)} • ${formatSpeed(speed)}"
                            }

                            act.runOnUiThread {
                                act.onDownloadsChanged()
                            }
                            updateNotification(item)
                        }
                    }
                }
            }

            if (item.isCancelled) {
                if (uri != null && Build.VERSION.SDK_INT >= 29) {
                    try { act.contentResolver.delete(uri, null, null) } catch (_: Exception) {}
                }
                cancelNotification(item)
                finish(item, null, DownloadStatus.CANCELLED, "Cancelled")
                return
            }

            if (item.isPaused) {
                item.statusText = "Paused • ${formatSize(item.bytesDownloaded)}"
                act.runOnUiThread { act.onDownloadsChanged() }
                updateNotification(item)
                return
            }

            if (uri != null && pendingValues != null && Build.VERSION.SDK_INT >= 29) {
                act.contentResolver.update(uri, pendingValues, null, null)
            }

            finish(item, uri, DownloadStatus.DONE, "Download complete")
        } catch (e: Exception) {
            if (!item.isCancelled && !item.isPaused) {
                finish(item, null, DownloadStatus.FAILED, "Download failed")
            }
        }
    }

    fun pause(item: DownloadItem) {
        if (item.state != DownloadStatus.DOWNLOADING) return
        item.isPaused = true
        item.state = DownloadStatus.PAUSED
        item.statusText = "Paused"
        item.workerThread?.interrupt()
        updateNotification(item)
        act.runOnUiThread { act.onDownloadsChanged() }
        act.toast("Paused ${item.name}")
    }

    fun resume(item: DownloadItem) {
        if (item.state != DownloadStatus.PAUSED) return
        item.isPaused = false
        item.state = DownloadStatus.DOWNLOADING
        item.statusText = "Resuming…"
        updateNotification(item)
        act.runOnUiThread { act.onDownloadsChanged() }

        val thread = Thread {
            executeHttpDownload(item)
        }
        item.workerThread = thread
        thread.start()
        act.toast("Resuming ${item.name}")
    }

    fun cancel(item: DownloadItem) {
        item.isCancelled = true
        item.workerThread?.interrupt()
        cancelNotification(item)
        item.state = DownloadStatus.CANCELLED
        item.statusText = "Cancelled"
        act.runOnUiThread { act.onDownloadsChanged() }
        act.toast("Cancelled ${item.name}")
    }

    fun openFile(item: DownloadItem) {
        val targetUri = item.uri ?: run {
            item.localPath?.let { path ->
                val f = File(path)
                if (f.exists()) {
                    try {
                        FileProvider.getUriForFile(act, "${act.packageName}.fileprovider", f)
                    } catch (_: Exception) {
                        Uri.fromFile(f)
                    }
                } else null
            }
        }

        if (targetUri == null) {
            act.toast("File not found or still downloading")
            return
        }

        try {
            val intent = Intent(Intent.ACTION_VIEW).apply {
                setDataAndType(targetUri, item.mime ?: "application/octet-stream")
                flags = Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK
            }
            act.startActivity(intent)
        } catch (e: Exception) {
            act.toast("No app found to open this file")
        }
    }

    fun shareFile(item: DownloadItem) {
        val targetUri = item.uri ?: return
        try {
            val intent = Intent(Intent.ACTION_SEND).apply {
                type = item.mime ?: "application/octet-stream"
                putExtra(Intent.EXTRA_STREAM, targetUri)
                flags = Intent.FLAG_GRANT_READ_URI_PERMISSION
            }
            act.startActivity(Intent.createChooser(intent, "Share ${item.name}"))
        } catch (_: Exception) {
            act.toast("Cannot share file")
        }
    }

    fun removeItem(item: DownloadItem) {
        cancel(item)
        items.remove(item)
        act.onDownloadsChanged()
    }

    private fun updateNotification(item: DownloadItem) {
        val cancelIntent = Intent(ACTION_CANCEL_DOWNLOAD).apply {
            putExtra(EXTRA_DOWNLOAD_ID, item.id)
            setPackage(act.packageName)
        }
        val cancelPending = PendingIntent.getBroadcast(
            act,
            item.notificationId * 10 + 1,
            cancelIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val pauseResumeIntent = Intent(ACTION_PAUSE_RESUME_DOWNLOAD).apply {
            putExtra(EXTRA_DOWNLOAD_ID, item.id)
            setPackage(act.packageName)
        }
        val pauseResumePending = PendingIntent.getBroadcast(
            act,
            item.notificationId * 10 + 2,
            pauseResumeIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val pauseResumeTitle = if (item.isPaused) "Resume" else "Pause"
        val pauseResumeIcon = if (item.isPaused) R.drawable.ic_play else R.drawable.ic_pause

        val contentText = if (item.totalBytes > 0) {
            "${formatSize(item.bytesDownloaded)} of ${formatSize(item.totalBytes)} • ${formatSpeed(item.speedBytesPerSec)}"
        } else {
            "${formatSize(item.bytesDownloaded)} • ${formatSpeed(item.speedBytesPerSec)}"
        }

        val builder = NotificationCompat.Builder(act, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_download)
            .setContentTitle(item.name)
            .setContentText(if (item.isPaused) "Paused • ${formatSize(item.bytesDownloaded)}" else contentText)
            .setOngoing(!item.isPaused)
            .setOnlyAlertOnce(true)
            .setAutoCancel(false)
            .addAction(pauseResumeIcon, pauseResumeTitle, pauseResumePending)
            .addAction(R.drawable.ic_close, "Cancel", cancelPending)

        if (item.totalBytes > 0) {
            builder.setProgress(100, item.progressPercent, false)
            if (item.etaSeconds > 0 && !item.isPaused) {
                builder.setSubText(formatEta(item.etaSeconds))
            }
        } else {
            builder.setProgress(0, 0, true)
        }

        try {
            notificationManager.notify(item.notificationId, builder.build())
        } catch (_: Exception) {}
    }

    private fun notifyComplete(item: DownloadItem) {
        val openIntent = Intent(Intent.ACTION_VIEW).apply {
            item.uri?.let { setDataAndType(it, item.mime ?: "application/octet-stream") }
            flags = Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK
        }
        val openPending = PendingIntent.getActivity(
            act,
            item.notificationId,
            openIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val builder = NotificationCompat.Builder(act, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_download)
            .setContentTitle("Download complete")
            .setContentText("${item.name} (${formatSize(item.bytesDownloaded)})")
            .setAutoCancel(true)
            .setContentIntent(openPending)
            .setOngoing(false)

        try {
            notificationManager.notify(item.notificationId, builder.build())
        } catch (_: Exception) {}
    }

    private fun cancelNotification(item: DownloadItem) {
        try {
            notificationManager.cancel(item.notificationId)
        } catch (_: Exception) {}
    }

    private fun finish(item: DownloadItem, uri: Uri?, state: DownloadStatus, status: String) {
        act.runOnUiThread {
            item.uri = uri
            item.state = state
            item.statusText = status
            act.onDownloadsChanged()
            if (state == DownloadStatus.DONE) {
                notifyComplete(item)
                act.toast("Downloaded ${item.name}")
            } else if (state == DownloadStatus.FAILED) {
                cancelNotification(item)
                act.toast("Failed: ${item.name}")
            }
        }
    }

    private fun withExtension(name: String, mime: String?): String {
        if (name.contains('.') || mime == null) return name
        val ext = android.webkit.MimeTypeMap.getSingleton().getExtensionFromMimeType(mime.substringBefore(';').trim())
        return if (ext.isNullOrEmpty()) name else "$name.$ext"
    }

    private fun fileName(disposition: String?, url: String): String {
        if (disposition != null) {
            val m = Regex("filename\\*?=(?:UTF-8'')?\"?([^\";]+)\"?", RegexOption.IGNORE_CASE).find(disposition)
            if (m != null) return clean(Uri.decode(m.groupValues[1]))
        }
        val last = url.substringBefore('?').substringBefore('#').trimEnd('/').substringAfterLast('/')
        return clean(Uri.decode(last)).ifEmpty { "download" }
    }

    private fun clean(s: String) = s.replace(Regex("[\\\\/:*?\"<>|]"), "_").trim()
}
