package com.liquidair.browser

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.Color
import android.content.res.ColorStateList
import android.graphics.drawable.RippleDrawable
import android.graphics.drawable.ColorDrawable
import android.graphics.Outline
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.ViewOutlineProvider
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.widget.CheckBox
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.PopupWindow
import android.widget.ProgressBar
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast
import android.text.TextUtils
import org.mozilla.geckoview.GeckoSession
import org.mozilla.geckoview.GeckoView
import android.media.AudioManager

/**
 * Liquid Air. The page area is GeckoView (the engine); everything around it is drawn
 * here in plain Android views: tab strip, toolbar, start page, tab view and menus.
 */
class MainActivity : Activity() {
    lateinit var prefs: Prefs
    lateinit var browser: Browser
    lateinit var downloads: Downloads
    lateinit var prompts: PromptUi
    lateinit var permissions: Permissions
    lateinit var geckoView: GeckoView
    private var hoverFrame: HoverFrame? = null
    private var hoverMode = false
    private var cursorBtn: FrameLayout? = null

    private val main = Handler(Looper.getMainLooper())

    private lateinit var root: FrameLayout
    private lateinit var strip: LinearLayout
    private lateinit var toolbar: LinearLayout
    private lateinit var content: FrameLayout
    private lateinit var home: LinearLayout
    private lateinit var homeInput: EditText
    private lateinit var tabsScroll: HorizontalScrollView
    private lateinit var tabsRow: LinearLayout
    private lateinit var modes: FrameLayout
    private lateinit var modePill: View
    private lateinit var modeA: TextView
    private lateinit var addressInput: EditText
    private lateinit var counter: TextView
    private lateinit var progress: View
    private lateinit var homeButton: FrameLayout
    private lateinit var backButton: FrameLayout
    private lateinit var forwardButton: FrameLayout
    private lateinit var reloadButton: FrameLayout
    private lateinit var menuButton: FrameLayout
    private lateinit var overview: FrameLayout
    private lateinit var overviewBody: LinearLayout
    private lateinit var toolPage: FrameLayout
    private lateinit var plusView: FrameLayout
    private lateinit var findBar: LinearLayout
    private lateinit var findInput: EditText
    private lateinit var toolTitle: TextView
    private lateinit var toolBody: LinearLayout

    private var menu: PopupWindow? = null
    private var zoomLabel: TextView? = null
    private var currentTool = ""
    private var clearRange = "all"
    private var clearHistory = true
    private var clearCookies = true
    private var clearCache = true
    private var fullscreen = false
    private var wrenchButton: FrameLayout? = null
    private var transferPill: FrameLayout? = null
    private var transferPillText: TextView? = null
    private var transferPillSubText: TextView? = null

    private class Pill(val view: View, val mark: FrameLayout, val title: TextView, val tab: Tab)

    private val pills = HashMap<Int, Pill>()

    private val androidAsks = HashMap<Int, (Boolean) -> Unit>()
    private var askCode = 200
    private var filePicked: ((List<Uri>) -> Unit)? = null

    // ---- start-up -------------------------------------------------------

    override fun onCreate(savedInstanceState: Bundle?) {
        prefs = Prefs(this)
        setTheme(if (wantDark()) R.style.AppThemeDark else R.style.AppThemeLight)
        super.onCreate(savedInstanceState)
        Engine.start(this, prefs)
        downloads = Downloads(this)
        prompts = PromptUi(this)
        permissions = Permissions(this)
        browser = Browser(this, prefs)
        applyTheme()
        buildUi()
        val first = intent?.data?.toString()
        if (first != null || !prefs.restoreTabs || !restoreSession()) browser.newTab(first)
        if (Build.VERSION.SDK_INT >= 33 && prefs.bgPlay) {
            askAndroid(listOf(Manifest.permission.POST_NOTIFICATIONS)) { }
        }
    }

    /** Light or dark, exactly as the system says. */
    private fun wantDark(): Boolean = when (prefs.theme) {
        1 -> false
        2 -> true
        else -> systemIsDark()
    }

    /** Re-draws the whole screen in the current theme, keeping tabs and the open page. */
    private fun paintCursor() {
        val b = cursorBtn ?: return
        b.background = if (hoverMode) solid(this, C.MINT, 18f) else RippleDrawable(
            ColorStateList.valueOf(if (C.dark) 0x33FFFFFF else 0x8CFFFFFF.toInt()), null, solid(this, Color.WHITE, 18f))
        b.isSelected = hoverMode
    }

    private fun setHoverMode(on: Boolean, say: Boolean) {
        hoverMode = on
        hoverFrame?.hoverMode = on
        paintCursor()
        if (say) toast(if (on) "Hover mode on: tap shows details, nothing opens. Drag still scrolls." else "Hover mode off")
    }

    private fun reTheme() {
        val tool = currentTool
        menu?.dismiss()
        setTheme(if (wantDark()) R.style.AppThemeDark else R.style.AppThemeLight)
        applyTheme()
        Engine.apply(prefs)
        buildUi()
        currentTool = ""
        syncMode(false)
        rebuildPills()
        showActive()
        refreshToolbar()
        if (tool == "settings") openTool("settings")
    }

    private fun applyTheme() {
        C.dark = wantDark()
        window.statusBarColor = C.BG
        window.navigationBarColor = C.WHITE
        if (!fullscreen) setBars(false)
    }

    @Suppress("DEPRECATION")
    private fun setBars(immersive: Boolean) {
        var f = View.SYSTEM_UI_FLAG_LAYOUT_STABLE
        if (immersive) {
            f = f or View.SYSTEM_UI_FLAG_FULLSCREEN or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or
                View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
        } else if (!C.dark) {
            f = f or View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR
            if (Build.VERSION.SDK_INT >= 26) f = f or View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR
        }
        window.decorView.systemUiVisibility = f
    }

    override fun onConfigurationChanged(newConfig: android.content.res.Configuration) {
        super.onConfigurationChanged(newConfig)
        if (!::root.isInitialized || prefs.theme != 0 || wantDark() == C.dark) return
        reTheme()
    }

    override fun onNewIntent(intent: Intent?) {
        super.onNewIntent(intent)
        val url = intent?.data?.toString() ?: return
        browser.newTab(url)
    }

    /** Remembers the open pages (not private ones) for the next start. */
    private fun saveSession() {
        if (!prefs.restoreTabs) {
            prefs.session = ""
            return
        }
        try {
            val arr = org.json.JSONArray()
            var active = 0
            for (t in browser.tabs) {
                if (t.isPrivate || t.home || !Urls.isWeb(t.url)) continue
                if (t.id == browser.activeId) active = arr.length()
                arr.put(t.url)
            }
            prefs.session = org.json.JSONObject().put("urls", arr).put("active", active).toString()
        } catch (e: Exception) {
        }
    }

    private fun restoreSession(): Boolean {
        return try {
            val o = org.json.JSONObject(prefs.session)
            val arr = o.getJSONArray("urls")
            if (arr.length() == 0) return false
            val n = minOf(arr.length(), 5)
            val active = o.optInt("active", 0).coerceIn(0, n - 1)
            var pick: Tab? = null
            for (i in 0 until n) {
                val t = browser.newTab(arr.getString(i), false, false)
                if (i == active) pick = t
            }
            pick?.let { browser.select(it) }
            true
        } catch (e: Exception) {
            false
        }
    }

    override fun onPause() {
        super.onPause()
        saveSession()
        val audio = getSystemService(Context.AUDIO_SERVICE) as AudioManager
        if (prefs.bgPlay && audio.isMusicActive) {
            try {
                startForegroundService(Intent(this, PlaybackService::class.java))
            } catch (e: Exception) {
                // Android refused to start it; playback may stop with the screen.
            }
        }
    }

    override fun onResume() {
        super.onResume()
        stopService(Intent(this, PlaybackService::class.java))
        if (prefs.ramHardLimit) enforceRamLimit()
    }

    override fun onDestroy() {
        super.onDestroy()
        downloads.onDestroy()
    }

    // ---- building the screen -------------------------------------------

    private fun buildUi() {
        root = FrameLayout(this)
        root.background = ArtDrawable(this)
        // Stop the system's own "dark mode for apps" from greying the picture.
        if (Build.VERSION.SDK_INT >= 29) root.isForceDarkAllowed = false
        // Stop the system's own "dark mode for apps" from greying the picture.
        if (Build.VERSION.SDK_INT >= 29) root.isForceDarkAllowed = false

        val column = LinearLayout(this)
        column.orientation = LinearLayout.VERTICAL
        root.addView(column, FrameLayout.LayoutParams(-1, -1))

        strip = buildStrip()
        column.addView(strip, lp(-1, dp(50)))
        toolbar = buildToolbar()
        column.addView(toolbar, lp(-1, dp(58)))

        progress = View(this)
        progress.background = GradientDrawable(
            GradientDrawable.Orientation.LEFT_RIGHT, intArrayOf(C.SKY_A, C.SKY_C)
        )
        progress.pivotX = 0f
        progress.scaleX = 0f
        column.addView(progress, lp(-1, dp(2)))

        content = FrameLayout(this)
        column.addView(content, LinearLayout.LayoutParams(-1, 0, 1f))
        if (!::geckoView.isInitialized) geckoView = GeckoView(this)
        (geckoView.parent as? ViewGroup)?.removeView(geckoView)
        (hoverFrame?.parent as? ViewGroup)?.removeView(hoverFrame)
        hoverFrame?.removeAllViews()
        val hf = HoverFrame(this)
        hf.addView(geckoView, FrameLayout.LayoutParams(-1, -1))
        hf.hoverMode = hoverMode
        hoverFrame = hf
        content.addView(hf, FrameLayout.LayoutParams(-1, -1))
        home = buildHome()
        content.addView(home, FrameLayout.LayoutParams(-1, -1))
        findBar = buildFindBar()
        findBar.visibility = View.GONE
        content.addView(findBar, FrameLayout.LayoutParams(-1, dp(46), Gravity.TOP).apply {
            leftMargin = dp(8); rightMargin = dp(8); topMargin = dp(6)
        })

        val pill = buildTransferPill()
        pill.visibility = View.GONE
        transferPill = pill
        content.addView(pill, FrameLayout.LayoutParams(-1, -2, Gravity.BOTTOM).apply {
            leftMargin = dp(14); rightMargin = dp(14); bottomMargin = dp(14)
        })

        overview = buildOverviewShell()
        overview.visibility = View.GONE
        root.addView(overview, FrameLayout.LayoutParams(-1, -1))
        toolPage = buildToolShell()
        toolPage.visibility = View.GONE
        root.addView(toolPage, FrameLayout.LayoutParams(-1, -1))

        setContentView(root)
        root.addOnLayoutChangeListener { _, l, t, r, b, ol, ot, orr, ob ->
            if (r - l != orr - ol || b - t != ob - ot) {
                Backdrop.rebuild(this, root)
                Backdrop.redraw(root)
            }
        }
    }

    private fun buildStrip(): LinearLayout {
        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        row.gravity = Gravity.CENTER_VERTICAL
        row.pad(10, 0, 10, 0)

        // The A / InPrivate switch.
        modes = FrameLayout(this)
        modes.background = glass(this, 19f)
        modePill = View(this)
        modePill.background = solid(this, C.MINT, 16f)
        modes.addView(modePill, FrameLayout.LayoutParams(dp(32), dp(32)).apply {
            leftMargin = dp(3)
            topMargin = dp(3)
        })
        modeA = text(this, "A", 15f, C.INK, true)
        modeA.gravity = Gravity.CENTER
        modes.addView(modeA, FrameLayout.LayoutParams(dp(32), dp(32)).apply {
            leftMargin = dp(3)
            topMargin = dp(3)
        })
        val eyeBox = FrameLayout(this)
        eyeBox.contentDescription = "InPrivate tabs"
        eyeBox.addView(icon(this, R.drawable.ic_eye_off, 23), FrameLayout.LayoutParams(dp(23), dp(23), Gravity.CENTER))
        modes.addView(eyeBox, FrameLayout.LayoutParams(dp(34), dp(38)).apply { leftMargin = dp(37) })
        modeA.setOnClickListener { switchMode(false) }
        eyeBox.setOnClickListener { switchMode(true) }
        modes.setOnClickListener { }
        row.addView(modes, lp(dp(74), dp(38)))

        tabsScroll = HorizontalScrollView(this)
        tabsScroll.isHorizontalScrollBarEnabled = false
        tabsRow = LinearLayout(this)
        tabsRow.orientation = LinearLayout.HORIZONTAL
        tabsRow.gravity = Gravity.CENTER_VERTICAL
        tabsScroll.addView(tabsRow, FrameLayout.LayoutParams(-2, -1))
        row.addView(tabsScroll, LinearLayout.LayoutParams(0, -1, 1f).apply { leftMargin = dp(8) })

        val plus = FrameLayout(this)
        plus.background = glass(this, 18f)
        val plusIcon = icon(this, R.drawable.ic_plus, 20)
        plus.addView(plusIcon, FrameLayout.LayoutParams(dp(20), dp(20), Gravity.CENTER))
        plus.contentDescription = "New tab"
        plus.setOnClickListener { browser.newTab() }
        plusView = plus
        return row
    }

    private fun buildToolbar(): LinearLayout {
        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        row.gravity = Gravity.CENTER_VERTICAL
        row.pad(6, 0, 6, 0)

        homeButton = iconButton(this, R.drawable.ic_home, 38, 40, 25, "Home")
        backButton = iconButton(this, R.drawable.ic_back, 38, 40, 25, "Back")
        forwardButton = iconButton(this, R.drawable.ic_forward, 38, 40, 25, "Forward")
        reloadButton = iconButton(this, R.drawable.ic_reload, 38, 40, 25, "Reload")
        for (b in listOf(homeButton, backButton, forwardButton, reloadButton)) row.addView(b)

        homeButton.setOnClickListener { browser.active()?.let { browser.goHome(it) } }
        backButton.setOnClickListener { browser.active()?.let { if (browser.canBack(it)) browser.back(it) } }
        forwardButton.setOnClickListener { browser.active()?.let { if (browser.canForward(it)) browser.forward(it) } }
        reloadButton.setOnClickListener {
            browser.active()?.let {
                browser.reload(it)
                reloadButton.iconView().animate().rotationBy(360f).setDuration(600)
                    .setInterpolator(android.view.animation.PathInterpolator(.3f, .9f, .3f, 1f)).start()
            }
        }

        addressInput = EditText(this)
        addressInput.background = null
        addressInput.setTextColor(C.INK)
        addressInput.setHintTextColor(C.HINT)
        addressInput.hint = "Search or URL"
        addressInput.textSize = 14.5f
        addressInput.maxLines = 1
        addressInput.isSingleLine = true
        addressInput.imeOptions = EditorInfo.IME_ACTION_GO
        addressInput.inputType = InputType.TYPE_TEXT_VARIATION_URI
        addressInput.setSelectAllOnFocus(true)
        addressInput.pad(40, 0, 44, 0)
        addressInput.setOnEditorActionListener { v, actionId, _ ->
            if (actionId == EditorInfo.IME_ACTION_GO) {
                submit(v.text.toString())
                true
            } else false
        }
        addressInput.setOnFocusChangeListener { _, focused ->
            val tab = browser.active()
            if (focused && tab != null && !tab.home) {
                addressInput.setText(tab.url)
                addressInput.selectAll()
            } else if (!focused) {
                refreshToolbar()
            }
        }
        val addrBox = FrameLayout(this)
        addrBox.background = glass(this, 20f, C.FIELD)

        val wb = iconButton(this, R.drawable.ic_wrench, 36, 36, 20, "Browser Tools & Extensions")
        wb.layoutParams = FrameLayout.LayoutParams(dp(36), dp(36), Gravity.START or Gravity.CENTER_VERTICAL).apply { leftMargin = dp(2) }
        wb.setOnClickListener { showWrenchTools() }
        wrenchButton = wb
        addrBox.addView(wb)

        addrBox.addView(addressInput, FrameLayout.LayoutParams(-1, -1))
        val cb = iconButton(this, R.drawable.ic_cursor, 36, 36, 20, "Hover mode")
        cb.layoutParams = FrameLayout.LayoutParams(dp(36), dp(36), Gravity.END or Gravity.CENTER_VERTICAL).apply { rightMargin = dp(2) }
        cb.setOnClickListener { setHoverMode(!hoverMode, true) }
        cursorBtn = cb
        addrBox.addView(cb)
        row.addView(addrBox, LinearLayout.LayoutParams(0, dp(40), 1f).apply {
            leftMargin = dp(2)
            rightMargin = dp(6)
        })
        paintCursor()

        counter = text(this, "1", 13f, C.INK, true)
        counter.gravity = Gravity.CENTER
        counter.background = glass(this, 12f).also { it.ring = true }
        counter.contentDescription = "Tabs"
        counter.setOnClickListener { showOverview() }
        row.addView(counter, lp(dp(36), dp(36)).apply { rightMargin = dp(2) })

        menuButton = iconButton(this, R.drawable.ic_tune, 38, 40, 24, "Settings menu")
        menuButton.setOnClickListener { showMenu() }
        row.addView(menuButton)
        return row
    }

    private fun buildHome(): LinearLayout {
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.addView(View(this), LinearLayout.LayoutParams(-1, 0, 3f))

        val bar = CappedFrame(this, dp(580))
        bar.background = liquidBar(this, 26f)
        homeInput = EditText(this)
        homeInput.background = null
        homeInput.setTextColor(C.INK)
        homeInput.setHintTextColor(C.HINT)
        homeInput.textSize = 17f
        homeInput.isSingleLine = true
        homeInput.imeOptions = EditorInfo.IME_ACTION_SEARCH
        homeInput.inputType = InputType.TYPE_TEXT_VARIATION_URI
        homeInput.pad(22, 0, 56, 0)
        homeInput.setOnEditorActionListener { v, actionId, _ ->
            if (actionId == EditorInfo.IME_ACTION_SEARCH) {
                submit(v.text.toString())
                true
            } else false
        }
        bar.addView(homeInput, FrameLayout.LayoutParams(-1, -1))
        val go = icon(this, R.drawable.ic_search, 22)
        go.alpha = 0.8f
        go.setOnClickListener { submit(homeInput.text.toString()) }
        bar.addView(go, FrameLayout.LayoutParams(dp(22), dp(22), Gravity.END or Gravity.CENTER_VERTICAL).apply {
            rightMargin = dp(16)
        })
        col.addView(bar, LinearLayout.LayoutParams(-1, dp(56)).apply {
            leftMargin = dp(24)
            rightMargin = dp(24)
            gravity = Gravity.CENTER_HORIZONTAL
        })
        col.addView(View(this), LinearLayout.LayoutParams(-1, 0, 2f))
        return col
    }

    // ---- find in page --------------------------------------------------

    private fun buildFindBar(): LinearLayout {
        val bar = LinearLayout(this)
        bar.gravity = Gravity.CENTER_VERTICAL
        bar.background = solid(this, C.WHITE, 23f)
        bar.elevation = dpf(6f)
        bar.pad(14, 0, 4, 0)
        findInput = EditText(this)
        findInput.background = null
        findInput.hint = "Find in page"
        findInput.setTextColor(C.INK)
        findInput.setHintTextColor(C.HINT)
        findInput.textSize = 15f
        findInput.isSingleLine = true
        findInput.imeOptions = EditorInfo.IME_ACTION_SEARCH
        findInput.setOnEditorActionListener { _, id, _ ->
            if (id == EditorInfo.IME_ACTION_SEARCH) { findNext(false); true } else false
        }
        findInput.addTextChangedListener(object : android.text.TextWatcher {
            override fun afterTextChanged(e: android.text.Editable?) { findNext(false) }
            override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
        })
        bar.addView(findInput, LinearLayout.LayoutParams(0, -1, 1f))
        fun btn(label: String, action: () -> Unit) {
            val b = text(this, label, 20f, C.INK, true)
            b.gravity = Gravity.CENTER
            b.background = withRipple(null)
            b.setOnClickListener { action() }
            bar.addView(b, lp(dp(40), dp(40)))
        }
        btn("\u2039") { findNext(true) }
        btn("\u203A") { findNext(false) }
        btn("\u2715") { hideFind() }
        return bar
    }

    private fun showFind() {
        val tab = browser.active()
        if (tab == null || tab.home) { toast("Open a page first"); return }
        findBar.visibility = View.VISIBLE
        findInput.requestFocus()
        val imm = getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
        imm.showSoftInput(findInput, 0)
    }

    private fun hideFind() {
        if (findBar.visibility != View.VISIBLE) return
        findBar.visibility = View.GONE
        findInput.setText("")
        findInput.clearFocus()
        hideKeyboard()
        try { browser.active()?.session?.finder?.clear() } catch (e: Exception) { }
    }

    private fun findNext(backwards: Boolean) {
        val tab = browser.active() ?: return
        val q = findInput.text.toString()
        try {
            if (q.isEmpty()) tab.session.finder.clear()
            else tab.session.finder.find(
                q, if (backwards) GeckoSession.FINDER_FIND_BACKWARDS else GeckoSession.FINDER_FIND_FORWARD
            )
        } catch (e: Exception) {
            // The page is not ready for searching yet.
        }
    }

    /** Takes a picture of the page and saves it in Pictures/LiquidAir. */
    private fun saveScreenshot() {
        val tab = browser.active()
        if (tab == null || tab.home || geckoView.session !== tab.session) {
            toast("Open a page first")
            return
        }
        if (tab.isPrivate) {
            toast("Screenshots are off in private tabs")
            return
        }
        if (Build.VERSION.SDK_INT < 29) {
            toast("Screenshots need Android 10 or newer")
            return
        }
        try {
            geckoView.capturePixels().accept({ bmp ->
                if (bmp == null) toast("Could not take the screenshot") else storeScreenshot(bmp)
            }, { toast("Could not take the screenshot") })
        } catch (e: Exception) {
            toast("Could not take the screenshot")
        }
    }

    private fun storeScreenshot(bmp: android.graphics.Bitmap) {
        try {
            val values = android.content.ContentValues().apply {
                put(android.provider.MediaStore.Images.Media.DISPLAY_NAME, "LiquidAir-" + System.currentTimeMillis() + ".png")
                put(android.provider.MediaStore.Images.Media.MIME_TYPE, "image/png")
                put(android.provider.MediaStore.Images.Media.RELATIVE_PATH, "Pictures/LiquidAir")
            }
            val uri = contentResolver.insert(android.provider.MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values)
            if (uri == null) {
                toast("Could not save the screenshot")
                return
            }
            contentResolver.openOutputStream(uri)?.use { bmp.compress(android.graphics.Bitmap.CompressFormat.PNG, 100, it) }
            toast("Screenshot saved in Pictures")
        } catch (e: Exception) {
            toast("Could not save the screenshot")
        }
    }

    private fun copyLink() {
        val tab = browser.active()
        if (tab == null || tab.home || tab.url.isEmpty()) { toast("Nothing to copy"); return }
        val cm = getSystemService(Context.CLIPBOARD_SERVICE) as android.content.ClipboardManager
        cm.setPrimaryClip(android.content.ClipData.newPlainText("link", tab.url))
        toast("Link copied")
    }

    // ---- the callbacks the browser brain uses --------------------------

    private var toastView: TextView? = null

    /** A small glass pill that fades up from the bottom, like the old browser. */
    fun toast(message: String) {
        if (!::root.isInitialized) {
            Toast.makeText(this, message, Toast.LENGTH_SHORT).show()
            return
        }
        toastView?.let { root.removeView(it) }
        val t = text(this, message, 14f, C.INK)
        t.gravity = Gravity.CENTER
        t.pad(18, 11, 18, 11)
        t.background = GradientDrawable().apply {
            cornerRadius = dpf(30f)
            setColor(if (C.dark) 0xE6262B29.toInt() else 0xE6FFFFFF.toInt())
            setStroke(dp(1), if (C.dark) 0x33FFFFFF else 0xCCFFFFFF.toInt())
        }
        t.elevation = dpf(8f)
        root.addView(t, FrameLayout.LayoutParams(-2, -2, Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL).apply {
            bottomMargin = dp(22)
            leftMargin = dp(16)
            rightMargin = dp(16)
        })
        toastView = t
        t.arrive(0f, 8f, 1f, 180)
        main.postDelayed({
            if (toastView === t) {
                t.animate().alpha(0f).setDuration(180).withEndAction { root.removeView(t) }.start()
                toastView = null
            }
        }, 2000)
    }

    /** The set of tabs changed (opened, closed, renamed). */
    fun onTabsChanged() {
        rebuildPills()
        refreshToolbar()
        if (overview.visibility == View.VISIBLE) buildOverview()
    }

    /** The active tab, the mode or the home/web state changed. */
    fun onActiveChanged() {
        syncMode(true)
        rebuildPills()
        showActive()
        refreshToolbar()
        if (overview.visibility == View.VISIBLE) buildOverview()
    }

    /** Something about one tab changed (title, icon, loading, address). */
    fun onTabChanged(tab: Tab) {
        pills[tab.id]?.let { updatePill(it) }
        if (tab.id == browser.activeId) refreshToolbar()
    }

    private fun showActive() {
        val tab = browser.active() ?: return
        if (::findBar.isInitialized && findBar.visibility == View.VISIBLE) hideFind()
        applyPrivacy(tab)
        if (tab.home) {
            geckoView.visibility = View.INVISIBLE
            home.visibility = View.VISIBLE
            content.setBackgroundColor(Color.TRANSPARENT)
            homeInput.hint = if (tab.isPrivate) "Liquid Air inprivate - surf the internet"
            else "Liquid Air - surf the internet"
            homeInput.setText("")
        } else {
            home.visibility = View.GONE
            geckoView.visibility = View.VISIBLE
            content.setBackgroundColor(C.WHITE)
            attach(tab, 0)
        }
    }

    /** Private tabs: hide from screenshots and recent apps, and stop the keyboard learning what is typed. */
    private fun applyPrivacy(tab: Tab) {
        if (tab.isPrivate && prefs.secureTabs) {
            window.addFlags(android.view.WindowManager.LayoutParams.FLAG_SECURE)
        } else {
            window.clearFlags(android.view.WindowManager.LayoutParams.FLAG_SECURE)
        }
        val noLearn = EditorInfo.IME_FLAG_NO_PERSONALIZED_LEARNING
        val base = if (tab.isPrivate) {
            InputType.TYPE_TEXT_VARIATION_URI or InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS
        } else {
            InputType.TYPE_TEXT_VARIATION_URI
        }
        if (addressInput.inputType != base) addressInput.inputType = base
        if (homeInput.inputType != base) homeInput.inputType = base
        addressInput.imeOptions = EditorInfo.IME_ACTION_GO or (if (tab.isPrivate) noLearn else 0)
        homeInput.imeOptions = EditorInfo.IME_ACTION_SEARCH or (if (tab.isPrivate) noLearn else 0)
    }

    private fun attach(tab: Tab, tries: Int) {
        if (!tab.session.isOpen) {
            if (tries < 40) {
                main.postDelayed({
                    if (browser.active() === tab && !tab.home) attach(tab, tries + 1)
                }, 60)
            }
            return
        }
        if (geckoView.session !== tab.session) {
            val old = geckoView.releaseSession()
            old?.setActive(false)
            geckoView.setSession(tab.session)
        }
        tab.session.setActive(true)
    }

    fun detach(tab: Tab) {
        if (geckoView.session === tab.session) geckoView.releaseSession()
    }

    fun setFullscreen(on: Boolean) {
        fullscreen = on
        strip.visibility = if (on) View.GONE else View.VISIBLE
        toolbar.visibility = if (on) View.GONE else View.VISIBLE
        progress.visibility = if (on) View.GONE else View.VISIBLE
        setBars(on)
        // Keep the screen awake while a video is full screen.
        if (on) window.addFlags(android.view.WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        else window.clearFlags(android.view.WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
    }

    // ---- submitting addresses ------------------------------------------

    private fun submit(textIn: String) {
        val tab = browser.active() ?: return
        val value = textIn.trim()
        if (value.isEmpty()) return
        addressInput.clearFocus()
        homeInput.clearFocus()
        hideKeyboard()
        browser.load(tab, value)
    }

    private fun hideKeyboard() {
        val imm = getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
        imm.hideSoftInputFromWindow(root.windowToken, 0)
    }

    // ---- mode switch ------------------------------------------------

    private fun switchMode(priv: Boolean) {
        if (browser.privateMode == priv) return
        captureThen(browser.active()) { browser.setMode(priv) }
    }

    private fun syncMode(animated: Boolean) {
        val target = if (browser.privateMode) dp(34).toFloat() else 0f
        if (animated) modePill.animate().translationX(target).setDuration(320).start()
        else modePill.translationX = target
    }

    // ---- the tab strip --------------------------------------------------

    private val seenTabs = HashSet<Int>()
    private var pillsReady = false

    private fun rebuildPills() {
        tabsRow.removeAllViews()
        pills.clear()
        var activePill: View? = null
        var fresh = false
        for (tab in browser.modeTabs()) {
            val pill = makePill(tab)
            pills[tab.id] = pill
            tabsRow.addView(pill.view, lp(dp(250), dp(36)).apply { rightMargin = dp(8) })
            if (tab.id == browser.activeId) activePill = pill.view
            if (seenTabs.add(tab.id) && pillsReady) {
                fresh = true
                pill.view.arrive(40f, 0f, .7f, 230)
            }
        }
        pillsReady = true
        if (fresh) {
            plusView.animate().rotationBy(90f).translationX(dpf(10f)).setDuration(130).withEndAction {
                plusView.animate().translationX(0f).setDuration(130).start()
            }.start()
        }
        (plusView.parent as? ViewGroup)?.removeView(plusView)
        tabsRow.addView(plusView, lp(dp(36), dp(36)))
        activePill?.let { v -> tabsScroll.post { tabsScroll.smoothScrollTo(v.left - dp(8), 0) } }
    }

    private fun makePill(tab: Tab): Pill {
        val active = tab.id == browser.activeId
        val view = LinearLayout(this)
        view.orientation = LinearLayout.HORIZONTAL
        view.gravity = Gravity.CENTER_VERTICAL
        view.pad(8, 0, 6, 0)
        val groupColor = (C.INK and 0x00FFFFFF) or 0x59000000
        view.background = if (active) {
            solid(this, C.WHITE, 18f).also { if (tab.grouped) it.setStroke(dp(2), groupColor) }
        } else {
            glass(this, 18f).also { if (tab.grouped) it.extraStroke(dp(2), groupColor) }
        }
        if (active) view.elevation = dpf(2f)

        val mark = FrameLayout(this)
        mark.background = solid(this, C.SHADE, 10f)
        view.addView(mark, lp(dp(20), dp(20)))

        val title = oneLine(text(this, "", 13f))
        view.addView(title, LinearLayout.LayoutParams(0, -2, 1f).apply {
            leftMargin = dp(8)
            rightMargin = dp(4)
        })
        val close = icon(this, R.drawable.ic_close, 14)
        close.contentDescription = "Close tab"
        close.setPadding(dp(8), dp(8), dp(8), dp(8))
        view.addView(close, lp(dp(30), dp(30)))

        view.setOnClickListener {
            if (tab.id != browser.activeId) captureThen(browser.active()) { browser.select(tab) }
        }
        close.setOnClickListener { closePillAnimated(view, tab) }
        val pill = Pill(view, mark, title, tab)
        updatePill(pill)
        return pill
    }

    /** The tab shrinks and fades before it goes. */
    private fun closePillAnimated(v: View, tab: Tab) {
        val params = v.layoutParams as? LinearLayout.LayoutParams
        if (params == null) {
            browser.close(tab)
            return
        }
        v.isClickable = false
        val w0 = params.width
        animate(240, 0f, 1f) { f ->
            params.width = (w0 * (1f - f)).toInt()
            params.rightMargin = (dp(8) * (1f - f)).toInt()
            v.alpha = 1f - f
            v.scaleX = 1f - .28f * f
            v.layoutParams = params
        }.addListener(object : android.animation.AnimatorListenerAdapter() {
            override fun onAnimationEnd(animation: android.animation.Animator) {
                browser.close(tab)
            }
        })
    }

    private fun updatePill(p: Pill) {
        p.title.text = p.tab.label()
        p.mark.removeAllViews()
        val icon = p.tab.icon
        if (icon != null && !p.tab.isPrivate) {
            val img = ImageView(this)
            img.setImageBitmap(icon)
            p.mark.addView(img, FrameLayout.LayoutParams(dp(18), dp(18), Gravity.CENTER))
        } else {
            val letter = text(this, if (p.tab.isPrivate) "P" else "A", 10f, C.INK, true)
            letter.gravity = Gravity.CENTER
            p.mark.addView(letter, FrameLayout.LayoutParams(-1, -1))
        }
    }

    // ---- the toolbar ----------------------------------------------------

    private fun enable(b: FrameLayout, on: Boolean) {
        b.isEnabled = on
        b.iconView().alpha = if (on) 1f else 0.3f
    }

    private fun refreshToolbar() {
        val tab = browser.active() ?: return
        enable(backButton, browser.canBack(tab))
        enable(forwardButton, browser.canForward(tab))
        enable(homeButton, !tab.home)
        reloadButton.iconView().setImageResource(if (tab.loading) R.drawable.ic_stop else R.drawable.ic_reload)
        val count = browser.modeTabs().size.toString()
        if (counter.text.toString() != count) {
            counter.text = count
            counter.animate().scaleX(1.15f).scaleY(1.15f).setDuration(120).withEndAction {
                counter.animate().scaleX(1f).scaleY(1f).setDuration(120).start()
            }.start()
        }
        if (!addressInput.hasFocus()) {
            addressInput.setText(if (tab.home) "" else Urls.display(tab.url))
        }
        val p = if (tab.loading && !tab.home) tab.progress / 100f else 0f
        progress.animate().scaleX(p).setDuration(120).start()
    }

    // ---- tab thumbnails ---------------------------------------------------

    /** Takes a small picture of the page (for the tab view), then runs [then]. */
    private fun captureThen(tab: Tab?, then: () -> Unit) {
        if (tab == null || tab.home || geckoView.session !== tab.session ||
            geckoView.visibility != View.VISIBLE
        ) {
            then()
            return
        }
        var done = false
        val finish = {
            if (!done) {
                done = true
                then()
            }
        }
        main.postDelayed({ finish() }, 450)
        try {
            geckoView.capturePixels().accept({ bmp ->
                if (bmp != null) {
                    val w = 420
                    val h = (bmp.height * (w.toFloat() / bmp.width)).toInt().coerceAtLeast(1)
                    tab.thumb = Bitmap.createScaledBitmap(bmp, w, h, true)
                }
                finish()
            }, { _ -> finish() })
        } catch (e: Exception) {
            finish()
        }
    }

    // ---- the tab view (opened by the number box) --------------------------

    private fun buildOverviewShell(): FrameLayout {
        val shell = FrameLayout(this)
        shell.background = ArtDrawable(this)
        shell.isClickable = true
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        shell.addView(col, FrameLayout.LayoutParams(-1, -1))

        val header = LinearLayout(this)
        header.gravity = Gravity.CENTER_VERTICAL
        header.pad(12, 8, 12, 8)
        val back = iconButton(this, R.drawable.ic_back, 44, 44, 24, "Back")
        back.background = glass(this, 22f)
        back.setOnClickListener { hideOverview() }
        header.addView(back)
        val title = text(this, "Tabs", 22f, C.INK, true)
        header.addView(title, LinearLayout.LayoutParams(0, -2, 1f).apply { leftMargin = dp(14) })
        val clear = text(this, "Clear all", 14f, C.INK, true)
        clear.gravity = Gravity.CENTER
        clear.pad(16, 0, 16, 0)
        clear.background = glass(this, 20f)
        clear.setOnClickListener {
            for (i in 0 until overviewBody.childCount) {
                overviewBody.getChildAt(i).animate().alpha(0f).translationY(-dpf(10f))
                    .scaleX(.88f).scaleY(.88f).setDuration(480).start()
            }
            for (i in 0 until tabsRow.childCount) {
                tabsRow.getChildAt(i).animate().alpha(0f).translationY(-dpf(10f)).setDuration(480).start()
            }
            playShine(overview)
            main.postDelayed({ browser.closeAllInMode() }, 480)
        }
        header.addView(clear, lp(-2, dp(40)))
        val add = iconButton(this, R.drawable.ic_plus, 44, 44, 22, "New tab")
        add.background = glass(this, 22f)
        add.setOnClickListener {
            hideOverview()
            browser.newTab()
        }
        header.addView(add, LinearLayout.LayoutParams(dp(44), dp(44)).apply { leftMargin = dp(8) })
        col.addView(header, lp(-1, -2))

        val scroll = ScrollView(this)
        overviewBody = LinearLayout(this)
        overviewBody.orientation = LinearLayout.VERTICAL
        overviewBody.pad(10, 4, 10, 24)
        scroll.addView(overviewBody, FrameLayout.LayoutParams(-1, -2))
        col.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        return shell
    }

    private fun showOverview() {
        closeMenu()
        hideKeyboard()
        captureThen(browser.active()) {
            buildOverview()
            overview.visibility = View.VISIBLE
            overview.arrive(20f)
        }
    }

    private fun hideOverview() {
        overview.visibility = View.GONE
    }

    private fun buildOverview() {
        overviewBody.removeAllViews()
        val list = browser.modeTabs()
        var row: LinearLayout? = null
        for ((i, tab) in list.withIndex()) {
            if (i % 2 == 0) {
                row = LinearLayout(this)
                overviewBody.addView(row, lp(-1, -2))
            }
            row?.addView(makeCard(tab), LinearLayout.LayoutParams(0, -2, 1f))
        }
        if (list.size % 2 == 1) row?.addView(View(this), LinearLayout.LayoutParams(0, 1, 1f))
    }

    private fun makeCard(tab: Tab): View {
        val active = tab.id == browser.activeId
        val wrap = FrameLayout(this)
        wrap.setPadding(dp(5), dp(5), dp(5), dp(5))
        val ring = FrameLayout(this)
        ring.setPadding(dp(3), dp(3), dp(3), dp(3))
        ring.background = if (active) skyRing(this, 24f) else null
        wrap.addView(ring, FrameLayout.LayoutParams(-1, -2))

        val card = LinearLayout(this)
        card.orientation = LinearLayout.VERTICAL
        card.background = if (active) solid(this, C.WHITE, 21f) else glass(this, 21f, C.CARD)
        ring.addView(card, FrameLayout.LayoutParams(-1, -2))

        val pic = ImageView(this)
        pic.scaleType = ImageView.ScaleType.CENTER_CROP
        pic.setBackgroundColor(C.SHADE)
        pic.clipToOutline = true
        pic.outlineProvider = object : ViewOutlineProvider() {
            override fun getOutline(view: View, outline: Outline) {
                val r = dpf(18f)
                outline.setRoundRect(0, 0, view.width, view.height + r.toInt(), r)
            }
        }
        val thumb = tab.thumb
        if (thumb != null) pic.setImageBitmap(thumb)
        card.addView(pic, LinearLayout.LayoutParams(-1, dp(150)))

        val bottom = LinearLayout(this)
        bottom.gravity = Gravity.CENTER_VERTICAL
        bottom.pad(10, 0, 4, 0)
        val label = oneLine(text(this, tab.label(), 13f))
        bottom.addView(label, LinearLayout.LayoutParams(0, -2, 1f))
        val close = icon(this, R.drawable.ic_close, 14)
        close.setPadding(dp(10), dp(10), dp(10), dp(10))
        close.setOnClickListener {
            wrap.isEnabled = false
            wrap.animate().alpha(0f).scaleX(.88f).scaleY(.88f).setDuration(200)
                .withEndAction { browser.close(tab) }.start()
        }
        bottom.addView(close, lp(dp(36), dp(36)))
        card.addView(bottom, lp(-1, dp(38)))

        card.setOnClickListener {
            hideOverview()
            browser.select(tab)
        }
        return wrap
    }

    /** A soft reflection that sweeps across the screen. */
    private fun playShine(host: FrameLayout) {
        val band = View(this)
        band.background = GradientDrawable(
            GradientDrawable.Orientation.LEFT_RIGHT,
            intArrayOf(0x00FFFFFF, 0xB3FFFFFF.toInt(), 0x00FFFFFF)
        )
        band.rotation = 14f
        val w = host.width.coerceAtLeast(dp(300))
        host.addView(band, FrameLayout.LayoutParams(dp(130), host.height + dp(200)).apply { topMargin = -dp(100) })
        band.translationX = -dp(200).toFloat()
        band.animate().translationX(w + dp(100).toFloat()).setDuration(800).withEndAction {
            host.removeView(band)
        }.start()
    }

    // ---- the menu ---------------------------------------------------------

    private fun closeMenu() {
        menu?.dismiss()
        menu = null
    }

    private fun showMenu() {
        if (menu != null) {
            closeMenu()
            return
        }
        val panel = LinearLayout(this)
        panel.orientation = LinearLayout.VERTICAL
        panel.pad(8, 8, 8, 8)

        fun item(res: Int, label: String, action: () -> Unit): TextView {
            val row = LinearLayout(this)
            row.gravity = Gravity.CENTER_VERTICAL
            row.pad(12, 0, 12, 0)
            row.background = withRipple(null)
            row.addView(icon(this, res, 27))
            val t = text(this, label, 16f)
            row.addView(t, LinearLayout.LayoutParams(-2, -2).apply { leftMargin = dp(17) })
            row.setOnClickListener {
                closeMenu()
                action()
            }
            panel.addView(row, lp(-1, dp(54)))
            return t
        }
        fun divider() {
            val d = View(this)
            d.setBackgroundColor(C.LINE)
            panel.addView(d, LinearLayout.LayoutParams(-1, dp(1)).apply {
                topMargin = dp(6)
                bottomMargin = dp(6)
                leftMargin = dp(7)
                rightMargin = dp(7)
            })
        }

        item(R.drawable.ic_newtab, "New tab") { browser.newTab() }
        val current = browser.active()
        item(R.drawable.ic_group, if (current?.grouped == true) "Remove tab from group" else "Move tab to group") {
            val t = browser.active()
            if (t != null) {
                t.grouped = !t.grouped
                rebuildPills()
                toast(if (t.grouped) "Tab moved to a group" else "Tab removed from its group")
            }
        }
        item(R.drawable.ic_copy, "Duplicate tab") {
            val t = browser.active()
            if (t != null && !t.home && Urls.isWeb(t.url)) browser.newTab(t.url, t.isPrivate)
            else toast("Open a page first")
        }
        item(R.drawable.ic_close, "Close other tabs") {
            val keep = browser.activeId
            val others = browser.modeTabs().filter { it.id != keep }
            for (t in others) browser.close(t)
            toast(if (others.isEmpty()) "No other tabs" else "Closed " + others.size + " tabs")
        }
        divider()
        item(R.drawable.ic_history, "History") { openTool("history") }
        item(R.drawable.ic_download, "Downloads") { openTool("downloads") }
        item(R.drawable.ic_bookmark, "Bookmarks") { openTool("bookmarks") }
        item(R.drawable.ic_recent, "Recent tabs") { openTool("recent") }
        if (browser.closed.isNotEmpty()) {
            item(R.drawable.ic_newtab, "Reopen closed tab") {
                val last = browser.closed.firstOrNull()
                if (last != null) browser.reopenClosed(last)
            }
        }
        divider()
        val here = browser.active()
        val saved = here != null && browser.bookmarks.any { it.url == here.url }
        item(R.drawable.ic_bookmark, if (saved) "Remove bookmark" else "Bookmark page") {
            val t = browser.active()
            if (t == null || t.isPrivate || t.home || !Urls.isWeb(t.url)) {
                toast("Open a page to bookmark")
            } else if (browser.bookmarks.any { it.url == t.url }) {
                browser.bookmarks.removeAll { it.url == t.url }
                browser.saveBookmarks()
                toast("Bookmark removed")
            } else {
                browser.bookmarks.add(0, Saved(t.label(), t.url))
                browser.saveBookmarks()
                toast("Bookmarked")
            }
        }
        item(R.drawable.ic_camera, "Save screenshot") { saveScreenshot() }
        item(R.drawable.ic_search, "Find in page") { showFind() }
        item(R.drawable.ic_copy, "Copy link") { copyLink() }
        item(R.drawable.ic_share, "Share page") { sharePage() }
        item(R.drawable.ic_desktop, if (prefs.desktop) "Mobile mode" else "Desktop mode") {
            browser.setDesktop(!prefs.desktop)
            toast(if (prefs.desktop) "Desktop mode on" else "Mobile mode on")
        }

        val zoom = LinearLayout(this)
        zoom.gravity = Gravity.CENTER_VERTICAL
        zoom.pad(12, 0, 4, 0)
        zoom.addView(icon(this, R.drawable.ic_zoom, 27))
        zoom.addView(text(this, "Zoom", 16f), LinearLayout.LayoutParams(0, -2, 1f).apply { leftMargin = dp(17) })
        fun step(label: String, delta: Int) {
            val b = text(this, label, 20f, C.INK, true)
            b.gravity = Gravity.CENTER
            b.background = withRipple(solid(this, C.SOFT, 16f))
            b.setOnClickListener {
                prefs.zoom += delta
                Engine.apply(prefs)
                zoomLabel?.text = prefs.zoom.toString() + "%"
            }
            zoom.addView(b, lp(dp(34), dp(34)))
        }
        step("−", -10)
        val z = text(this, prefs.zoom.toString() + "%", 13f)
        z.gravity = Gravity.CENTER
        zoomLabel = z
        zoom.addView(z, lp(dp(46), dp(34)))
        step("+", 10)
        panel.addView(zoom, lp(-1, dp(54)))
        divider()
        item(R.drawable.ic_tune, "Settings") { openTool("settings") }

        val scroller = android.widget.ScrollView(this)
        scroller.isVerticalScrollBarEnabled = false
        scroller.background = GradientDrawable().apply {
            cornerRadius = dpf(22f)
            setColor(if (C.dark) 0xEB262B29.toInt() else 0xE0FFFFFF.toInt())
            setStroke(dp(1), if (C.dark) 0x33FFFFFF else 0xCCFFFFFF.toInt())
        }
        scroller.clipToOutline = true
        panel.background = null
        scroller.addView(panel)
        val maxH = resources.displayMetrics.heightPixels - dp(130)
        val panelW = minOf(dp(330), resources.displayMetrics.widthPixels - dp(16))
        panel.measure(
            View.MeasureSpec.makeMeasureSpec(panelW, View.MeasureSpec.EXACTLY),
            View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED)
        )
        val popup = PopupWindow(scroller, panelW, minOf(panel.measuredHeight, maxH), true)
        popup.elevation = dpf(14f)
        popup.setBackgroundDrawable(null)
        popup.isOutsideTouchable = true
        popup.setOnDismissListener { menu = null }
        val where = IntArray(2)
        menuButton.getLocationOnScreen(where)
        val wantedLeft = resources.displayMetrics.widthPixels - dp(8) - panelW
        popup.showAsDropDown(menuButton, wantedLeft - where[0], dp(12))
        scroller.pivotX = panelW.toFloat()
        scroller.pivotY = 0f
        scroller.arrive(0f, -5f, .98f, 160)
        menu = popup
    }

    private fun sharePage() {
        val tab = browser.active()
        if (tab == null || tab.home || !Urls.isWeb(tab.url)) {
            toast("Open a page to share.")
            return
        }
        val send = Intent(Intent.ACTION_SEND)
        send.type = "text/plain"
        send.putExtra(Intent.EXTRA_SUBJECT, tab.title)
        send.putExtra(Intent.EXTRA_TEXT, tab.url)
        startActivity(Intent.createChooser(send, "Share page"))
    }

    // ---- tool pages: history, downloads, bookmarks, recent, settings -------

    private fun buildToolShell(): FrameLayout {
        val shell = FrameLayout(this)
        shell.setBackgroundColor(C.WHITE)
        shell.isClickable = true
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        shell.addView(col, FrameLayout.LayoutParams(-1, -1))

        val header = LinearLayout(this)
        header.gravity = Gravity.CENTER_VERTICAL
        header.pad(14, 12, 14, 8)
        val back = iconButton(this, R.drawable.ic_back, 44, 44, 24, "Back")
        back.background = solid(this, C.SOFT, 22f)
        back.setOnClickListener { closeTool() }
        header.addView(back)
        toolTitle = text(this, "", 24f, C.INK, true)
        header.addView(toolTitle, LinearLayout.LayoutParams(-2, -2).apply { leftMargin = dp(16) })
        col.addView(header, lp(-1, -2))

        val scroll = ScrollView(this)
        toolBody = LinearLayout(this)
        toolBody.orientation = LinearLayout.VERTICAL
        toolBody.pad(16, 8, 16, 32)
        scroll.addView(toolBody, FrameLayout.LayoutParams(-1, -2))
        col.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        return shell
    }

    private fun openTool(kind: String) {
        currentTool = kind
        hideKeyboard()
        renderTool()
        val wasShowing = toolPage.visibility == View.VISIBLE
        toolPage.visibility = View.VISIBLE
        if (!wasShowing) toolPage.arrive(20f)
    }

    private fun closeTool() {
        toolPage.visibility = View.GONE
        currentTool = ""
    }

    fun onDownloadsChanged() {
        updateTransferPill()
        if (currentTool == "downloads" && toolPage.visibility == View.VISIBLE) renderTool()
    }

    private fun renderTool() {
        toolBody.removeAllViews()
        toolTitle.text = when (currentTool) {
            "history" -> "History"
            "downloads" -> "Downloads"
            "bookmarks" -> "Bookmarks"
            "recent" -> "Recent tabs"
            else -> "Settings"
        }
        when (currentTool) {
            "history" -> renderHistory()
            "downloads" -> renderDownloads()
            "bookmarks" -> renderBookmarks()
            "recent" -> renderRecent()
            else -> renderSettings()
        }
    }

    private fun row(title: String, subtitle: String?, onClick: (() -> Unit)?, trailing: View? = null): LinearLayout {
        val r = LinearLayout(this)
        r.gravity = Gravity.CENTER_VERTICAL
        r.pad(6, 10, 6, 10)
        r.minimumHeight = dp(60)
        if (onClick != null) {
            r.background = withRipple(null)
            r.setOnClickListener { onClick() }
        }
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.addView(oneLine(text(this, title, 15.5f, C.INK, true)))
        if (!subtitle.isNullOrEmpty()) {
            val s = oneLine(text(this, subtitle, 12.5f, C.MUTED))
            col.addView(s, lp(-2, -2).apply { topMargin = dp(4) })
        }
        r.addView(col, LinearLayout.LayoutParams(0, -2, 1f))
        if (trailing != null) r.addView(trailing)
        toolBody.addView(r, lp(-1, -2))
        val d = View(this)
        d.setBackgroundColor(C.LINE)
        toolBody.addView(d, lp(-1, dp(1)))
        return r
    }

    private fun empty(message: String) {
        val t = text(this, message, 15f, C.MUTED)
        t.gravity = Gravity.CENTER
        t.pad(8, 40, 8, 40)
        toolBody.addView(t, lp(-1, -2))
    }

    private fun removeButton(onClick: () -> Unit): ImageView {
        val b = icon(this, R.drawable.ic_close, 16)
        b.setPadding(dp(10), dp(10), dp(10), dp(10))
        b.layoutParams = LinearLayout.LayoutParams(dp(40), dp(40))
        b.setOnClickListener { onClick() }
        return b
    }

    private fun openSaved(item: Saved) {
        closeTool()
        val tab = browser.active()
        if (tab != null && tab.home) browser.load(tab, item.url) else browser.newTab(item.url)
    }

    private fun renderHistory() {
        // Delete browsing data.
        val panel = LinearLayout(this)
        panel.orientation = LinearLayout.VERTICAL
        panel.background = solid(this, C.SOFT, 22f)
        panel.pad(16, 14, 16, 16)
        panel.addView(text(this, "Delete browsing data", 16f, C.INK, true))

        val chips = LinearLayout(this)
        fun chip(key: String, label: String) {
            val on = clearRange == key
            val c = text(this, label, 13f, if (on) C.ON_INK else C.INK, true)
            c.gravity = Gravity.CENTER
            c.background = solid(this, if (on) C.INK else C.CARD, 18f)
            c.setOnClickListener {
                clearRange = key
                renderTool()
            }
            chips.addView(c, LinearLayout.LayoutParams(0, dp(36), 1f).apply { rightMargin = dp(8) })
        }
        chip("hour", "Last hour")
        chip("day", "Today")
        chip("all", "All time")
        panel.addView(chips, lp(-1, -2).apply { topMargin = dp(10) })

        fun check(label: String, value: Boolean, set: (Boolean) -> Unit) {
            val cb = CheckBox(this)
            cb.text = label
            cb.textSize = 15f
            cb.setTextColor(C.INK)
            cb.isChecked = value
            cb.setOnCheckedChangeListener { _, v -> set(v) }
            panel.addView(cb, lp(-1, dp(44)))
        }
        check("Browsing history", clearHistory) { clearHistory = it }
        check("Cookies and site data", clearCookies) { clearCookies = it }
        check("Cached images and files", clearCache) { clearCache = it }

        val go = text(this, "Delete data", 15f, C.INK, true)
        go.gravity = Gravity.CENTER
        go.pad(26, 0, 26, 0)
        go.background = glass(this, 22f, C.CARD, C.EDGE_DARK)
        go.setOnClickListener {
            if (!clearHistory && !clearCookies && !clearCache) {
                toast("Choose what to delete.")
            } else {
                if (clearHistory) {
                    val now = System.currentTimeMillis()
                    val since = when (clearRange) {
                        "hour" -> now - 3600000L
                        "day" -> now - (now % 86400000L)
                        else -> 0L
                    }
                    browser.clearHistory(since)
                }
                Engine.clearData(clearCookies, clearCache)
                renderTool()
                playShine(toolPage)
                toast("Browsing data deleted.")
            }
        }
        panel.addView(go, lp(-2, dp(44)).apply { topMargin = dp(8) })
        toolBody.addView(panel, lp(-1, -2).apply { bottomMargin = dp(16) })

        if (browser.history.isEmpty()) {
            empty("Your browsing history will appear here.")
            return
        }
        val search = EditText(this)
        search.hint = "Search history"
        search.textSize = 15f
        search.isSingleLine = true
        search.background = solid(this, C.SOFT, 22f)
        search.pad(18, 0, 18, 0)
        toolBody.addView(search, lp(-1, dp(44)).apply { bottomMargin = dp(6) })

        val rows = ArrayList<Pair<View, String>>()
        val heads = ArrayList<View>()
        var last = ""
        val startOfDay = System.currentTimeMillis().let { it - (it % 86400000L) }
        for (item in browser.history.toList()) {
            val group = when {
                item.time <= 0L -> "Earlier"
                item.time >= startOfDay -> "Today"
                item.time >= startOfDay - 86400000L -> "Yesterday"
                else -> "Earlier"
            }
            if (group != last) {
                last = group
                val h = text(this, group.uppercase(), 12f, C.MUTED, true)
                h.pad(6, 14, 6, 2)
                toolBody.addView(h, lp(-1, -2))
                heads.add(h)
            }
            val before = toolBody.childCount
            row(item.title, Urls.display(item.url), { openSaved(item) },
                removeButton {
                    browser.history.remove(item)
                    browser.saveHistory()
                    renderTool()
                })
            for (i in before until toolBody.childCount) {
                rows.add(toolBody.getChildAt(i) to (item.title + " " + item.url).lowercase())
            }
        }
        search.addTextChangedListener(object : android.text.TextWatcher {
            override fun afterTextChanged(s: android.text.Editable?) {
                val q = s.toString().trim().lowercase()
                for ((v, key) in rows) v.visibility = if (q.isEmpty() || key.contains(q)) View.VISIBLE else View.GONE
                for (h in heads) h.visibility = if (q.isEmpty()) View.VISIBLE else View.GONE
            }
            override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
        })
    }

    private fun buildTransferPill(): FrameLayout {
        val pill = FrameLayout(this)
        pill.background = glass(this, 22f, C.BAR).also { it.ring = true }
        pill.elevation = dpf(6f)
        pill.pad(12, 10, 14, 10)

        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        row.gravity = Gravity.CENTER_VERTICAL

        val icon = ImageView(this)
        icon.setImageResource(R.drawable.ic_download)
        icon.imageTintList = ColorStateList.valueOf(C.SKY_C)
        row.addView(icon, LinearLayout.LayoutParams(dp(26), dp(26)).apply { rightMargin = dp(10) })

        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        val title = text(this, "Downloading file…", 13.5f, C.INK, true)
        title.isSingleLine = true
        title.ellipsize = TextUtils.TruncateAt.END
        col.addView(title)
        transferPillText = title

        val sub = text(this, "0% • 0 KB/s", 12f, C.MUTED)
        col.addView(sub, lp(-2, -2).apply { topMargin = dp(2) })
        transferPillSubText = sub

        row.addView(col, LinearLayout.LayoutParams(0, -2, 1f))

        val btn = text(this, "Details", 12.5f, C.ON_INK, true)
        btn.gravity = Gravity.CENTER
        btn.background = solid(this, C.INK, 14f)
        btn.pad(12, 6, 12, 6)
        btn.setOnClickListener { openTool("downloads") }
        row.addView(btn, LinearLayout.LayoutParams(-2, dp(30)).apply { leftMargin = dp(8) })

        pill.addView(row, FrameLayout.LayoutParams(-1, -2))
        pill.setOnClickListener { openTool("downloads") }
        return pill
    }

    private fun updateTransferPill() {
        val active = downloads.activeTransfers()
        if (active.isEmpty()) {
            transferPill?.visibility = View.GONE
        } else {
            val first = active.first()
            transferPill?.visibility = View.VISIBLE
            val countStr = if (active.size > 1) " (${active.size})" else ""
            transferPillText?.text = "Downloading${countStr}: ${first.name}"
            transferPillSubText?.text = "${first.sizeLabel} • ${first.speedLabel} ${if (first.etaLabel.isNotEmpty()) "• " + first.etaLabel else ""}"
        }
    }

    private fun renderDownloads() {
        val form = LinearLayout(this)
        form.gravity = Gravity.CENTER_VERTICAL
        val input = EditText(this)
        input.hint = "Paste a file link (https://…)"
        input.textSize = 14f
        input.isSingleLine = true
        input.background = solid(this, C.SOFT, 22f)
        input.pad(16, 0, 16, 0)
        form.addView(input, LinearLayout.LayoutParams(0, dp(44), 1f))
        val go = text(this, "Download", 14f, C.ON_INK, true)
        go.gravity = Gravity.CENTER
        go.background = solid(this, C.INK, 22f)
        go.setOnClickListener {
            val url = input.text.toString().trim()
            if (url.isNotEmpty()) {
                input.setText("")
                downloads.fetch(url)
            }
        }
        form.addView(go, LinearLayout.LayoutParams(dp(104), dp(44)).apply { leftMargin = dp(8) })
        toolBody.addView(form, lp(-1, -2).apply { bottomMargin = dp(14) })

        val active = downloads.activeTransfers()
        if (active.isNotEmpty()) {
            val section = text(this, "ACTIVE TRANSFERS (${active.size})", 12f, C.MUTED, true)
            section.pad(4, 6, 4, 6)
            toolBody.addView(section)

            for (d in active) {
                toolBody.addView(buildActiveDownloadCard(d), lp(-1, -2).apply { bottomMargin = dp(10) })
            }
        }

        val completed = downloads.items.filter { it.state != DownloadStatus.DOWNLOADING && it.state != DownloadStatus.PAUSED }
        if (completed.isNotEmpty()) {
            val section = text(this, "DOWNLOADED FILES (${completed.size})", 12f, C.MUTED, true)
            section.pad(4, 12, 4, 6)
            toolBody.addView(section)

            for (d in completed) {
                toolBody.addView(buildCompletedDownloadCard(d), lp(-1, -2).apply { bottomMargin = dp(8) })
            }
        }

        if (downloads.items.isEmpty()) {
            empty("Your downloads will appear here.")
        }
    }

    private fun buildActiveDownloadCard(item: DownloadItem): View {
        val card = LinearLayout(this)
        card.orientation = LinearLayout.VERTICAL
        card.background = solid(this, C.SOFT, 16f)
        card.pad(14, 12, 14, 12)

        val topRow = LinearLayout(this)
        topRow.gravity = Gravity.CENTER_VERTICAL

        val icon = ImageView(this)
        icon.setImageResource(R.drawable.ic_download)
        icon.imageTintList = ColorStateList.valueOf(C.SKY_C)
        topRow.addView(icon, LinearLayout.LayoutParams(dp(24), dp(24)).apply { rightMargin = dp(8) })

        val name = text(this, item.name, 14.5f, C.INK, true)
        name.isSingleLine = true
        name.ellipsize = TextUtils.TruncateAt.END
        topRow.addView(name, LinearLayout.LayoutParams(0, -2, 1f))

        card.addView(topRow, lp(-1, -2))

        val pb = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal)
        pb.isIndeterminate = item.totalBytes <= 0
        pb.max = 100
        pb.progress = item.progressPercent
        card.addView(pb, lp(-1, dp(6)).apply { topMargin = dp(8); bottomMargin = dp(6) })

        val subRow = LinearLayout(this)
        subRow.gravity = Gravity.CENTER_VERTICAL

        val stats = text(this, "${item.sizeLabel} • ${item.speedLabel} ${if (item.etaLabel.isNotEmpty()) "• " + item.etaLabel else ""}", 12f, C.MUTED)
        subRow.addView(stats, LinearLayout.LayoutParams(0, -2, 1f))

        val pauseBtn = text(this, if (item.isPaused) "Resume" else "Pause", 12.5f, C.INK, true)
        pauseBtn.pad(8, 4, 8, 4)
        pauseBtn.background = solid(this, C.WHITE, 12f)
        pauseBtn.setOnClickListener {
            if (item.isPaused) downloads.resume(item) else downloads.pause(item)
        }
        subRow.addView(pauseBtn, lp(-2, -2).apply { rightMargin = dp(6) })

        val cancelBtn = text(this, "Cancel", 12.5f, 0xFFE04040.toInt(), true)
        cancelBtn.pad(8, 4, 8, 4)
        cancelBtn.background = solid(this, C.WHITE, 12f)
        cancelBtn.setOnClickListener {
            downloads.cancel(item)
        }
        subRow.addView(cancelBtn, lp(-2, -2))

        card.addView(subRow, lp(-1, -2))
        return card
    }

    private fun buildCompletedDownloadCard(item: DownloadItem): View {
        val card = LinearLayout(this)
        card.gravity = Gravity.CENTER_VERTICAL
        card.background = withRipple(solid(this, C.SOFT, 16f))
        card.pad(12, 10, 12, 10)

        val icon = ImageView(this)
        val ext = item.name.substringAfterLast('.', "").lowercase()
        val iconRes = when (ext) {
            "apk" -> R.drawable.ic_desktop
            "png", "jpg", "jpeg", "webp", "gif" -> R.drawable.ic_camera
            "mp4", "mkv", "webm", "mp3", "wav" -> R.drawable.ic_tune
            else -> R.drawable.ic_download
        }
        icon.setImageResource(iconRes)
        icon.imageTintList = ColorStateList.valueOf(C.INK)
        card.addView(icon, LinearLayout.LayoutParams(dp(28), dp(28)).apply { rightMargin = dp(10) })

        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL

        val name = text(this, item.name, 14f, C.INK, true)
        name.isSingleLine = true
        name.ellipsize = TextUtils.TruncateAt.END
        col.addView(name)

        val sub = text(this, "${Downloads.formatSize(item.bytesDownloaded)} • ${item.statusText}", 12f, C.MUTED)
        col.addView(sub, lp(-2, -2).apply { topMargin = dp(2) })
        card.addView(col, LinearLayout.LayoutParams(0, -2, 1f))

        if (item.state == DownloadStatus.DONE) {
            val open = text(this, "Open", 12.5f, C.ON_INK, true)
            open.pad(10, 6, 10, 6)
            open.background = solid(this, C.INK, 14f)
            open.setOnClickListener { downloads.openFile(item) }
            card.addView(open, lp(-2, -2).apply { rightMargin = dp(6) })

            val share = iconButton(this, R.drawable.ic_share, 32, 32, 18, "Share")
            share.setOnClickListener { downloads.shareFile(item) }
            card.addView(share, lp(dp(32), dp(32)).apply { rightMargin = dp(2) })
        }

        val del = iconButton(this, R.drawable.ic_trash, 32, 32, 18, "Delete")
        del.setOnClickListener { downloads.removeItem(item) }
        card.addView(del, lp(dp(32), dp(32)))

        card.setOnClickListener {
            if (item.state == DownloadStatus.DONE) downloads.openFile(item)
        }
        return card
    }

    fun onAdsBlockedUpdated(tab: Tab) {
        if (tab.id == browser.activeId) {
            // Updated ad block count
        }
    }

    fun enforceRamLimit() {
        val rt = Runtime.getRuntime()
        val usedMem = (rt.totalMemory() - rt.freeMemory()) / (1024 * 1024)
        if (usedMem > prefs.ramLimitMb) {
            for (t in browser.tabs) {
                if (t.id != browser.activeId && !t.hibernated) {
                    browser.hibernateTab(t)
                }
            }
            Engine.trimMemory()
            System.gc()
        }
    }

    private fun showWrenchTools() {
        val activeTab = browser.active()
        val host = activeTab?.host ?: ""
        val siteLabel = if (host.isNotEmpty()) host else "New Tab"

        val dialogView = ScrollView(this)
        dialogView.isVerticalScrollBarEnabled = false
        val rootLayout = LinearLayout(this)
        rootLayout.orientation = LinearLayout.VERTICAL
        rootLayout.pad(20, 20, 20, 20)
        dialogView.addView(rootLayout, FrameLayout.LayoutParams(-1, -2))

        val dialog = AlertDialog.Builder(this)
            .setView(dialogView)
            .create()

        dialog.window?.setBackgroundDrawable(solid(this, C.BG, 24f))

        // Header
        val headRow = LinearLayout(this)
        headRow.gravity = Gravity.CENTER_VERTICAL

        val wrenchIcon = ImageView(this)
        wrenchIcon.setImageResource(R.drawable.ic_wrench)
        wrenchIcon.imageTintList = ColorStateList.valueOf(C.SKY_C)
        headRow.addView(wrenchIcon, LinearLayout.LayoutParams(dp(26), dp(26)).apply { rightMargin = dp(10) })

        val titleCol = LinearLayout(this)
        titleCol.orientation = LinearLayout.VERTICAL
        titleCol.addView(text(this, "Control Center", 18f, C.INK, true))
        titleCol.addView(text(this, siteLabel, 13f, C.MUTED))
        headRow.addView(titleCol, LinearLayout.LayoutParams(0, -2, 1f))

        val closeBtn = iconButton(this, R.drawable.ic_close, 32, 32, 20, "Close")
        closeBtn.setOnClickListener { dialog.dismiss() }
        headRow.addView(closeBtn)
        rootLayout.addView(headRow, lp(-1, -2).apply { bottomMargin = dp(16) })

        // Section 1: SITE PROTECTION & STATS
        val sec1 = text(this, "SITE PROTECTION & MEDIA", 11.5f, C.MUTED, true)
        sec1.pad(4, 4, 4, 6)
        rootLayout.addView(sec1)

        val siteCard = LinearLayout(this)
        siteCard.orientation = LinearLayout.VERTICAL
        siteCard.background = solid(this, C.SOFT, 16f)
        siteCard.pad(14, 12, 14, 12)

        val blockedCount = activeTab?.adsBlockedCount ?: 0
        val adStatsRow = LinearLayout(this)
        adStatsRow.gravity = Gravity.CENTER_VERTICAL

        val shieldIcon = ImageView(this)
        shieldIcon.setImageResource(R.drawable.ic_shield)
        shieldIcon.imageTintList = ColorStateList.valueOf(if (prefs.isSiteAdBlockEnabled(host)) 0xFF34A853.toInt() else C.MUTED)
        adStatsRow.addView(shieldIcon, LinearLayout.LayoutParams(dp(24), dp(24)).apply { rightMargin = dp(10) })

        val adStatsCol = LinearLayout(this)
        adStatsCol.orientation = LinearLayout.VERTICAL
        val adCountText = text(this, "$blockedCount ads & trackers blocked", 14.5f, C.INK, true)
        adStatsCol.addView(adCountText)
        val totalText = text(this, "Total blocked: ${prefs.totalAdsBlocked} items", 12f, C.MUTED)
        adStatsCol.addView(totalText, lp(-2, -2).apply { topMargin = dp(2) })
        adStatsRow.addView(adStatsCol, LinearLayout.LayoutParams(0, -2, 1f))
        siteCard.addView(adStatsRow, lp(-1, -2))

        val div1 = View(this).apply { background = ColorDrawable(C.LINE) }
        siteCard.addView(div1, lp(-1, dp(1)).apply { topMargin = dp(10); bottomMargin = dp(8) })

        val adSwRow = LinearLayout(this)
        adSwRow.gravity = Gravity.CENTER_VERTICAL
        val adSwLabel = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        adSwLabel.addView(text(this, "Ad & Tracker Blocker", 14f, C.INK, true))
        adSwLabel.addView(text(this, if (host.isNotEmpty()) "Active on $host" else "Active on all sites", 12f, C.MUTED))
        adSwRow.addView(adSwLabel, LinearLayout.LayoutParams(0, -2, 1f))
        val adSwitch = Switch(this)
        adSwitch.isChecked = prefs.isSiteAdBlockEnabled(host)
        adSwitch.setOnCheckedChangeListener { _, checked ->
            prefs.setSiteAdBlockEnabled(host, checked)
            browser.active()?.let { browser.reload(it) }
        }
        adSwRow.addView(adSwitch)
        siteCard.addView(adSwRow, lp(-1, -2))

        val div2 = View(this).apply { background = ColorDrawable(C.LINE) }
        siteCard.addView(div2, lp(-1, dp(1)).apply { topMargin = dp(8); bottomMargin = dp(8) })

        val bgSwRow = LinearLayout(this)
        bgSwRow.gravity = Gravity.CENTER_VERTICAL
        val bgSwLabel = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        bgSwLabel.addView(text(this, "Background Play", 14f, C.INK, true))
        bgSwLabel.addView(text(this, "Keeps video & audio playing in background", 12f, C.MUTED))
        bgSwRow.addView(bgSwLabel, LinearLayout.LayoutParams(0, -2, 1f))
        val bgSwitch = Switch(this)
        bgSwitch.isChecked = prefs.isSiteBgPlayEnabled(host)
        bgSwitch.setOnCheckedChangeListener { _, checked ->
            prefs.setSiteBgPlayEnabled(host, checked)
            toast(if (checked) "Background play enabled for $host" else "Background play disabled")
        }
        bgSwRow.addView(bgSwitch)
        siteCard.addView(bgSwRow, lp(-1, -2))

        rootLayout.addView(siteCard, lp(-1, -2).apply { bottomMargin = dp(16) })

        // Section 2: OPERA GX RAM LIMITER
        val sec2 = text(this, "OPERA GX RAM LIMITER", 11.5f, 0xFF00D2FF.toInt(), true)
        sec2.pad(4, 4, 4, 6)
        rootLayout.addView(sec2)

        val ramCard = LinearLayout(this)
        ramCard.orientation = LinearLayout.VERTICAL
        ramCard.background = solid(this, C.SOFT, 16f)
        ramCard.pad(14, 12, 14, 12)

        val rt = Runtime.getRuntime()
        val usedMb = ((rt.totalMemory() - rt.freeMemory()) / (1024 * 1024)).toInt()
        val limitMb = prefs.ramLimitMb

        val ramStatsRow = LinearLayout(this)
        ramStatsRow.gravity = Gravity.CENTER_VERTICAL

        val memIcon = ImageView(this)
        memIcon.setImageResource(R.drawable.ic_memory)
        memIcon.imageTintList = ColorStateList.valueOf(0xFF00D2FF.toInt())
        ramStatsRow.addView(memIcon, LinearLayout.LayoutParams(dp(24), dp(24)).apply { rightMargin = dp(10) })

        val ramStatsCol = LinearLayout(this)
        ramStatsCol.orientation = LinearLayout.VERTICAL
        val ramUsageText = text(this, "RAM Used: ${usedMb} MB / ${limitMb} MB Limit", 14.5f, C.INK, true)
        ramStatsCol.addView(ramUsageText)

        val hibernatedCount = browser.tabs.count { it.hibernated }
        val ramStatusSub = text(this, if (hibernatedCount > 0) "$hibernatedCount background tabs hibernated" else "All tabs active in memory", 12f, C.MUTED)
        ramStatsCol.addView(ramStatusSub, lp(-2, -2).apply { topMargin = dp(2) })
        ramStatsRow.addView(ramStatsCol, LinearLayout.LayoutParams(0, -2, 1f))
        ramCard.addView(ramStatsRow, lp(-1, -2))

        val ramBar = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal)
        ramBar.max = limitMb
        ramBar.progress = usedMb.coerceIn(0, limitMb)
        ramCard.addView(ramBar, lp(-1, dp(6)).apply { topMargin = dp(10); bottomMargin = dp(10) })

        val sliderLabel = text(this, "Max RAM Ceiling: ${prefs.ramLimitMb} MB", 13f, C.INK, true)
        ramCard.addView(sliderLabel)

        val seekBar = SeekBar(this)
        seekBar.max = 14
        val currentStep = ((prefs.ramLimitMb - 256) / 128).coerceIn(0, 14)
        seekBar.progress = currentStep
        seekBar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar?, progress: Int, fromUser: Boolean) {
                val newLimit = 256 + (progress * 128)
                prefs.ramLimitMb = newLimit
                sliderLabel.text = "Max RAM Ceiling: $newLimit MB"
                ramBar.max = newLimit
                ramBar.progress = usedMb.coerceIn(0, newLimit)
                ramUsageText.text = "RAM Used: ${usedMb} MB / ${newLimit} MB Limit"
            }
            override fun onStartTrackingTouch(sb: SeekBar?) {}
            override fun onStopTrackingTouch(sb: SeekBar?) {
                if (prefs.ramHardLimit) enforceRamLimit()
            }
        })
        ramCard.addView(seekBar, lp(-1, -2).apply { topMargin = dp(4); bottomMargin = dp(8) })

        val hardLimRow = LinearLayout(this)
        hardLimRow.gravity = Gravity.CENTER_VERTICAL
        val hardLimLabel = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        hardLimLabel.addView(text(this, "Hard Limiter", 14f, C.INK, true))
        hardLimLabel.addView(text(this, "Auto-hibernate background tabs & trim cache", 12f, C.MUTED))
        hardLimRow.addView(hardLimLabel, LinearLayout.LayoutParams(0, -2, 1f))
        val hardSwitch = Switch(this)
        hardSwitch.isChecked = prefs.ramHardLimit
        hardSwitch.setOnCheckedChangeListener { _, checked ->
            prefs.ramHardLimit = checked
            if (checked) enforceRamLimit()
        }
        hardLimRow.addView(hardSwitch)
        ramCard.addView(hardLimRow, lp(-1, -2).apply { topMargin = dp(6); bottomMargin = dp(10) })

        val purgeBtn = text(this, "⚡ Purge RAM Now", 13.5f, C.ON_INK, true)
        purgeBtn.gravity = Gravity.CENTER
        purgeBtn.background = solid(this, C.INK, 16f)
        purgeBtn.pad(14, 8, 14, 8)
        purgeBtn.setOnClickListener {
            var count = 0
            for (t in browser.tabs) {
                if (t.id != browser.activeId && !t.hibernated) {
                    browser.hibernateTab(t)
                    count++
                }
            }
            Engine.trimMemory()
            System.gc()
            val newUsed = ((Runtime.getRuntime().totalMemory() - Runtime.getRuntime().freeMemory()) / (1024 * 1024)).toInt()
            ramUsageText.text = "RAM Used: ${newUsed} MB / ${prefs.ramLimitMb} MB Limit"
            ramBar.progress = newUsed.coerceIn(0, prefs.ramLimitMb)
            ramStatusSub.text = "$count tabs hibernated"
            toast("RAM Purged: $count background tabs frozen & cache cleared!")
        }
        ramCard.addView(purgeBtn, lp(-1, dp(40)))

        rootLayout.addView(ramCard, lp(-1, -2).apply { bottomMargin = dp(16) })

        // Section 3: EXTENSIONS MANAGER
        val sec3 = text(this, "BUILT-IN EXTENSIONS (6 ACTIVE)", 11.5f, C.MUTED, true)
        sec3.pad(4, 4, 4, 6)
        rootLayout.addView(sec3)

        val extCard = LinearLayout(this)
        extCard.orientation = LinearLayout.VERTICAL
        extCard.background = solid(this, C.SOFT, 16f)
        extCard.pad(14, 12, 14, 12)

        fun addExtensionRow(name: String, ver: String, desc: String, value: Boolean, onToggle: (Boolean) -> Unit) {
            val r = LinearLayout(this)
            r.gravity = Gravity.CENTER_VERTICAL
            r.pad(0, 6, 0, 6)
            val c = LinearLayout(this)
            c.orientation = LinearLayout.VERTICAL

            val titleRow = LinearLayout(this)
            titleRow.gravity = Gravity.CENTER_VERTICAL
            titleRow.addView(text(this, name, 14f, C.INK, true))

            val vTag = text(this, ver, 11f, C.MUTED)
            vTag.pad(6, 2, 6, 2)
            vTag.background = solid(this, C.WHITE, 8f)
            titleRow.addView(vTag, lp(-2, -2).apply { leftMargin = dp(6) })
            c.addView(titleRow)

            c.addView(text(this, desc, 12f, C.MUTED), lp(-2, -2).apply { topMargin = dp(2) })
            r.addView(c, LinearLayout.LayoutParams(0, -2, 1f))

            val sw = Switch(this)
            sw.isChecked = value
            sw.setOnCheckedChangeListener { _, checked -> onToggle(checked) }
            r.addView(sw)
            extCard.addView(r, lp(-1, -2))
        }

        addExtensionRow("AdBlock Shield Pro", "v2.4.0", "Blocks popups, banners & video ads", prefs.adBlock) {
            prefs.adBlock = it
            Engine.apply(prefs)
            browser.active()?.let { t -> browser.reload(t) }
        }

        addExtensionRow("Dark Reader Core", "v4.9.2", "High-contrast dark mode for all pages", prefs.extensionDarkReader) {
            prefs.extensionDarkReader = it
            browser.active()?.let { t -> browser.injectExtensionScripts(t) }
        }

        addExtensionRow("Background Play Enabler", "v1.3.1", "Keeps media playing in background tabs", prefs.bgPlay) {
            prefs.bgPlay = it
        }

        addExtensionRow("Desktop Mode Switcher", "v1.1.0", "Forces desktop Chrome user agent", prefs.desktop) {
            browser.setDesktop(it)
        }

        addExtensionRow("Video Speed Booster", "v1.5.2", "0.5x - 3.0x video playback acceleration", prefs.extensionVideoSpeed) {
            prefs.extensionVideoSpeed = it
        }

        addExtensionRow("HTTPS Everywhere Guard", "v2.1.0", "Upgrades connections to secure HTTPS", prefs.extensionHttpsEverywhere) {
            prefs.extensionHttpsEverywhere = it
        }

        val checkExtBtn = text(this, "🔄 Check for Extension Updates", 13f, C.INK, true)
        checkExtBtn.gravity = Gravity.CENTER
        checkExtBtn.background = solid(this, C.WHITE, 14f)
        checkExtBtn.pad(10, 8, 10, 8)
        checkExtBtn.setOnClickListener {
            toast("All extensions are up to date! (v2.4.0, v4.9.2, v1.3.1)")
        }
        extCard.addView(checkExtBtn, lp(-1, dp(38)).apply { topMargin = dp(8) })

        rootLayout.addView(extCard, lp(-1, -2).apply { bottomMargin = dp(16) })

        // Section 4: QUICK UTILITIES
        val sec4 = text(this, "SYSTEM & UPDATES", 11.5f, C.MUTED, true)
        sec4.pad(4, 4, 4, 6)
        rootLayout.addView(sec4)

        val utilCard = LinearLayout(this)
        utilCard.orientation = LinearLayout.VERTICAL
        utilCard.background = solid(this, C.SOFT, 16f)
        utilCard.pad(14, 12, 14, 12)

        val clearBtn = text(this, "🧹 Clear Cache & Site Data", 13.5f, C.INK, true)
        clearBtn.gravity = Gravity.CENTER
        clearBtn.background = solid(this, C.WHITE, 14f)
        clearBtn.pad(10, 8, 10, 8)
        clearBtn.setOnClickListener {
            Engine.clearData(false, true)
            toast("Cache and temporary data cleared!")
            dialog.dismiss()
        }
        utilCard.addView(clearBtn, lp(-1, dp(40)).apply { bottomMargin = dp(8) })

        val updateBtn = text(this, "🚀 Check for App Updates", 13.5f, C.INK, true)
        updateBtn.gravity = Gravity.CENTER
        updateBtn.background = solid(this, C.WHITE, 14f)
        updateBtn.pad(10, 8, 10, 8)
        updateBtn.setOnClickListener {
            toast("Liquid Air is up to date! (Version 2.5)")
        }
        utilCard.addView(updateBtn, lp(-1, dp(40)))

        rootLayout.addView(utilCard, lp(-1, -2).apply { bottomMargin = dp(10) })

        dialog.show()
    }

    private fun renderBookmarks() {
        val tab = browser.active()
        if (tab != null && !tab.isPrivate && !tab.home && Urls.isWeb(tab.url)) {
            val add = text(this, "+ Bookmark this page", 15f, C.INK, true)
            add.gravity = Gravity.CENTER
            add.background = solid(this, C.SOFT, 22f)
            add.setOnClickListener {
                if (browser.bookmarks.none { it.url == tab.url }) {
                    browser.bookmarks.add(0, Saved(tab.label(), tab.url))
                    browser.saveBookmarks()
                }
                renderTool()
            }
            toolBody.addView(add, lp(-1, dp(46)).apply { bottomMargin = dp(10) })
        }
        if (browser.bookmarks.isEmpty()) {
            empty("Your bookmarks will appear here.")
            return
        }
        for (b in browser.bookmarks.toList()) {
            row(b.title, Urls.display(b.url), { openSaved(b) }, removeButton {
                browser.bookmarks.remove(b)
                browser.saveBookmarks()
                renderTool()
            })
        }
    }

    private fun renderRecent() {
        if (browser.closed.isEmpty()) {
            empty("Tabs you close will appear here.")
            return
        }
        for (c in browser.closed.toList()) {
            row(c.title, Urls.display(c.url), {
                closeTool()
                browser.reopenClosed(c)
            })
        }
    }

    private fun switchRow(title: String, subtitle: String, value: Boolean, onChange: (Boolean) -> Unit) {
        val sw = Switch(this)
        sw.isChecked = value
        sw.setOnCheckedChangeListener { _, v -> onChange(v) }
        row(title, subtitle, { sw.toggle() }, sw)
    }

    private fun renderSettings() {
        val head = text(this, "GENERAL", 12f, C.MUTED, true)
        head.pad(6, 4, 6, 6)
        toolBody.addView(head, lp(-1, -2))
        switchRow("Ad and tracker blocker", "Blocks ads, trackers and fingerprinting. Off on YouTube and captcha pages.", prefs.adBlock) {
            prefs.adBlock = it
            Engine.apply(prefs)
            toast(if (it) "Blocker on" else "Blocker off")
        }
        switchRow("Background play", "Keep sound playing when the screen is off.", prefs.bgPlay) {
            prefs.bgPlay = it
            toast(if (it) "Background play on" else "Background play off")
        }
        switchRow("SafeSearch", "Applies to Google searches. Other search engines use their own setting.", prefs.safeSearch) {
            prefs.safeSearch = it
            toast(if (it) "SafeSearch on" else "SafeSearch off")
        }
        val themeNames = arrayOf("System default", "Light", "Dark")
        val engineNames = arrayOf("Google", "Brave Search", "DuckDuckGo")
        lateinit var engineRow: View
        engineRow = row("Search engine", engineNames[prefs.searchEngine], { showEnginePicker(engineRow) })
        lateinit var themeRow: View
        themeRow = row("Theme", themeNames[prefs.theme], { showThemePicker(themeRow) })
        switchRow("Hide private tabs", "Keeps private tabs out of screenshots and the recent-apps view.", prefs.secureTabs) {
            prefs.secureTabs = it
            browser.active()?.let { t -> applyPrivacy(t) }
            toast(if (it) "Private tabs are hidden" else "Private tabs can be captured")
        }
        switchRow("Restore tabs", "Open the pages you had open last time. Private tabs are never saved.", prefs.restoreTabs) {
            prefs.restoreTabs = it
            if (!it) prefs.session = ""
            toast(if (it) "Tabs will be restored" else "Tabs will not be restored")
        }
        row("Battery settings", "Let Android keep Liquid Air running in the background", { openBatterySettings() })
        val about = text(this, "ABOUT", 12f, C.MUTED, true)
        about.pad(6, 22, 6, 6)
        toolBody.addView(about, lp(-1, -2))
        row("Liquid Air 2.0", "Engine: GeckoView (Firefox engine)", null)
    }

    /** A small pop-up like the main menu: System default, Light or Dark. */
    private fun showThemePicker(anchor: View) {
        val names = arrayOf("System default", "Light", "Dark")
        val panel = LinearLayout(this)
        panel.orientation = LinearLayout.VERTICAL
        panel.background = solid(this, C.WHITE, 18f)
        panel.pad(6, 6, 6, 6)
        val holder = arrayOfNulls<PopupWindow>(1)
        for (i in names.indices) {
            val row = LinearLayout(this)
            row.gravity = Gravity.CENTER_VERTICAL
            row.pad(14, 0, 14, 0)
            row.background = withRipple(null)
            row.addView(text(this, names[i], 15f, C.INK, prefs.theme == i), LinearLayout.LayoutParams(0, -2, 1f))
            if (prefs.theme == i) row.addView(text(this, "\u2713", 17f, C.INK, true))
            row.setOnClickListener {
                holder[0]?.dismiss()
                if (prefs.theme != i) {
                    prefs.theme = i
                    toast("Theme: " + names[i])
                    reTheme()
                }
            }
            panel.addView(row, lp(-1, dp(46)))
        }
        val popup = PopupWindow(panel, dp(230), ViewGroup.LayoutParams.WRAP_CONTENT, true)
        popup.elevation = dpf(14f)
        popup.setBackgroundDrawable(null)
        popup.isOutsideTouchable = true
        holder[0] = popup
        popup.showAsDropDown(anchor, maxOf(0, anchor.width - dp(246)), -dp(16))
    }

    /** A small pop-up: pick the search engine used for words typed in the address bar. */
    private fun showEnginePicker(anchor: View) {
        val names = arrayOf("Google", "Brave Search", "DuckDuckGo")
        val panel = LinearLayout(this)
        panel.orientation = LinearLayout.VERTICAL
        panel.background = solid(this, C.WHITE, 18f)
        panel.pad(6, 6, 6, 6)
        val holder = arrayOfNulls<PopupWindow>(1)
        for (i in names.indices) {
            val row = LinearLayout(this)
            row.gravity = Gravity.CENTER_VERTICAL
            row.pad(14, 0, 14, 0)
            row.background = withRipple(null)
            row.addView(text(this, names[i], 15f, C.INK, prefs.searchEngine == i), LinearLayout.LayoutParams(0, -2, 1f))
            if (prefs.searchEngine == i) row.addView(text(this, "\u2713", 17f, C.INK, true))
            row.setOnClickListener {
                holder[0]?.dismiss()
                if (prefs.searchEngine != i) {
                    prefs.searchEngine = i
                    toast("Search engine: " + names[i])
                    renderTool()
                }
            }
            panel.addView(row, lp(-1, dp(46)))
        }
        val popup = PopupWindow(panel, dp(230), ViewGroup.LayoutParams.WRAP_CONTENT, true)
        popup.elevation = dpf(14f)
        popup.setBackgroundDrawable(null)
        popup.isOutsideTouchable = true
        holder[0] = popup
        popup.showAsDropDown(anchor, maxOf(0, anchor.width - dp(246)), -dp(16))
    }

    private fun openBatterySettings() {
        try {
            startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
        } catch (e: Exception) {
            try {
                startActivity(
                    Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName"))
                )
            } catch (e2: Exception) {
                toast("Open Settings > Apps > Liquid Air > Battery")
            }
        }
    }

    // ---- long-press menu ----------------------------------------------------

    fun showContextMenu(tab: Tab, link: String?, src: String?, type: Int) {
        val labels = ArrayList<String>()
        val actions = ArrayList<() -> Unit>()
        if (link != null) {
            labels.add("Open in new tab")
            actions.add { browser.newTab(link, tab.isPrivate) }
            if (!tab.isPrivate) {
                labels.add("Open in private tab")
                actions.add { browser.newTab(link, true) }
            }
            labels.add("Download link")
            actions.add { downloads.fetch(link) }
            labels.add("Copy link")
            actions.add { copy(link) }
            labels.add("Share link")
            actions.add {
                val send = Intent(Intent.ACTION_SEND)
                send.type = "text/plain"
                send.putExtra(Intent.EXTRA_TEXT, link)
                startActivity(Intent.createChooser(send, "Share link"))
            }
        }
        if (src != null && type == GeckoSession.ContentDelegate.ContextElement.TYPE_IMAGE) {
            labels.add("Open image in new tab")
            actions.add { browser.newTab(src, tab.isPrivate) }
            labels.add("Save image")
            actions.add { downloads.fetch(src) }
            labels.add("Copy image link")
            actions.add { copy(src) }
        }
        if (labels.isEmpty()) return
        AlertDialog.Builder(this)
            .setItems(labels.toTypedArray<CharSequence>()) { _, which -> actions[which]() }
            .show()
    }

    private fun copy(value: String) {
        val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        cm.setPrimaryClip(ClipData.newPlainText("link", value))
        toast("Copied")
    }

    // ---- Android permissions and file picking -------------------------------

    fun askAndroid(wanted: List<String>, answer: (Boolean) -> Unit) {
        val missing = wanted.filter { checkSelfPermission(it) != PackageManager.PERMISSION_GRANTED }
        if (missing.isEmpty()) {
            answer(true)
            return
        }
        val code = askCode++
        androidAsks[code] = answer
        requestPermissions(missing.toTypedArray(), code)
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        val cb = androidAsks.remove(requestCode) ?: return
        cb(grantResults.isNotEmpty() && grantResults.all { it == PackageManager.PERMISSION_GRANTED })
    }

    fun pickFiles(mimeTypes: List<String>, multiple: Boolean, answer: (List<Uri>) -> Unit) {
        filePicked = answer
        val i = Intent(Intent.ACTION_GET_CONTENT)
        i.addCategory(Intent.CATEGORY_OPENABLE)
        i.type = if (mimeTypes.size == 1) mimeTypes[0] else "*/*"
        if (mimeTypes.size > 1) i.putExtra(Intent.EXTRA_MIME_TYPES, mimeTypes.toTypedArray())
        i.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, multiple)
        try {
            startActivityForResult(Intent.createChooser(i, "Choose a file"), REQ_FILE)
        } catch (e: Exception) {
            filePicked = null
            answer(emptyList())
        }
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != REQ_FILE) return
        val cb = filePicked ?: return
        filePicked = null
        val out = ArrayList<Uri>()
        if (resultCode == RESULT_OK && data != null) {
            val clip = data.clipData
            if (clip != null) {
                for (i in 0 until clip.itemCount) out.add(clip.getItemAt(i).uri)
            } else {
                data.data?.let { out.add(it) }
            }
        }
        cb(out)
    }

    // ---- the Back button -----------------------------------------------------

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        when {
            menu != null -> closeMenu()
            findBar.visibility == View.VISIBLE -> hideFind()
            toolPage.visibility == View.VISIBLE -> closeTool()
            overview.visibility == View.VISIBLE -> hideOverview()
            fullscreen -> browser.active()?.session?.exitFullScreen()
            else -> {
                val tab = browser.active()
                if (tab != null && browser.canBack(tab)) browser.back(tab)
                else if (tab != null && tab.openedByEngine && !tab.home && browser.modeTabs().size > 1) browser.close(tab)
                else moveTaskToBack(true)
            }
        }
    }

    companion object {
        private const val REQ_FILE = 1001
    }
}
