package com.liquidair.browser

import android.content.Context
import org.mozilla.geckoview.ContentBlocking
import org.mozilla.geckoview.GeckoRuntime
import org.mozilla.geckoview.GeckoRuntimeSettings
import org.mozilla.geckoview.GeckoSession
import org.mozilla.geckoview.GeckoSessionSettings

/**
 * Everything that talks to the browser engine's global settings lives here, so the
 * rest of the app never has to know how the engine is configured.
 */
object Engine {
    private var runtimeOrNull: GeckoRuntime? = null

    val runtime: GeckoRuntime
        get() = runtimeOrNull ?: error("Engine.start() was not called")

    fun start(context: Context, prefs: Prefs) {
        if (runtimeOrNull == null) {
            runtimeOrNull = GeckoRuntime.create(context.applicationContext)
        }
        apply(prefs)
    }

    /** Push the user's choices (blocker, text size, ...) into the engine. */
    fun apply(prefs: Prefs) {
        val settings = runtime.settings
        settings.setJavaScriptEnabled(true)
        settings.setRemoteDebuggingEnabled(false)
        settings.setConsoleOutputEnabled(false)
        // Pages follow the app theme: system default, or the light/dark choice in Settings.
        settings.setPreferredColorScheme(
            when (prefs.theme) {
                1 -> GeckoRuntimeSettings.COLOR_SCHEME_LIGHT
                2 -> GeckoRuntimeSettings.COLOR_SCHEME_DARK
                else -> GeckoRuntimeSettings.COLOR_SCHEME_SYSTEM
            }
        )
        settings.setGlobalPrivacyControl(true)

        val blocking = settings.contentBlocking
        if (prefs.adBlock) {
            blocking.setEnhancedTrackingProtectionLevel(ContentBlocking.EtpLevel.STRICT)
            blocking.setAntiTracking(
                ContentBlocking.AntiTracking.AD or
                    ContentBlocking.AntiTracking.ANALYTIC or
                    ContentBlocking.AntiTracking.SOCIAL or
                    ContentBlocking.AntiTracking.CRYPTOMINING or
                    ContentBlocking.AntiTracking.FINGERPRINTING
            )
            blocking.setCookieBehavior(ContentBlocking.CookieBehavior.ACCEPT_NON_TRACKERS)
            blocking.setStrictSocialTrackingProtection(true)
        } else {
            blocking.setEnhancedTrackingProtectionLevel(ContentBlocking.EtpLevel.NONE)
            blocking.setAntiTracking(ContentBlocking.AntiTracking.NONE)
        }

        settings.setAutomaticFontSizeAdjustment(false)
        settings.setFontInflationEnabled(true)
        settings.setFontSizeFactor(prefs.zoom / 100f)
    }

    /** A fresh page session. Private tabs get a separate private session. */
    fun newSession(private: Boolean, desktop: Boolean): GeckoSession {
        val builder = GeckoSessionSettings.Builder()
            .usePrivateMode(private)
            .userAgentMode(
                if (desktop) GeckoSessionSettings.USER_AGENT_MODE_DESKTOP
                else GeckoSessionSettings.USER_AGENT_MODE_MOBILE
            )
            .viewportMode(
                if (desktop) GeckoSessionSettings.VIEWPORT_MODE_DESKTOP
                else GeckoSessionSettings.VIEWPORT_MODE_MOBILE
            )
        return GeckoSession(builder.build())
    }

    fun clearData(cookiesAndSites: Boolean, caches: Boolean) {
        var flags = 0L
        if (cookiesAndSites) flags = flags or
            org.mozilla.geckoview.StorageController.ClearFlags.SITE_DATA
        if (caches) flags = flags or
            org.mozilla.geckoview.StorageController.ClearFlags.ALL_CACHES
        if (flags != 0L) runtime.storageController.clearData(flags)
    }

    fun trimMemory() {
        try {
            runtimeOrNull?.storageController?.clearData(
                org.mozilla.geckoview.StorageController.ClearFlags.ALL_CACHES
            )
        } catch (_: Exception) {}
    }
}
